
/*********************************************************************************
*	Misc functions!
**********************************************************************************/

#include "stdafx.h"

//String functions
//Trim the white space off a string!
std::string trimString(std::string stringToTrim) {
	if (stringToTrim.size() > 0) {
		stringToTrim = stringToTrim.substr(stringToTrim.find_first_not_of(' '), stringToTrim.size()); //remove the whitespace off the front
		stringToTrim = stringToTrim.substr(stringToTrim.find_first_not_of("	"), stringToTrim.size()); //remove tabs off the front
		stringToTrim = stringToTrim.substr(0, stringToTrim.find_last_not_of(' ') + 1); //remove the whitespace off the end
		stringToTrim = stringToTrim.substr(0, stringToTrim.find_last_not_of("	") + 1); //remove tabs off the end
	}
	return stringToTrim;
}

std::vector<std::string> splitString(std::string stringToSplit, std::string delim) {
	std::vector<std::string> splitStrings;
	std::string butcheredString = stringToSplit;
	while (butcheredString.find(delim) != std::string::npos) {
		splitStrings.push_back(butcheredString.substr(0, butcheredString.find(delim)));
		butcheredString = butcheredString.substr(butcheredString.find(delim) + delim.size(), butcheredString.size());
	}
	splitStrings.push_back(butcheredString);
	return splitStrings;
}

//functions allowing the lists of nodes to be obtained on flowchart.cpp etc
std::vector <ResourceNode> getResourceNodeList() {
	return ResourceNodeList;
}

std::vector <ExtractorNode> getExtractorNodeList() {
	return ExtractorNodeList;
}

std::vector <ProcessNode> getProcessNodeList() {
	return ProcessNodeList;
}

std::vector <ConsumerNode> getConsumerNodeList() {
	return ConsumerNodeList;
}

std::vector <StorageNode> getStorageNodeList() {
	return StorageNodeList;
}

//functions allowing lists to be updated from other .cpp files
int updateResourceNodeList(std::vector <ResourceNode> list) {
	ResourceNodeList = list;
	return 0;
}

int updateExtractorNodeList(std::vector <ExtractorNode> list) {
	ExtractorNodeList = list;
	return 0;
}
int updateProcessNodeList(std::vector <ProcessNode> list) {
	ProcessNodeList = list;
	return 0;
}
int updateConsumerNodeList(std::vector <ConsumerNode> list) {
	ConsumerNodeList = list;
	return 0;
}
int updateStorageNodeList(std::vector <StorageNode> list) {
	StorageNodeList = list;
	return 0;
}

//Functions allowing all acceptable units to be obtained for this cpp file
std::array <std::string, 5> getMassUnitsList() {
	return MassUnitsList;
}
std::array <std::string, 5> getDistanceUnitsList() {
	return DistanceUnitsList;
}
std::array <std::string, 5> getVolumeUnitsList() {
	return VolumeUnitsList;
}
std::array <std::string, 5> getPowerUnitsList() {
	return PowerUnitsList;
}
std::array<std::string, 15> getFlowRateUnitsList() {
	return FlowRateUnitsList;
}

bool isAnyNodesFloating() {
	for (int i = 0; i < ResourceNodeList.size(); i++) {
		if (ResourceNodeList[i].isPlaced == false) {
			return true;
		}
	}
	for (int i = 0; i < ExtractorNodeList.size(); i++) {
		if (!ExtractorNodeList[i].isPlaced) {
			return true;
		}
	}
	for (int i = 0; i < ProcessNodeList.size(); i++) {
		if (!ProcessNodeList[i].isPlaced) {
			return true;
		}
	}
	for (int i = 0; i < ConsumerNodeList.size(); i++) {
		if (!ConsumerNodeList[i].isPlaced) {
			return true;
		}
	}
	for (int i = 0; i < StorageNodeList.size(); i++) {
		if (!StorageNodeList[i].isPlaced) {
			return true;
		}
	}
	return false;
}

//allow positions to be accessed outside of main.cpp
int getMouseX() {
	return mouseX;
}
int getMouseY() {
	return mouseY;
}
int getLastMouseX() {
	return lastMouseX;
}
int getLastMouseY() {
	return lastMouseY;
}
bool isMousePressedL() {
	return mousePressedL;
}
bool isMouseLDblClk() {
	return mouseLDblClk;
}

//allow window handles to be accessed from other pages...
HWND getNodeNameBox() {
	return nodeNameBox;
}
HWND getNodeDescBox() {
	return nodeDescBox;
}

//get the view variables
float getZoomFactor() {
	return zoomFactor;
}
float getViewX() {
	return viewX;
}
float getViewY() {
	return viewY;
}
//functions that correct x/y positions, going from internal to screen co-ords
float correctX(float xpos) {
	return (xpos - getViewX())*zoomFactor;
}
float correctY(float ypos) {
	return (ypos - getViewY())*zoomFactor;
}
//and the functions that go the other way
float deCorrectX(float xpos) {
	return (xpos / zoomFactor) + getViewX();
}
float deCorrectY(float ypos) {
	return (ypos / zoomFactor) + getViewY();
}
//create a tooltip!
HWND createTooltip(HWND hwndParent, HWND toolTip, TCHAR* text) {
	INITCOMMONCONTROLSEX ic;
	ic.dwSize = sizeof(INITCOMMONCONTROLSEX);
	ic.dwICC = ICC_TAB_CLASSES;
	InitCommonControlsEx(&ic);
	// Create a ToolTip.
	toolTip = CreateWindowEx(WS_EX_TOPMOST, TOOLTIPS_CLASS, NULL, WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, hwndParent, NULL, mainHinst, NULL);
	SetWindowPos(toolTip, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	// Set up "tool" information.
	// In this case, the "tool" is the entire parent window.
	TOOLINFO ti = { 0 };
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hwndParent; //normally the flowchart window
	ti.hinst = mainHinst;
	ti.lpszText = LPSTR(text);
	GetClientRect(hwndParent, &ti.rect);
	SendMessage(toolTip, TTM_ADDTOOL, 0, (LPARAM)(LPTOOLINFO)&ti); //Associate it with all the data from the struct
	SendMessage(toolTip, TTM_ACTIVATE, true, NULL); //activate it
	SendMessage(toolTip, TTM_SETMAXTIPWIDTH, 0, 180); //make it a multi-line tooltip
	SendMessage(toolTip, TTM_SETDELAYTIME, TTDT_AUTOPOP, 25000); //make it hide after 25 seconds (25,000ms)
	return toolTip;
}

//Murder a tooltip!
HWND destroyTooltip(HWND tooltip) {
	DestroyWindow(tooltip);
	return tooltip;
}