
/*******************************************************************************************************************************
*
*
*	Colony Simulator v0.4.0 by /u/rafty4, started 02/10/2016, last updated 04/02/2017.
*	
*	A program for simulating any resource-driven system in an exceedingly flexible manner, but with particular focus
*	on extra-terrestrial colonies, particularly Martian ones. However, systems as diverse as a bucket being filled with
*	water, a factory, colonies of ants, small ecosystems etc. can also be relatively easily modelled,
*	thanks to the built in flexibility and user-created content focus of the application.
*	Currently approx 10,314 lines of code.
*
*	TODO:
*	-> Node edit window graphically filled in for each node type
*	-> Nodes associate with the comment box they're in
*	-> Nodes always associate with the box with the smallest area they're inside
*	-> Make better approximation for spline curve collision detection
*	-> Optimise framerate for lotsa nodes
*	-> Undo button works
*	-> Redo button works
*
*
*	UNDOCUMENTED FEATURES:
*	-> Closing the extractor none creation window can cause everything to close!
*	-> Opened child windows not updating properly when a different request button has been pressed
*	-> Comment boxes are not resizing correctly when placed
*	-> Comment edit boxes do not display multiple lines automatically
*	-> Something funny going on with nodes being reconnected when clicked after a connection point has been deleted
*	-> Scrollbars dissappear until mouseover upon resize
*	-> Comment edit box text will sometimes scroll to the left when typing
*	-> Comment boxes don't resize properly on zooming
*	-> Node resizing doesn't quite work right when zoomed in
*	-> Flickers like a bitch on resizing
*	-> Zoom buttons will dissappear on resizing
*	-> Node tooltips can reappear (often in the wrong places) after node deletion or zooming
*	-> Bezier curves aren't quite working right...
*	-> Arcs being doubled, and one of them dragging (but not until the flowchart has otherwise been fully debugged!!)
*
*	-> (SOLVED, now continually update) Connection points not re-indexed after deletion 
*	-> (SOLVED) RCM Arc removal only removes the lowest indexed arc, not the one selected
*	-> (SOLVED) Cannot right-click on an arc when a node is selected
*	-> (SOLVED, survived 26 minutes) Still appears to be a minor memory leak somewhere...
*	-> (SOLVED)'New Simulation' causes all kinds of window-related havoc
*	-> (SOLVED) Zoom buttons will disappear on startup
*	-> (SOLVED) Connections are drawn in reverse order!
*	-> (SOLVED) Node connections do not update properly when a node is resized
*	-> (SOLVED) Can no longer remove elements from a component in the periodic table view
*
*
*********************************************************************************************************************************/

#include "stdafx.h"

LRESULT CALLBACK WinProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam){
	PAINTSTRUCT ps;
	HDC hdc;
	HDC          hdcMem;
	HBITMAP      hbmMem;
	HANDLE       hOld;
	switch (msg)
	{
	//Mouse wheel!
	case WM_MOUSEWHEEL:
	{
		zoomFactor /= float(1.1);
	}
	break;
	case WM_SIZE:
		return 1;
	case WM_CREATE:
	{
		HGDIOBJ hfDefault = GetStockObject(DEFAULT_GUI_FONT);
		// Create a push button
		HWND NewResourceButton = CreateWindowEx(NULL, "BUTTON", "Add Resource", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 30, 140, 25, hWnd, (HMENU)IDC_REQ_RESOURCE, GetModuleHandle(NULL), NULL);
		HWND NewExtractorButton = CreateWindowEx(NULL, "BUTTON", "Add Extractor Process", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 150, 30, 140, 25, hWnd, (HMENU)IDC_REQ_EXTRACTOR, GetModuleHandle(NULL), NULL);
		HWND NewIndustrialProcessButton = CreateWindowEx(NULL, "BUTTON", "Add Industrial Process", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 290, 30, 140, 25, hWnd, (HMENU)IDC_REQ_INDUSTRIAL, GetModuleHandle(NULL), NULL);
		HWND NewConsumerButton = CreateWindowEx(NULL, "BUTTON", "Add Consumer", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 430, 30, 140, 25, hWnd, (HMENU)IDC_REQ_CONSUMER, GetModuleHandle(NULL), NULL);
		HWND NewStorageButton = CreateWindowEx(NULL, "BUTTON", "Add Storage", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 570, 30, 140, 25, hWnd, (HMENU)IDC_REQ_STORAGE, GetModuleHandle(NULL), NULL);


		//Despatch the relevant messages to create each button
		SendMessage(NewResourceButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(NewExtractorButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(NewIndustrialProcessButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(NewConsumerButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(NewStorageButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		DeleteObject(hfDefault);
	}
	break;

	case WM_COMMAND: //if we have recieved a command word
		switch (LOWORD(wParam)) //take the low-level word
		{

			/***************************************************************************
			*
			*	Deal with commands from the menu bar!
			*
			***************************************************************************/
			/*File menu*/
		case IDM_NEW_SIM: //create a new simulation
		{
			//clear everything
			//clear the node lists
			ResourceNodeList.clear();
			ExtractorNodeList.clear();
			ProcessNodeList.clear();
			ConsumerNodeList.clear();
			StorageNodeList.clear();
			for (int i = 0; i < CommentsList.size(); i++) {
				CommentsList[commentSelected].destroy(); //remove all the edit boxes
			}
			CommentsList.clear();
			//and clear the selections
			resourceNodeSelected = -1;
			resourceForwardsConnectionClicked = -1;
			extractorNodeSelected = -1;
			extractorBackwardsConnectionClicked = -1;
			extractorForwardsConnectionClicked = -1;
			processNodeSelected = -1;
			processForwardsConnectionClicked = -1;
			processBackwardsConnectionClicked = -1;
			consumerNodeSelected = -1;
			consumerForwardsConnectionClicked = -1;
			consumerBackwardsConnectionClicked = -1;
			storageNodeSelected = -1;
			storageForwardsConnectionClicked = -1;
			storageBackwardsConnectionClicked = -1;
			//clear misc variables
			nodeCreationType = -1;
			ForwardsConnectionsToAdd.clear();
			BackwardsConnectionsToAdd.clear();
			fowardsConnectionsNum = 1;
			backwardsConnectionsNum = 1;
			RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE); //and refresh the screen!
		}
		break;
		case IDM_SAVE: //save a project
		{

		}
		break;
		case IDM_SAVE_AS: //save the project as...
		{
			OPENFILENAME ofn;
			char szFileName[MAX_PATH] = "";

			ZeroMemory(&ofn, sizeof(ofn));

			ofn.lStructSize = sizeof(ofn); // SEE NOTE BELOW
			ofn.hwndOwner = hWnd;
			ofn.lpstrFilter = "All Files (*.*)\0*.*\0";
			ofn.lpstrFile = szFileName;
			ofn.nMaxFile = MAX_PATH;
			ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
			ofn.lpstrDefExt = "txt";

			if (GetSaveFileName(&ofn))
			{
				// Do something useful with the filename stored in szFileName 
			}
		}
		break;
		case IDM_SAVE_COPY_AS: //save a copy of the project as...
		{
			OPENFILENAME ofn;
			char szFileName[MAX_PATH] = "";

			ZeroMemory(&ofn, sizeof(ofn));

			ofn.lStructSize = sizeof(ofn); // SEE NOTE BELOW
			ofn.hwndOwner = hWnd;
			ofn.lpstrFilter = "All Files (*.*)\0*.*\0";
			ofn.lpstrFile = szFileName;
			ofn.nMaxFile = MAX_PATH;
			ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
			ofn.lpstrDefExt = "txt";

			if (GetSaveFileName(&ofn)) {
				// Do something useful with the filename stored in szFileName 
			}
		}
		break;
		case IDM_OPEN: //open a project
		{
			OPENFILENAME ofn;
			char szFileName[MAX_PATH] = "";

			ZeroMemory(&ofn, sizeof(ofn));

			ofn.lStructSize = sizeof(ofn); // SEE NOTE BELOW
			ofn.hwndOwner = hWnd;
			ofn.lpstrFilter = "All Files (*.*)\0*.*\0";
			ofn.lpstrFile = szFileName;
			ofn.nMaxFile = MAX_PATH;
			ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
			ofn.lpstrDefExt = "txt";

			if (GetOpenFileName(&ofn)) {
				// Do something useful with the filename stored in szFileName 
			}
		}
		break;
		case IDM_EXIT:
		{
			PostQuitMessage(0); //Exit!
		}
		break;
		/*View Menu*/
		case IDM_ZOOM_IN:
		{
			zoomFactor *= float(1.3);
		}
		break;
		case IDM_ZOOM_OUT:
		{
			zoomFactor /= float(1.3);
		}
		break;
		case IDM_RESET_VIEW:
		{
			zoomFactor = 1;
			viewX = 0;
			viewY = 0;
		}
		break;
		case IDM_SET_BKGND_STATIC_GRID:
		{
			backgroundMode = 1;
		}
		break;
		case IDM_SET_BKGND_MOBILE_GRID:
		{
			backgroundMode = 2;
		}
		break;
		case IDM_SET_BKGND_PLAIN:
		{
			backgroundMode = 0;
		}
		break;
		/*Settings Menu*/
		//...
		/*Create Menu*/
		case IDCE_EDIT_CONNECTIONS + 0:
		case IDCE_EDIT_CONNECTIONS + 1:
		case IDCE_EDIT_CONNECTIONS + 2:
		case IDCE_EDIT_CONNECTIONS + 3:
		case IDCE_EDIT_CONNECTIONS + 4:
		{
			nodeEditWindowMode = LOWORD(wParam) - IDCE_EDIT_CONNECTIONS;
			SendMessage(NodeConnEditWindowHandle, WM_COMMAND, IDCE_EDIT_CONNECTIONS, 0);
		}
		break;
		case ERCW_CREATE_NEW:
		{
			SendMessage(ExtractableResourceCreationWindowHandle, WM_COMMAND, ERCW_CREATE_NEW, 0);
		}
		break;
		case RCCW_CREATE_NEW:
		{
			SendMessage(ResourceComponentCreationWindowHandle, WM_COMMAND, RCCW_CREATE_NEW, 0);
		}
		break;
		case CSW_START_EDIT:
		{
			SendMessage(ChemicalFormulaCreationWindowHandle, WM_COMMAND, CSW_START_EDIT, 0);
		}
		break;
		/*Colony Menu*/
		//...
		/*Simulate Menu*/
		//...
		/*Help menu*/
		case IDM_ABOUT: //"About Colony Simulator" from the help menu
		{
			//Produce a nice message detailing colony simulator
			OutputDebugString("About");
			MessageBox(NULL, "Colony Simulator v0.4.0\nA resource-driven simulation tool. Although specifically geared towards simulating off-world colonies (specifically Martian ones), it can be used to simulate any system involving an exchange of resources - from filling a bucket of water, to an object falling under gravity, to a fully-blown ecosystem.\nCreated by /u/rafty4 and licensed under the GPL x.x license.", "About Colony Simulator", MB_ICONINFORMATION);
		}
		break;

		/**************************************************************************
		*
		*	Deal with other commands!
		*
		**************************************************************************/

		case IDC_REQ_RESOURCE: //if a new resource node has been *requested*...
		{
			SendMessage(NodeCreateWindowHandle, IDC_REQ_NEW_NODE, 0, IDC_REQ_RESOURCE); //forward the message onto the other window
		}
		break;
		case IDC_REQ_EXTRACTOR: //if a new extractor node has been *requested*...
		{
			SendMessage(NodeCreateWindowHandle, IDC_REQ_NEW_NODE, 0, IDC_REQ_EXTRACTOR); //forward the message onto the other window
		}
		break;
		case IDC_REQ_INDUSTRIAL: //if a new industrial process node has been *requested*...
		{
			SendMessage(NodeCreateWindowHandle, IDC_REQ_NEW_NODE, 0, IDC_REQ_INDUSTRIAL); //forward the message onto the other window
		}
		break;
		case IDC_REQ_CONSUMER: //if a new consumer node has been *requested*...
		{
			SendMessage(NodeCreateWindowHandle, IDC_REQ_NEW_NODE, 0, IDC_REQ_CONSUMER); //forward the message onto the other window
		}
		break;
		case IDC_REQ_STORAGE: //if a new storage node has been *requested*...
		{
			SendMessage(NodeCreateWindowHandle, IDC_REQ_NEW_NODE, 0, IDC_REQ_STORAGE); //forward the message onto the other window
		}
		break;
		//otherwise... messages have been replied to by the node creatin window! Fwends!
		case IDC_ADD_RESOURCE: //if we have recived a message telling us to add a new resource node...
		{
			ResourceNode newResourceNode(float(mouseX), float(mouseY), 140, 50, ForwardsConnectionsToAdd); //create a new resource node, with basic dimensions
			ResourceNodeList.push_back(newResourceNode); //add resource node to the end of the list
		}
		break;
		case IDC_ADD_EXTRACTOR:
		{
			ExtractorNode newExtractorNode(float(mouseX), float(mouseY), 140, 50, ForwardsConnectionsToAdd, BackwardsConnectionsToAdd);
			ExtractorNodeList.push_back(newExtractorNode);
		}
		break;
		case IDC_ADD_INDUSTRIAL:
		{
			ProcessNode newProcessNode(float(mouseX), float(mouseY), 140, 50, ForwardsConnectionsToAdd, BackwardsConnectionsToAdd);
			ProcessNodeList.push_back(newProcessNode);
		}
		break;
		case IDC_ADD_CONSUMER:
		{
			ConsumerNode newConsumerNode(float(mouseX), float(mouseY), 140, 50, ForwardsConnectionsToAdd, BackwardsConnectionsToAdd);
			ConsumerNodeList.push_back(newConsumerNode);
		}
		break;
		case IDC_ADD_STORAGE:
		{
			StorageNode newStorageNode(float(mouseX), float(mouseY), 140, 50, ForwardsConnectionsToAdd, BackwardsConnectionsToAdd);
			StorageNodeList.push_back(newStorageNode);
		}
		break;
		}
		break;

		case WM_ERASEBKGND:
			return (LRESULT)1; // Say we handled it.

	case WM_PAINT:
	{
		RECT rect;
		GetWindowRect(hWnd, &rect);
		win_width = rect.right - rect.left;
		win_height = rect.bottom - rect.top;

		hdc = BeginPaint(hWnd, &ps);

		// Create an off-screen DC for double-buffering
		hdcMem = CreateCompatibleDC(hdc);
		hbmMem = CreateCompatibleBitmap(hdc, win_width, win_height);

		hOld = SelectObject(hdcMem, hbmMem);

		/*************************************************************************************
		*
		*	Drawing code called here!
		*
		**************************************************************************************/

		// Fill the client area with a brush
		RECT clientRect;
		HRGN bgRgn;
		HBRUSH hBrush;
		GetClientRect(hWnd, &clientRect);
		win_width = clientRect.right - clientRect.left;
		win_height = clientRect.bottom - clientRect.top;
		bgRgn = CreateRectRgnIndirect(&clientRect);
		hBrush = CreateSolidBrush(RGB(255, 255, 255)); //colour it white
		FillRgn(hdcMem, bgRgn, hBrush); //draw to offscreen buffer

		//Label this screen
		TextOut(hdcMem, 10, 5, "Flowchart View", _tcslen("Flowchart View"));


		//Swap buffers
		BitBlt(hdc, 0, 0, win_width, win_height, hdcMem, 0, 0, SRCCOPY);

		//Free-up the off-screen buffer
		SelectObject(hdcMem, hOld);
		DeleteObject(hbmMem);
		DeleteDC(hdcMem);

		SelectObject(hdc, NULL);

		EndPaint(hWnd, &ps);
	}
	break;
	case WM_DESTROY:
	{
		PostQuitMessage(0);
		return 0;
	}
	break;
	case WM_MOUSEMOVE:
	{

	}
	break; 
	}
	return DefWindowProc(hWnd, msg, wParam, lParam);
}


/*************************************************************************************************
*
*	Flowchart window procedure!
*	This is where we handle all the messages relating to the flowchart!
*
**************************************************************************************************/

LRESULT CALLBACK FlowchartWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam){
	switch (message){
		case WM_CREATE:
		{
			// Create zoom in/zoom out buttons
			FlowchartZoomInButton = CreateWindowEx(NULL, "BUTTON", "+", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_FLAT, win_width - 60, 10, 20, 20, hWnd, (HMENU)IDC_ZOOM_IN, GetModuleHandle(NULL), NULL);
			FlowchartZoomOutButton = CreateWindowEx(NULL, "BUTTON", "-", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_FLAT, win_width - 60, 32, 20, 20, hWnd, (HMENU)IDC_ZOOM_OUT, GetModuleHandle(NULL), NULL);

			//Despatch the relevant messages to create each button
			HGDIOBJ hfDefault = GetStockObject(DEFAULT_GUI_FONT);
			SendMessage(FlowchartZoomInButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
			SendMessage(FlowchartZoomOutButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
			DeleteObject(hfDefault);
		}
		break;
		case WM_SIZE: //Pretty sure this isn't helping at all... >.<
		{
			//RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE | RDW_INTERNALPAINT);
			return 1;
		}
		break;
		case WM_LBUTTONDBLCLK:
		{
			mouseLDblClk = true;
		}
		break;
		case WM_LBUTTONUP:
		{
			mousePressedL = false;
			for (int i = 0; i < CommentsList.size(); i++) { //iterate through the lists of comments
				if (CommentsList[i].isDefiningArea) { //if this comment is trying to define it's area of influence...
					if (CommentsList[i].TempAssociationRect.left == 0 && CommentsList[i].TempAssociationRect.top == 0) { //... and it's top left and right have not yet been placed
						CommentsList[i].TempAssociationRect.left = (LONG)deCorrectX((float)mouseX); //place them!
						CommentsList[i].TempAssociationRect.top = (LONG)deCorrectY((float)mouseY);
					}
					else if(CommentsList[i].TempAssociationRect.right != 0 && CommentsList[i].TempAssociationRect.bottom != 0){ //and if everything has now been sorted, make it permanent!
						CommentsList[i].isDefiningArea = false; //stop the node thinking it is defining an area
						CommentsList[i].AssociationRect = CommentsList[i].TempAssociationRect; //make it permanent!
						CommentsList[i].TempAssociationRect = { 0,0,0,0 }; //and reset the temporary area for next time!
						//and stick the comment itself on the top left corner of the rectangle!
						CommentsList[i].xpos = (float)CommentsList[i].AssociationRect.left;
						CommentsList[i].ypos = (float)CommentsList[i].AssociationRect.top - CommentsList[i].height;
					}
				}
			}
		}
		break;
		case WM_LBUTTONDOWN:
		{
			mousePressedL = true;
			bool wasOperationCarriedOut = false; //variable for keeping track of if anything actually happened - used to determine if a reset must be carried out.
			for (int i = 0; i < CommentsList.size(); i++) {
				if (CommentsList[i].isMouseOverComment((float)mouseX, (float)mouseY)) {
					CommentsList[i].isPlaced = !(CommentsList[i].isPlaced == true); //make it free-floating (or not)
					wasOperationCarriedOut = true; //record an operation happened!
				}
			}
			//iterate through the list of resource nodes and make sure they are all placed, and no other tasks need to be completed
			for (int i = 0; i < ResourceNodeList.size(); i++){
				if (!ResourceNodeList[i].isPlaced){
					ResourceNodeList[i].place(mouseX, mouseY);
				}
				else if (ResourceNodeList[i].isConnectionNodeClicked(mouseX, mouseY) != -1 && resourceNodeSelected != i && ResourceNodeList[i].forwardsConnectionPointsList[ResourceNodeList[i].isConnectionNodeClicked(mouseX, mouseY, false)].connectionsList.size() == 0){ //see if any of this node's connections are being clicked
					OutputDebugString("Clicked Resource node forward connection!\n");
					wasOperationCarriedOut = true; //record an operation was carried out
					if ((resourceNodeSelected == -1 && resourceForwardsConnectionClicked == -1) && extractorForwardsConnectionClicked == -1 && processForwardsConnectionClicked == -1 && consumerForwardsConnectionClicked == -1 && processNodeSelected == -1 && consumerNodeSelected == -1 && storageNodeSelected == -1){ //make sure we aren't trying to connect two resource front nodes...
						resourceNodeSelected = i; //this node has now been selected
						resourceForwardsConnectionClicked = ResourceNodeList[i].isConnectionNodeClicked(mouseX, mouseY, false); //false means the values are only observed, not modified
						ResourceNodeList[i].forwardsConnectionPointsList[resourceForwardsConnectionClicked].setUnconnectedArc(ResourceNodeList[i].x + ResourceNodeList[i].width - 2, ResourceNodeList[i].y + (ResourceNodeList[i].height / 2) + (ResourceNodeList[i].defaultHeight / 2)*(resourceForwardsConnectionClicked - float(ResourceNodeList[i].forwardsConnectionPointsList.size() -1) / 2));
						if (extractorBackwardsConnectionClicked != -1){ //if an extractor's backwards node has been selected
							OutputDebugString("Connecting nodes...\n");
							//connect the node up correctly for the extractor node
							ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].placeConnection(1 /*start at the extractor node*/, 0 /*start on the LHS*/, extractorNodeSelected, extractorBackwardsConnectionClicked, 0 /*end at the resource node*/, 1 /*end on the RHS*/, resourceNodeSelected, resourceForwardsConnectionClicked); //place the connection
							ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the resource node! Note that this means two lines are actually goign to be drawn, rather than one
							ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].placeConnection(1 /*start at the extractor node*/, 0 /*start on the LHS*/, extractorNodeSelected, extractorBackwardsConnectionClicked, 0 /*end at the resource node*/, 1 /*end on the RHS*/, resourceNodeSelected, resourceForwardsConnectionClicked); //place the connection
							ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							resourceNodeSelected = -1;
							extractorNodeSelected = -1;
							extractorBackwardsConnectionClicked = -1;
							resourceForwardsConnectionClicked = -1;
						}
					}
					break; //break out of this for loop. Our work is done.
				}
			}
			for (int i = 0; i < ExtractorNodeList.size(); i++){
				if (!ExtractorNodeList[i].isPlaced){
					ExtractorNodeList[i].place(mouseX, mouseY);
				}
				else if (ExtractorNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY) != -1 && extractorNodeSelected != i && ExtractorNodeList[i].backwardsConnectionPointsList[ExtractorNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false)].connectionsList.size() == 0){ //see if any of it's backwards connections are being clicked
					OutputDebugString("Clicked Extractor backwards connection!\n");
					wasOperationCarriedOut = true; //record an operation was carried out
					if (extractorBackwardsConnectionClicked == -1 && processBackwardsConnectionClicked == -1 && consumerBackwardsConnectionClicked == -1){
						extractorBackwardsConnectionClicked = ExtractorNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false);
						ExtractorNodeList[i].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].setUnconnectedArc(ExtractorNodeList[i].x, ExtractorNodeList[i].y + (ExtractorNodeList[i].height / 2) + (ExtractorNodeList[i].defaultHeight / 2)*(extractorBackwardsConnectionClicked - float(ExtractorNodeList[i].backwardsConnectionPointsList.size() - 1) / 2));
						if (extractorForwardsConnectionClicked != -1 && extractorNodeSelected != i){ //we must be trying to daisy-chain extractors! (But not connecting stuff to itself. That's naughty!)
							OutputDebugString("Connecting two extractor nodes...\n");
							//deal with the other extractor node
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].placeConnection(1 /*start at the *other* extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked, 1 /*end at this extractor node*/, 0 /*end on the LHS*/, i, extractorBackwardsConnectionClicked); //place the connection on the other extractor's memory
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//deal with this extractor node
							ExtractorNodeList[i].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].placeConnection(1 /*start at the *other* extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked, 1 /*end at this extractor node*/, 0 /*end on the LHS*/, i, extractorBackwardsConnectionClicked); //place the connection on this extractor's memory
							ExtractorNodeList[i].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//reset the relevant variables
							extractorNodeSelected = -1;
							extractorBackwardsConnectionClicked = -1;
							extractorForwardsConnectionClicked = -1;
							break; //LEAVE! NOW! BEFORE ANYTHING BAD HAPPENS!!
						}
						else{
							extractorNodeSelected = i; //this entire node has now been selected
						}
						//moving on to the not-so-special connection cases...
						if (resourceForwardsConnectionClicked != -1){ //if a resource node's connection has been clicked
							OutputDebugString("Connecting extractor and resource node...\n");
							//connect the node up correctly for the extractor node
							ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].placeConnection(0 /*start at the resource node*/, 1 /*start on the RHS*/, resourceNodeSelected, resourceForwardsConnectionClicked, 1 /*end at the extractor node*/, 0 /*end on the LHS*/, extractorNodeSelected, extractorBackwardsConnectionClicked); //place the connection
							ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the resource node! Note that this means two lines are actually goign to be drawn, rather than one
							ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].placeConnection(0 /*start at the resource node*/, 1 /*start on the RHS*/, resourceNodeSelected, resourceForwardsConnectionClicked, 1 /*end at the extractor node*/, 0 /*end on the LHS*/, extractorNodeSelected, extractorBackwardsConnectionClicked); //place the connection
							ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							resourceNodeSelected = -1;
							extractorNodeSelected = -1;
							extractorBackwardsConnectionClicked = -1;
							resourceForwardsConnectionClicked = -1;
						}
						if (processNodeSelected != -1 || consumerNodeSelected != -1){ //reset the connection creation variables if the connection is not legal
							ExtractorNodeList[i].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].unsetUnconnectedArc();
							resourceNodeSelected = -1;
							resourceForwardsConnectionClicked = -1;
							extractorNodeSelected = -1;
							extractorForwardsConnectionClicked = -1;
							extractorBackwardsConnectionClicked = -1;
						}
					}
					break;
				}
				else if (ExtractorNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY) != -1 && extractorNodeSelected != i && ExtractorNodeList[i].forwardsConnectionPointsList[ExtractorNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false)].connectionsList.size() == 0){ //see if any of it's forwards connections are being clicked
					OutputDebugString("Clicked Extractor Forwards connection!\n");
					wasOperationCarriedOut = true; //record an operation was carried out
					if (resourceForwardsConnectionClicked == -1 && extractorForwardsConnectionClicked == -1 && processForwardsConnectionClicked == -1 && consumerForwardsConnectionClicked == -1){
						extractorForwardsConnectionClicked = ExtractorNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false); //false tells the check not to modify any values
						ExtractorNodeList[i].forwardsConnectionPointsList[extractorForwardsConnectionClicked].setUnconnectedArc(ExtractorNodeList[i].x + ExtractorNodeList[i].width - 2, ExtractorNodeList[i].y + (ExtractorNodeList[i].height / 2) + (ExtractorNodeList[i].defaultHeight / 2)*(extractorForwardsConnectionClicked - float(ExtractorNodeList[i].forwardsConnectionPointsList.size() - 1) / 2));
						if (extractorBackwardsConnectionClicked != -1 && extractorNodeSelected != i){ //we must be trying to daisy-chain extractors!
							OutputDebugString("Connecting two extractor nodes\n");
							//deal with the other extractor node
							ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].placeConnection(1 /*start at the *other* extractor node*/, 0 /*start on the LHS*/, extractorNodeSelected, extractorBackwardsConnectionClicked, 1 /*end at this extractor node*/, 1 /*end on the RHS*/, i, extractorForwardsConnectionClicked); //place the connection on the other extractor's memory
							ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//deal with this extractor node
							ExtractorNodeList[i].forwardsConnectionPointsList[extractorForwardsConnectionClicked].placeConnection(1 /*start at the *other* extractor node*/, 0 /*start on the LHS*/, extractorNodeSelected, extractorBackwardsConnectionClicked, 1 /*end at this extractor node*/, 1 /*end on the RHS*/, i, extractorForwardsConnectionClicked); //place the connection on this extractors memory
							ExtractorNodeList[i].forwardsConnectionPointsList[extractorForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//reset the relevant variables
							extractorNodeSelected = -1;
							extractorBackwardsConnectionClicked = -1;
							extractorForwardsConnectionClicked = -1;
							break; //leave
						}
						else{
							extractorNodeSelected = i; //this entire node has now been selected
						}

						if (processBackwardsConnectionClicked != -1){
							OutputDebugString("Connecting Extractor and Process nodes...\n");
							//connect the node up correctly for the extractor node
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].placeConnection(2 /*start at the process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked, 1 /*end at the extractor node*/, 1 /*end on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked); //place the connection
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].placeConnection(2 /*start at the process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked, 1 /*end at the extractor node*/, 1 /*end on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked); //place the connection
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							extractorNodeSelected = -1;
							processNodeSelected = -1;
							extractorForwardsConnectionClicked = -1;
							processBackwardsConnectionClicked = -1;
						}
						else if (consumerBackwardsConnectionClicked != -1){
							OutputDebugString("Connecting nodes consumer and extractor nodes...\n");
							//connect the node up correctly for the consumer node
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].placeConnection(3 /*end at the consumer node*/, 0 /*end on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked, 1 /*start at the extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked); //place the connection
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the extracctor node! Note that this means two lines are actually goign to be drawn, rather than one
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].placeConnection(3 /*end at the consumer node*/, 0 /*end on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked, 1 /*start at the extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked); //place the connection
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							consumerNodeSelected = -1;
							extractorNodeSelected = -1;
							consumerBackwardsConnectionClicked = -1;
							extractorForwardsConnectionClicked = -1;
						}
						else if (storageBackwardsConnectionClicked != -1){
							OutputDebugString("Connecting storage & extractor nodes...\n");
							//connect the node up correctly for the consumer node
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].placeConnection(4 /*end at the storage node*/, 0 /*end on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked, 1 /*start at the extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked); //place the connection
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the extracctor node! Note that this means two lines are actually goign to be drawn, rather than one
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].placeConnection(4 /*end at the storage node*/, 0 /*end on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked, 1 /*start at the extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked); //place the connection
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							storageNodeSelected = -1;
							extractorNodeSelected = -1;
							storageBackwardsConnectionClicked = -1;
							extractorForwardsConnectionClicked = -1;
						}
					}
					break;
				}
			}
			for (int i = 0; i < ProcessNodeList.size(); i++){
				if (!ProcessNodeList[i].isPlaced){
					ProcessNodeList[i].place(mouseX, mouseY);
				}
				else if (ProcessNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY) != -1 && processNodeSelected != i && ProcessNodeList[i].backwardsConnectionPointsList[ProcessNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false)].connectionsList.size() == 0){ //see if any of this node's backwards connections are being clicked
					wasOperationCarriedOut = true; //record an operation was carried out
					OutputDebugString("Clicked Process node backwards connection!\n");
					if (extractorBackwardsConnectionClicked == -1 && processBackwardsConnectionClicked == -1 && consumerBackwardsConnectionClicked == -1 && resourceNodeSelected == -1 && resourceForwardsConnectionClicked == -1){
						processBackwardsConnectionClicked = ProcessNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false); //false means the values are only observed, not modified
						ProcessNodeList[i].backwardsConnectionPointsList[processBackwardsConnectionClicked].setUnconnectedArc(ProcessNodeList[i].x, ProcessNodeList[i].y + (ProcessNodeList[i].height / 2) + (ProcessNodeList[i].defaultHeight / 2)*(processBackwardsConnectionClicked - float(ProcessNodeList[i].backwardsConnectionPointsList.size() - 1) / 2));
						if (processForwardsConnectionClicked != -1 && processNodeSelected != i){ //we are trying to chain process nodes -- but stop the user doing stupid stuff connecting a node directly to itself
							OutputDebugString("Connecting two process nodes...\n");
							//deal with the other process node
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].placeConnection(2 /*start at the *other* process node*/, 1 /*start on the RHS*/, processNodeSelected, processForwardsConnectionClicked, 2 /*end at this process node*/, 0 /*end on the LHS*/, i, processBackwardsConnectionClicked); //place the connection on the other process' memory
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//deal with this process node
							ProcessNodeList[i].backwardsConnectionPointsList[processBackwardsConnectionClicked].placeConnection(2 /*start at the *other* process node*/, 1 /*start on the RHS*/, processNodeSelected, processForwardsConnectionClicked, 2 /*end at this process node*/, 0 /*end on the LHS*/, i, processBackwardsConnectionClicked); //place the connection on this process' memory
							ProcessNodeList[i].backwardsConnectionPointsList[processBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//reset the relevant variables
							processNodeSelected = -1;
							processBackwardsConnectionClicked = -1;
							processForwardsConnectionClicked = -1;
							break;
						}
						else{
							processNodeSelected = i; //this node has now been selected
						}

						if (extractorForwardsConnectionClicked != -1){ //if an extractor's forwards node has been selected
							OutputDebugString("Connecting extractor & process nodes...\n");
							//connect the node up correctly for the extractor node
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].placeConnection(1 /*start at the extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked, 2 /*end at the process node*/, 0 /*end on the LHS*/, processNodeSelected, processBackwardsConnectionClicked); //place the connection
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].placeConnection(1 /*start at the extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked, 2 /*end at the process node*/, 0 /*end on the LHS*/, processNodeSelected, processBackwardsConnectionClicked); //place the connection
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							extractorNodeSelected = -1;
							processNodeSelected = -1;
							extractorForwardsConnectionClicked = -1;
							processBackwardsConnectionClicked = -1;
						}
						else if (consumerForwardsConnectionClicked != -1){
							OutputDebugString("Connecting consumer & process nodes...\n");
							//connect the node up correctly for the extractor node
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].placeConnection(3 /*start at the consumer node*/, 1 /*start on the RHS*/, consumerNodeSelected, consumerForwardsConnectionClicked, 2 /*end at the process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked); //place the connection
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].placeConnection(3 /*start at the consumer node*/, 1 /*start on the RHS*/, consumerNodeSelected, consumerForwardsConnectionClicked, 2 /*end at the process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked); //place the connection
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							consumerNodeSelected = -1;
							processNodeSelected = -1;
							consumerForwardsConnectionClicked = -1;
							processBackwardsConnectionClicked = -1;
						}
						else if (storageForwardsConnectionClicked != -1){
							OutputDebugString("Connecting storage & process nodes ...\n");
							//connect the node up correctly for the extractor node
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].placeConnection(4 /*start at the storage node*/, 1 /*start on the RHS*/, storageNodeSelected, storageForwardsConnectionClicked, 2 /*end at the process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked); //place the connection
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].placeConnection(4 /*start at the storage node*/, 1 /*start on the RHS*/, storageNodeSelected, storageForwardsConnectionClicked, 2 /*end at the process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked); //place the connection
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							storageNodeSelected = -1;
							processNodeSelected = -1;
							storageForwardsConnectionClicked = -1;
							processBackwardsConnectionClicked = -1;
						}
					}
					break; //break out of this for loop. Our work is done here.
				}
				else if (ProcessNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY) != -1 && processNodeSelected != i && ProcessNodeList[i].forwardsConnectionPointsList[ProcessNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false)].connectionsList.size() == 0){ //see if any of this node's forwards connections are being clicked
					OutputDebugString("Clicked Process node forwards connection!\n");
					wasOperationCarriedOut = true; //record an operation was carried out
					if (resourceForwardsConnectionClicked == -1 && extractorForwardsConnectionClicked == -1 && extractorBackwardsConnectionClicked == -1 && processForwardsConnectionClicked == -1 && consumerForwardsConnectionClicked == -1){
						processForwardsConnectionClicked = ProcessNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false); //false means the values are only observed, not modified
						ProcessNodeList[i].forwardsConnectionPointsList[processForwardsConnectionClicked].setUnconnectedArc(ProcessNodeList[i].x + ProcessNodeList[i].width - 2, ProcessNodeList[i].y + (ProcessNodeList[i].height / 2) + (ProcessNodeList[i].defaultHeight / 2)*(processForwardsConnectionClicked - float(ProcessNodeList[i].forwardsConnectionPointsList.size() - 1) / 2));
						if (processBackwardsConnectionClicked != -1 && processNodeSelected != i){ //we are trying to chain process nodes!
							OutputDebugString("Connecting two process nodes...\n");
							//deal with the other process node
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].placeConnection(2 /*start at the *other* process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked, 2 /*end at this process node*/, 1 /*end on the RHS*/, i, processForwardsConnectionClicked); //place the connection on the other process' memory
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//deal with this process node
							ProcessNodeList[i].forwardsConnectionPointsList[processForwardsConnectionClicked].placeConnection(2 /*start at the *other* process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked, 2 /*end at this process node*/, 1 /*end on the RHS*/, i, processForwardsConnectionClicked); //place the connection on this process' memory
							ProcessNodeList[i].forwardsConnectionPointsList[processForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//reset the relevant variables
							processNodeSelected = -1;
							processBackwardsConnectionClicked = -1;
							processForwardsConnectionClicked = -1;
							break;
						}
						else{
							processNodeSelected = i; //this node has now been selected
						}

						if (consumerBackwardsConnectionClicked != -1){ //if a consumer's backwards node has been selected
							OutputDebugString("Connecting nodes...\n");
							//connect the node up correctly for the consumer node
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].placeConnection(3 /*start at the consumer node*/, 0 /*start on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked, 2 /*end at the process node*/, 1 /*end on the RHS*/, processNodeSelected, processForwardsConnectionClicked); //place the connection
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].placeConnection(3 /*start at the consumer node*/, 0 /*start on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked, 2 /*end at the process node*/, 1 /*end on the RHS*/, processNodeSelected, processForwardsConnectionClicked); //place the connection
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							consumerNodeSelected = -1;
							processNodeSelected = -1;
							consumerBackwardsConnectionClicked = -1;
							processForwardsConnectionClicked = -1;
						}
						else if (storageBackwardsConnectionClicked != -1){ //if a storage nodes backwards node has been selected
							OutputDebugString("Connecting Storage & Process nodes...\n");
							//connect the node up correctly for the consumer node
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].placeConnection(4 /*start at the storage node*/, 0 /*start on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked, 2 /*end at the process node*/, 1 /*end on the RHS*/, processNodeSelected, processForwardsConnectionClicked); //place the connection
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].placeConnection(4 /*start at the storage node*/, 0 /*start on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked, 2 /*end at the process node*/, 1 /*end on the RHS*/, processNodeSelected, processForwardsConnectionClicked); //place the connection
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							storageNodeSelected = -1;
							processNodeSelected = -1;
							storageBackwardsConnectionClicked = -1;
							processForwardsConnectionClicked = -1;
						}
					}
					break;
				}
			}
			for (int i = 0; i < ConsumerNodeList.size(); i++){
				if (!ConsumerNodeList[i].isPlaced){
					ConsumerNodeList[i].place(mouseX, mouseY);
				}
				else if (ConsumerNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY) != -1 && consumerNodeSelected != i && ConsumerNodeList[i].backwardsConnectionPointsList[ConsumerNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false)].connectionsList.size() == 0){ //see if any of this node's backwards connections are being clicked
					OutputDebugString("Clicked Consumer node backwards connection!\n");
					wasOperationCarriedOut = true; //record an operation was carried out
					if (extractorBackwardsConnectionClicked == -1 && processBackwardsConnectionClicked == -1 && consumerBackwardsConnectionClicked == -1 && resourceForwardsConnectionClicked == -1 && resourceNodeSelected == -1){
						consumerBackwardsConnectionClicked = ConsumerNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false); //false means the values are only observed, not modified
						ConsumerNodeList[i].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].setUnconnectedArc(ConsumerNodeList[i].x + 2, ConsumerNodeList[i].y + (ConsumerNodeList[i].height / 2) + (ConsumerNodeList[i].defaultHeight / 2)*(consumerBackwardsConnectionClicked - float(ConsumerNodeList[i].backwardsConnectionPointsList.size() - 1) / 2));
						if (consumerForwardsConnectionClicked != -1 && consumerNodeSelected != i){ //we are trying to chain consumer nodes
							OutputDebugString("Connecting two consumer nodes...\n");
							//deal with the other consumer node
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].placeConnection(3 /*start at the *other* consumer node*/, 1 /*start on the RHS*/, consumerNodeSelected, consumerForwardsConnectionClicked, 3 /*end at this process node*/, 0 /*end on the LHS*/, i, consumerBackwardsConnectionClicked); //place the connection on the other consumer's memory
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//deal with this consumer node
							ConsumerNodeList[i].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].placeConnection(3 /*start at the *other* consumer node*/, 1 /*start on the RHS*/, consumerNodeSelected, consumerForwardsConnectionClicked, 3 /*end at this process node*/, 0 /*end on the LHS*/, i, consumerBackwardsConnectionClicked); //place the connection on this consumer's memory
							ConsumerNodeList[i].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//reset the relevant variables
							consumerNodeSelected = -1;
							consumerBackwardsConnectionClicked = -1;
							consumerForwardsConnectionClicked = -1;
							break;
						}
						else{
							consumerNodeSelected = i; //this node has now been selected
						}

						if (processForwardsConnectionClicked != -1){ //if a process' forwards node has been selected
							OutputDebugString("Connecting nodes...\n");
							//connect the node up correctly for the consumer node
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].placeConnection(2 /*start at the process node*/, 1 /*start on the RHS*/, processNodeSelected, processForwardsConnectionClicked, 3 /*end at the consumer node*/, 0 /*end on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked); //place the connection
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].placeConnection(2 /*start at the process node*/, 1 /*start on the RHS*/, processNodeSelected, processForwardsConnectionClicked, 3 /*end at the consumer node*/, 0 /*end on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked); //place the connection
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							consumerNodeSelected = -1;
							processNodeSelected = -1;
							consumerBackwardsConnectionClicked = -1;
							processForwardsConnectionClicked = -1;
							break; //break out of this for loop. Our work is done here.
						}
						else if (extractorForwardsConnectionClicked != -1){ //if an extractor forwards node has been selected
							OutputDebugString("Connecting Consumer & Extractor nodes...\n");
							//connect the node up correctly for the consumer node
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].placeConnection(1 /*start at the extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked, 3 /*end at the consumer node*/, 0 /*end on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked); //place the connection
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the extractor node! Note that this means two lines are actually goign to be drawn, rather than one
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].placeConnection(1 /*start at the extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked, 3 /*end at the consumer node*/, 0 /*end on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked); //place the connection
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							consumerNodeSelected = -1;
							extractorNodeSelected = -1;
							consumerBackwardsConnectionClicked = -1;
							extractorForwardsConnectionClicked = -1;
						}
						else if (storageForwardsConnectionClicked != -1){ //if a storage forwards node has been selected
							OutputDebugString("Connecting Consumer & Storage nodes...\n");
							//connect the node up correctly for the consumer node
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].placeConnection(4 /*start at the storage node*/, 1 /*start on the RHS*/, storageNodeSelected, storageForwardsConnectionClicked, 3 /*end at the consumer node*/, 0 /*end on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked); //place the connection
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the storage node! Note that this means two lines are actually goign to be drawn, rather than one
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].placeConnection(4 /*start at the storage node*/, 1 /*start on the RHS*/, storageNodeSelected, storageForwardsConnectionClicked, 3 /*end at the consumer node*/, 0 /*end on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked); //place the connection
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							consumerNodeSelected = -1;
							storageNodeSelected = -1;
							consumerBackwardsConnectionClicked = -1;
							storageForwardsConnectionClicked = -1;
						}
					}
					break; //break out of this for loop. Our work is done here.
				}
				else if (ConsumerNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY) != -1 && consumerNodeSelected != i && ConsumerNodeList[i].forwardsConnectionPointsList[ConsumerNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false)].connectionsList.size() == 0){ //if it's been clicked, and we aren't trying to connect to itself
					OutputDebugString("Clicked Consumer node forwards connection!\n");
					wasOperationCarriedOut = true; //record an operation was carried out
					if (resourceForwardsConnectionClicked == -1 && extractorForwardsConnectionClicked == -1 && extractorBackwardsConnectionClicked == -1 && processForwardsConnectionClicked == -1 && consumerForwardsConnectionClicked == -1){
						consumerForwardsConnectionClicked = ConsumerNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false); //false means the values are only observed, not modified
						ConsumerNodeList[i].forwardsConnectionPointsList[consumerForwardsConnectionClicked].setUnconnectedArc(ConsumerNodeList[i].x + ConsumerNodeList[i].width - 2, ConsumerNodeList[i].y + (ConsumerNodeList[i].height / 2) + (ConsumerNodeList[i].defaultHeight / 2)*(consumerForwardsConnectionClicked - float(ConsumerNodeList[i].forwardsConnectionPointsList.size() - 1) / 2));
						if (consumerBackwardsConnectionClicked != -1 && consumerNodeSelected != i){ //we are trying to chain consumer nodes. But not connect them to themselves!
							OutputDebugString("Connecting two consumer nodes...\n");
							//deal with the other process node
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].placeConnection(3 /*start at the *other* consumer node*/, 0 /*start on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked, 3 /*end at this consumer node*/, 1 /*end on the RHS*/, i, consumerForwardsConnectionClicked); //place the connection on the other consumer's memory
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//deal with this process node
							ConsumerNodeList[i].forwardsConnectionPointsList[consumerForwardsConnectionClicked].placeConnection(3 /*start at the *other* consumer node*/, 0 /*start on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked, 3 /*end at this consumer node*/, 1 /*end on the RHS*/, i, consumerForwardsConnectionClicked); //place the connection on this consumer's memory
							ConsumerNodeList[i].forwardsConnectionPointsList[consumerForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//reset the relevant variables
							consumerNodeSelected = -1;
							consumerBackwardsConnectionClicked = -1;
							consumerForwardsConnectionClicked = -1;
							break;
						}
						else{
							consumerNodeSelected = i; //this node has now been selected
						}
						//connecting the less special case(s): i.e. adding a process node onto the front!
						if (processBackwardsConnectionClicked != -1){
							OutputDebugString("Connecting nodes...\n");
							//connect the node up correctly for the extractor node
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].placeConnection(2 /*start at the process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked, 3 /*end at the consumer node*/, 1 /*end on the RHS*/, consumerNodeSelected, consumerForwardsConnectionClicked); //place the connection
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].placeConnection(2 /*start at the process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked, 3 /*end at the consumer node*/, 1 /*end on the RHS*/, consumerNodeSelected, consumerForwardsConnectionClicked); //place the connection
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							consumerNodeSelected = -1;
							processNodeSelected = -1;
							consumerForwardsConnectionClicked = -1;
							processBackwardsConnectionClicked = -1;
						}
						else if (storageBackwardsConnectionClicked != -1){
							OutputDebugString("Connecting nodes...\n");
							//connect the node up correctly for the extractor node
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].placeConnection(4 /*start at the storage node*/, 0 /*start on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked, 3 /*end at the consumer node*/, 1 /*end on the RHS*/, consumerNodeSelected, consumerForwardsConnectionClicked); //place the connection
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].placeConnection(4 /*start at the storage node*/, 0 /*start on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked, 3 /*end at the consumer node*/, 1 /*end on the RHS*/, consumerNodeSelected, consumerForwardsConnectionClicked); //place the connection
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							consumerNodeSelected = -1;
							storageNodeSelected = -1;
							consumerForwardsConnectionClicked = -1;
							storageBackwardsConnectionClicked = -1;
						}
					}
					break;
				}
			}
			for (int i = 0; i < StorageNodeList.size(); i++){
				if (!StorageNodeList[i].isPlaced){
					StorageNodeList[i].place(mouseX, mouseY);
				}
				else if (StorageNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY) != -1 && i != storageNodeSelected && StorageNodeList[i].backwardsConnectionPointsList[StorageNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false)].connectionsList.size() == 0){ //see if any of this node's backwards connections are being clicked
					OutputDebugString("Clicked Storage node backwards connection!\n");
					wasOperationCarriedOut = true; //record an operation was carried out
					if (extractorBackwardsConnectionClicked == -1 && processBackwardsConnectionClicked == -1 && consumerBackwardsConnectionClicked == -1 && resourceForwardsConnectionClicked == -1 && resourceNodeSelected == -1 && storageBackwardsConnectionClicked == -1){
						storageBackwardsConnectionClicked = StorageNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false); //false means the values are only observed, not modified
						StorageNodeList[i].backwardsConnectionPointsList[storageBackwardsConnectionClicked].setUnconnectedArc(StorageNodeList[i].x + 2, StorageNodeList[i].y + (StorageNodeList[i].height / 2) + (StorageNodeList[i].defaultHeight / 2)*(storageBackwardsConnectionClicked - float(StorageNodeList[i].backwardsConnectionPointsList.size() - 1) / 2));
						if (storageForwardsConnectionClicked != -1 && storageNodeSelected != i){ //we are trying to chain storage nodes
							OutputDebugString("Connecting two Storage nodes...\n");
							//deal with the other storage node
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].placeConnection(4 /*start at the *other* storage node*/, 1 /*start on the RHS*/, storageNodeSelected, storageForwardsConnectionClicked, 4 /*end at this storage node*/, 0 /*end on the LHS*/, i, storageBackwardsConnectionClicked); //place the connection on the other storage's memory
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//deal with this storage node
							StorageNodeList[i].backwardsConnectionPointsList[storageBackwardsConnectionClicked].placeConnection(4 /*start at the *other* storage node*/, 1 /*start on the RHS*/, storageNodeSelected, storageForwardsConnectionClicked, 4 /*end at this storage node*/, 0 /*end on the LHS*/, i, storageBackwardsConnectionClicked); //place the connection on this storage's memory
							StorageNodeList[i].backwardsConnectionPointsList[storageBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//reset the relevant variables
							storageNodeSelected = -1;
							storageBackwardsConnectionClicked = -1;
							storageForwardsConnectionClicked = -1;
							break;
						}
						else{
							storageNodeSelected = i; //this node has now been selected
						}

						if (processForwardsConnectionClicked != -1){ //if a process' forwards node has been selected
							OutputDebugString("Connecting storage & process nodes...\n");
							//connect the node up correctly for the consumer node
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].placeConnection(2 /*start at the process node*/, 1 /*start on the RHS*/, processNodeSelected, processForwardsConnectionClicked, 4 /*end at the storage node*/, 0 /*end on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked); //place the connection
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].placeConnection(2 /*start at the process node*/, 1 /*start on the RHS*/, processNodeSelected, processForwardsConnectionClicked, 4 /*end at the storage node*/, 0 /*end on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked); //place the connection
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							storageNodeSelected = -1;
							processNodeSelected = -1;
							storageBackwardsConnectionClicked = -1;
							processForwardsConnectionClicked = -1;
							break; //break out of this for loop. Our work is done here.
						}
						else if (extractorForwardsConnectionClicked != -1){ //if a process' forwards node has been selected
							OutputDebugString("Connecting storage & extractor nodes...\n");
							//connect the node up correctly for the consumer node
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].placeConnection(1 /*start at the extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked, 4 /*end at the storage node*/, 0 /*end on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked); //place the connection
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the extractor node! Note that this means two lines are actually goign to be drawn, rather than one
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].placeConnection(1 /*start at the extractor node*/, 1 /*start on the RHS*/, extractorNodeSelected, extractorForwardsConnectionClicked, 4 /*end at the storage node*/, 0 /*end on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked); //place the connection
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							storageNodeSelected = -1;
							extractorNodeSelected = -1;
							storageBackwardsConnectionClicked = -1;
							extractorForwardsConnectionClicked = -1;
						}
						else if (consumerForwardsConnectionClicked != -1){ //if a consumer's forwards node has been selected
							OutputDebugString("Connecting consumer & storage nodes...\n");
							//connect the node up correctly for the consumer node
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].placeConnection(3 /*start at the consumer node*/, 1 /*start on the RHS*/, consumerNodeSelected, consumerForwardsConnectionClicked, 4 /*end at the storage node*/, 0 /*end on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked); //place the connection
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the extractor node! Note that this means two lines are actually goign to be drawn, rather than one
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].placeConnection(3 /*start at the consumer node*/, 1 /*start on the RHS*/, consumerNodeSelected, consumerForwardsConnectionClicked, 4 /*end at the storage node*/, 0 /*end on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked); //place the connection
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							storageNodeSelected = -1;
							consumerNodeSelected = -1;
							storageBackwardsConnectionClicked = -1;
							consumerForwardsConnectionClicked = -1;
						}
					}
					break; //break out of this for loop. Our work is done here.
				}
				else if (StorageNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY) != -1 && i != storageNodeSelected && StorageNodeList[i].forwardsConnectionPointsList[StorageNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false)].connectionsList.size() == 0){
					OutputDebugString("Clicked Storage node forwards connection!\n");
					wasOperationCarriedOut = true; //record an operation was carried out
					if (resourceForwardsConnectionClicked == -1 && extractorBackwardsConnectionClicked == -1 && extractorForwardsConnectionClicked == -1 && processForwardsConnectionClicked == -1 && consumerForwardsConnectionClicked == -1 && storageForwardsConnectionClicked == -1){
						storageForwardsConnectionClicked = StorageNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false); //false means the values are only observed, not modified
						StorageNodeList[i].forwardsConnectionPointsList[storageForwardsConnectionClicked].setUnconnectedArc(StorageNodeList[i].x + StorageNodeList[i].width - 2, StorageNodeList[i].y + (StorageNodeList[i].height / 2) + (StorageNodeList[i].defaultHeight / 2)*(storageForwardsConnectionClicked - float(StorageNodeList[i].forwardsConnectionPointsList.size() - 1) / 2));
						if (storageBackwardsConnectionClicked != -1 && storageNodeSelected != i){ //we are trying to chain consumer nodes. But not connect them to themselves!
							OutputDebugString("Connecting two storage nodes...\n");
							//deal with the other storage node
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].placeConnection(4 /*start at the *other* storage node*/, 0 /*start on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked, 4 /*end at this storage node*/, 1 /*end on the RHS*/, i, storageForwardsConnectionClicked); //place the connection on the other storage's memory
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//deal with this storage node
							StorageNodeList[i].forwardsConnectionPointsList[storageForwardsConnectionClicked].placeConnection(4 /*start at the *other* storage node*/, 0 /*start on the LHS*/, storageNodeSelected, storageBackwardsConnectionClicked, 4 /*end at this storage node*/, 1 /*end on the RHS*/, i, storageForwardsConnectionClicked); //place the connection on this storage's memory
							StorageNodeList[i].forwardsConnectionPointsList[storageForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating
							//reset the relevant variables
							storageNodeSelected = -1;
							storageBackwardsConnectionClicked = -1;
							storageForwardsConnectionClicked = -1;
							break;
						}
						else{
							storageNodeSelected = i; //this node has now been selected
						}
						//connecting the less special case(s): i.e. adding a process node onto the front!
						if (processBackwardsConnectionClicked != -1){
							OutputDebugString("Connecting nodes...\n");
							//connect the node up correctly for the extractor node
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].placeConnection(2 /*start at the process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked, 4 /*end at the storage node*/, 1 /*end on the RHS*/, storageNodeSelected, storageForwardsConnectionClicked); //place the connection
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].placeConnection(2 /*start at the process node*/, 0 /*start on the LHS*/, processNodeSelected, processBackwardsConnectionClicked, 4 /*end at the storage node*/, 1 /*end on the RHS*/, storageNodeSelected, storageForwardsConnectionClicked); //place the connection
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							storageNodeSelected = -1;
							processNodeSelected = -1;
							storageForwardsConnectionClicked = -1;
							processBackwardsConnectionClicked = -1;
						}
						if (consumerBackwardsConnectionClicked != -1){
							OutputDebugString("Connecting Consumer & Storage nodes...\n");
							//connect the node up correctly for the extractor node
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].placeConnection(3 /*start at the consumer node*/, 0 /*start on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked, 4 /*end at the storage node*/, 1 /*end on the RHS*/, storageNodeSelected, storageForwardsConnectionClicked); //place the connection
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//and now do the same for the process node! Note that this means two lines are actually goign to be drawn, rather than one
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].placeConnection(3 /*start at the consumer node*/, 0 /*start on the LHS*/, consumerNodeSelected, consumerBackwardsConnectionClicked, 4 /*end at the storage node*/, 1 /*end on the RHS*/, storageNodeSelected, storageForwardsConnectionClicked); //place the connection
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].isFreeFloating = false; // no longer free-floating

							//reset the relevant variables
							storageNodeSelected = -1;
							consumerNodeSelected = -1;
							storageForwardsConnectionClicked = -1;
							consumerBackwardsConnectionClicked = -1;
						}
					}
					break;
				}
			}
			/**
			For the sake of clarity we are going to iterate through each list individually, and separately from the other loops
			considered next. We can change this if it becomes an optimisation issue. This is C++, not python, so it shouldn't be!
			**/
			bool isNodeClicked = false;
			if (!wasOperationCarriedOut){ //We know the user hasn't just missed a node accidentally
				for (int i = 0; i < ResourceNodeList.size(); i++){ //iterate through all resource nodes
					if (ResourceNodeList[i].isMouseOverNode(mouseX, mouseY)){ //if the mouse is over the node!
						isNodeClicked = true;
						if (ResourceNodeList[i].isConnectionNodeClicked(mouseX, mouseY, false) == -1 && !ResourceNodeList[i].unlockSize){ //we know this is not due to nodes being clicked
							OutputDebugString("Clicked resource entire node!\n");
							ResourceNodeList[i].isPlaced = false; //make it free-floating again
							break;
						}
					}
				}
				for (int i = 0; i < ExtractorNodeList.size(); i++){
					if (ExtractorNodeList[i].isMouseOverNode(mouseX, mouseY)){ //we are over the node
						isNodeClicked = true;
						if (ExtractorNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && ExtractorNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && !ExtractorNodeList[i].unlockSize){ //we know this is not due to nodes being clicked
							OutputDebugString("Clicked entire extractor node!\n");
							ExtractorNodeList[i].isPlaced = false; //make it free-floating again
							isNodeClicked = true;
							break;
						}
					}
				}
				for (int i = 0; i < ProcessNodeList.size(); i++){
					if (ProcessNodeList[i].isMouseOverNode(mouseX, mouseY)){ //we are over the node!
						isNodeClicked = true;
						if (ProcessNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && ProcessNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && !ProcessNodeList[i].unlockSize){ //we know this is not due to nodes being clicked
							OutputDebugString("Clicked entire process node!\n");
							ProcessNodeList[i].isPlaced = false; //make it free-floating again
							break;
						}
					}
				}
				for (int i = 0; i < ConsumerNodeList.size(); i++){
					if (ConsumerNodeList[i].isMouseOverNode(mouseX, mouseY)){ //we are within bounds
						isNodeClicked = true;
						if (ConsumerNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && ConsumerNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && !ConsumerNodeList[i].unlockSize){ //we know this is not due to nodes being clicked
							OutputDebugString("Clicked entire consumer node!\n");
							ConsumerNodeList[i].isPlaced = false; //make it free-floating again
							isNodeClicked = true;
							break;
						}
					}
				}
				for (int i = 0; i < StorageNodeList.size(); i++){
					if (StorageNodeList[i].isMouseOverNode(mouseX, mouseY)){ //we are within bounds
						isNodeClicked = true;
						if (StorageNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && StorageNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && !StorageNodeList[i].unlockSize){ //we know this is not due to nodes being clicked
							OutputDebugString("Clicked entire storage node!\n");
							StorageNodeList[i].isPlaced = false; //make it free-floating again
							break;
						}
					}
				}
				if (!isNodeClicked){ //if none of the nodes have been clicked on....
					//reset/deselect everything!
					resourceNodeSelected = -1;
					resourceForwardsConnectionClicked = -1;
					extractorNodeSelected = -1;
					extractorBackwardsConnectionClicked = -1;
					extractorForwardsConnectionClicked = -1;
					processNodeSelected = -1;
					processForwardsConnectionClicked = -1;
					processBackwardsConnectionClicked = -1;
					consumerNodeSelected = -1;
					consumerForwardsConnectionClicked = -1;
					consumerBackwardsConnectionClicked = -1;
					storageNodeSelected = -1;
					storageForwardsConnectionClicked = -1;
					storageBackwardsConnectionClicked = -1;
					commentSelected = -1;
					for (int i = 0; i < CommentsList.size(); i++) {
						CommentsList[i].isEditing = false;
					}
					//and now remove any disconnected arcs (etc)
					for (int i = 0; i < ResourceNodeList.size(); i++){
						ResourceNodeList[i].unlockSize = false; //Finish any resizing operations
						for (int j = 0; j < ResourceNodeList[i].forwardsConnectionPointsList.size(); j++){
							ResourceNodeList[i].forwardsConnectionPointsList[j].unsetUnconnectedArc(); //remove any disconnected arcs
						}
					}
					for (int i = 0; i < ExtractorNodeList.size(); i++){ //Remove any extractor node related free-floating connections
						ExtractorNodeList[i].unlockSize = false; //Finish any resizing operations
						for (int j = 0; j < ExtractorNodeList[i].forwardsConnectionPointsList.size(); j++){ //do it for forwards connections
							ExtractorNodeList[i].forwardsConnectionPointsList[j].unsetUnconnectedArc();
						}
						for (int j = 0; j < ExtractorNodeList[i].backwardsConnectionPointsList.size(); j++){//do it for backwards connections too
							ExtractorNodeList[i].backwardsConnectionPointsList[j].unsetUnconnectedArc();
						}
					}
					for (int i = 0; i < ConsumerNodeList.size(); i++){
						ConsumerNodeList[i].unlockSize = false; //Finish any resizing operations
						for (int j = 0; j < ConsumerNodeList[i].forwardsConnectionPointsList.size(); j++){
							ConsumerNodeList[i].forwardsConnectionPointsList[j].unsetUnconnectedArc();
						}
						for (int j = 0; j < ConsumerNodeList[i].backwardsConnectionPointsList.size(); j++){
							ConsumerNodeList[i].backwardsConnectionPointsList[j].unsetUnconnectedArc();
						}
					}
					for (int i = 0; i < ProcessNodeList.size(); i++){
						ProcessNodeList[i].unlockSize = false; //Finish any resizing operations
						for (int j = 0; j < ProcessNodeList[i].forwardsConnectionPointsList.size(); j++){
							ProcessNodeList[i].forwardsConnectionPointsList[j].unsetUnconnectedArc();
						}
						for (int j = 0; j < ProcessNodeList[i].backwardsConnectionPointsList.size(); j++){
							ProcessNodeList[i].backwardsConnectionPointsList[j].unsetUnconnectedArc();
						}
					}
					for (int i = 0; i < StorageNodeList.size(); i++){
						StorageNodeList[i].unlockSize = false; //Finish any resizing operations
						for (int j = 0; j < StorageNodeList[i].forwardsConnectionPointsList.size(); j++){
							StorageNodeList[i].forwardsConnectionPointsList[j].unsetUnconnectedArc();
						}
						for (int j = 0; j < StorageNodeList[i].backwardsConnectionPointsList.size(); j++){
							StorageNodeList[i].backwardsConnectionPointsList[j].unsetUnconnectedArc();
						}
					}
				}
			}
		}
		break;

		//when the right mouse button has been released from inside the flowchart window:
		case WM_RBUTTONUP:
		{
			//First, we reset everything!
			resourceNodeSelected = -1;
			resourceForwardsConnectionClicked = -1;
			extractorNodeSelected = -1;
			extractorForwardsConnectionClicked = -1;
			extractorBackwardsConnectionClicked = -1;
			processNodeSelected = -1;
			processForwardsConnectionClicked = -1;
			processBackwardsConnectionClicked = -1;
			consumerNodeSelected = -1;
			consumerForwardsConnectionClicked = -1;
			consumerBackwardsConnectionClicked = -1;
			storageNodeSelected = -1;
			storageForwardsConnectionClicked = -1;
			storageBackwardsConnectionClicked = -1;
			commentSelected = -1;
			HMENU hPopupMenu = CreatePopupMenu(); //set up the right-click menu we shall be using
			HMENU hPopupSubmenu = CreatePopupMenu(); //create the sub menu that may be used.
			POINT screenCursorPos;
			GetCursorPos(&screenCursorPos); //get the cursor position in screen co-ords
			if (!isAnyNodesFloating()){ //check no nodes are already being shifted around
				//deal with any resource nodes being right-clicked
				for (int i = 0; i < ResourceNodeList.size(); i++){
					if (ResourceNodeList[i].isConnectionNodeClicked(mouseX, mouseY, false) == -1){ //we know connections are not being clicked
						if (ResourceNodeList[i].isMouseOverNode(mouseX, mouseY)){ //if the mouse is over the node!
							OutputDebugString("Resource Node has been right clicked!\n");
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_REMOVE_RESOURCE, "Delete Resource Node");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_ADD_F_CONNECTION, "Add Forwards Connection");
							InsertMenu(hPopupMenu, 2, MF_BYPOSITION | MF_STRING | MF_GRAYED, RCM_ADD_B_CONNECTION, "Add Backwards Connection");
							InsertMenu(hPopupMenu, 3, MF_BYPOSITION | MF_STRING, RCM_NODE_PROPERTIES, "Node Properties");
							AppendMenu(hPopupMenu, MF_BYPOSITION | MF_POPUP, (UINT_PTR)hPopupSubmenu, "Resize Node");
							InsertMenu(hPopupSubmenu, 1, MF_BYPOSITION | MF_STRING, RCM_UNLOCK_NODE, "Freehand");
							InsertMenu(hPopupSubmenu, 2, MF_BYPOSITION | MF_STRING, RCM_FIT_TO_TEXT, "Fit to text (singleline)");
							InsertMenu(hPopupSubmenu, 3, MF_BYPOSITION | MF_STRING, RCM_FIT_TO_TEXT_MULTI, "Fit to text (multiline)");
							InsertMenu(hPopupSubmenu, 4, MF_BYPOSITION | MF_STRING, RCM_RESET_NODE_SIZE, "Reset size");
							if (ResourceNodeList[i].showTitle) {
								InsertMenu(hPopupMenu, 4, MF_BYPOSITION | MF_STRING | MF_CHECKED, RCM_TOGGLE_NODE_TITLE, "Show/Hide Title");
							}
							else {
								InsertMenu(hPopupMenu, 4, MF_BYPOSITION | MF_STRING, RCM_TOGGLE_NODE_TITLE, "Show/Hide Title");
							}
							resourceNodeSelected = i; //define which resource node it is we want to remove (randomly guessing *will* annoy end users!)
							break; //we have done what we set out to. Now leave! Before anything unintended happens!
						}
					}
					else{ //if connections *are* being right-clicked
						OutputDebugString("Resource Node Connection has been right clicked!\n");
						if (ResourceNodeList[i].isConnectionNodeClicked(mouseX, mouseY, false) != -1){
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_DISCONNECT_F_NODE, "Disconnect");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_DEL_F_CONNECTION, "Remove Forwards Connector");
						}
						InsertMenu(hPopupMenu, 2, MF_BYPOSITION | MF_STRING, RCM_ADD_F_CONNECTION, "Add Forwards Connection");
						InsertMenu(hPopupMenu, 3, MF_BYPOSITION | MF_STRING | MF_GRAYED, RCM_ADD_B_CONNECTION, "Add Backwards Connector");

						//setup this node, and reset all the others to make it foolproof against bugs!
						resourceNodeSelected = i;
						resourceForwardsConnectionClicked = ResourceNodeList[i].isConnectionNodeClicked(mouseX, mouseY, false);
						extractorNodeSelected = -1;
						extractorForwardsConnectionClicked = -1;
						extractorBackwardsConnectionClicked = -1;
						processNodeSelected = -1;
						processForwardsConnectionClicked = -1;
						processBackwardsConnectionClicked = -1;
						consumerNodeSelected = -1;
						consumerForwardsConnectionClicked = -1;
						consumerBackwardsConnectionClicked = -1;
						storageNodeSelected = -1;
						storageForwardsConnectionClicked = -1;
						storageBackwardsConnectionClicked = -1;
					}
				}
				//Deal with any extractor nodes being right clicked!
				for (int i = 0; i < ExtractorNodeList.size(); i++){
					if (ExtractorNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && ExtractorNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) == -1){ //we know connections are not being clicked
						if (ExtractorNodeList[i].isMouseOverNode(mouseX, mouseY)){ //we are over the node
							OutputDebugString("Extractor Node has been right clicked!\n");
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_REMOVE_EXTRACTOR, "Delete Extractor Node");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_ADD_F_CONNECTION, "Add Forwards Connection");
							InsertMenu(hPopupMenu, 2, MF_BYPOSITION | MF_STRING, RCM_ADD_B_CONNECTION, "Add Backwards Connection");
							InsertMenu(hPopupMenu, 3, MF_BYPOSITION | MF_STRING, RCM_NODE_PROPERTIES, "Node Properties");
							AppendMenu(hPopupMenu, MF_BYPOSITION | MF_POPUP, (UINT_PTR)hPopupSubmenu, "Resize Node");
							InsertMenu(hPopupSubmenu, 1, MF_BYPOSITION | MF_STRING, RCM_UNLOCK_NODE, "Freehand");
							InsertMenu(hPopupSubmenu, 2, MF_BYPOSITION | MF_STRING, RCM_FIT_TO_TEXT, "Fit to text (singleline)");
							InsertMenu(hPopupSubmenu, 3, MF_BYPOSITION | MF_STRING, RCM_FIT_TO_TEXT_MULTI, "Fit to text (multiline)");
							InsertMenu(hPopupSubmenu, 4, MF_BYPOSITION | MF_STRING, RCM_RESET_NODE_SIZE, "Reset size");
							if (ExtractorNodeList[i].showTitle) {
								InsertMenu(hPopupMenu, 4, MF_BYPOSITION | MF_STRING | MF_CHECKED, RCM_TOGGLE_NODE_TITLE, "Show/Hide Title");
							}
							else {
								InsertMenu(hPopupMenu, 4, MF_BYPOSITION | MF_STRING, RCM_TOGGLE_NODE_TITLE, "Show/Hide Title");
							}
							extractorNodeSelected = i; //define which resource node it is we want to remove (randomly guessing *will* annoy end users!)
							break; //we have done what we set out to. Now leave! Before anything unintended happens!
						}
					}
					else{ //if connection nodes *are* being right-clicked
						OutputDebugString("Extractor Node Connection has been right clicked!\n");
						if (ExtractorNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) != -1){
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_DISCONNECT_F_NODE, "Disconnect");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_DEL_F_CONNECTION, "Remove forwards connector");
						}
						else if (ExtractorNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) != -1){
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_DISCONNECT_B_NODE, "Disconnect");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_DEL_B_CONNECTION, "Remove backwards connector");
						}
						InsertMenu(hPopupMenu, 2, MF_BYPOSITION | MF_STRING, RCM_ADD_F_CONNECTION, "Add Forwards Connection");
						InsertMenu(hPopupMenu, 3, MF_BYPOSITION | MF_STRING, RCM_ADD_B_CONNECTION, "Add Backwards Connection");

						//make sure all the others are reset!
						resourceNodeSelected = -1;
						resourceForwardsConnectionClicked = -1;
						//setup the correct extractor nodes
						extractorNodeSelected = i;
						extractorForwardsConnectionClicked = ExtractorNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false);
						extractorBackwardsConnectionClicked = ExtractorNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false); //deal with both at the same time, since they should neevr both != -1
						processNodeSelected = -1;
						processForwardsConnectionClicked = -1;
						processBackwardsConnectionClicked = -1;
						consumerNodeSelected = -1;
						consumerForwardsConnectionClicked = -1;
						consumerBackwardsConnectionClicked = -1;
						storageNodeSelected = -1;
						storageForwardsConnectionClicked = -1;
						storageBackwardsConnectionClicked = -1;
					}
				}
				//Now deal with any process nodes being right clicked!
				for (int i = 0; i < ProcessNodeList.size(); i++){
					if (ProcessNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && ProcessNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) == -1){ //we know connections are not being clicked
						if (ProcessNodeList[i].isMouseOverNode(mouseX, mouseY)){ //we are over the node!
							OutputDebugString("Process Node has been right clicked!\n");
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_REMOVE_INDUSTRIAL, "Delete Process Node");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_ADD_F_CONNECTION, "Add Forwards Connection");
							InsertMenu(hPopupMenu, 2, MF_BYPOSITION | MF_STRING, RCM_ADD_B_CONNECTION, "Add Backwards Connection");
							InsertMenu(hPopupMenu, 3, MF_BYPOSITION | MF_STRING, RCM_NODE_PROPERTIES, "Node Properties");
							AppendMenu(hPopupMenu, MF_BYPOSITION | MF_POPUP, (UINT_PTR)hPopupSubmenu, "Resize Node");
							InsertMenu(hPopupSubmenu, 1, MF_BYPOSITION | MF_STRING, RCM_UNLOCK_NODE, "Freehand");
							InsertMenu(hPopupSubmenu, 2, MF_BYPOSITION | MF_STRING, RCM_FIT_TO_TEXT, "Fit to text (singleline)");
							InsertMenu(hPopupSubmenu, 3, MF_BYPOSITION | MF_STRING, RCM_FIT_TO_TEXT_MULTI, "Fit to text (multiline)");
							InsertMenu(hPopupSubmenu, 4, MF_BYPOSITION | MF_STRING, RCM_RESET_NODE_SIZE, "Reset size");
							if (ProcessNodeList[i].showTitle) {
								InsertMenu(hPopupMenu, 4, MF_BYPOSITION | MF_STRING | MF_CHECKED, RCM_TOGGLE_NODE_TITLE, "Show/Hide Title");
							}
							else {
								InsertMenu(hPopupMenu, 4, MF_BYPOSITION | MF_STRING, RCM_TOGGLE_NODE_TITLE, "Show/Hide Title");
							}
							processNodeSelected = i; //define which resource node it is we want to remove
							break; //we have done what we set out to. Now leave! Before anything unintended happens!
						}
					}
					else{ //if connection nodes *are* being right-clicked
						OutputDebugString("Process Node Connection has been right clicked!\n");
						if (ProcessNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) != -1){
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_DISCONNECT_F_NODE, "Disconnect");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_DEL_F_CONNECTION, "Remove forwards connector");
						}
						else if (ProcessNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) != -1){
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_DISCONNECT_B_NODE, "Disconnect");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_DEL_B_CONNECTION, "Remove backwards connector");
						}
						InsertMenu(hPopupMenu, 2, MF_BYPOSITION | MF_STRING, RCM_ADD_F_CONNECTION, "Add Forwards Connection");
						InsertMenu(hPopupMenu, 3, MF_BYPOSITION | MF_STRING, RCM_ADD_B_CONNECTION, "Add Backwards Connection");

						//make sure all the others are reset!
						resourceNodeSelected = -1;
						resourceForwardsConnectionClicked = -1;
						extractorNodeSelected = -1;
						extractorForwardsConnectionClicked = -1;
						extractorBackwardsConnectionClicked = -1;
						//setup the correct process nodes
						processNodeSelected = i;
						processForwardsConnectionClicked = ProcessNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false); //deal with both at the same time, since they should neevr both != -1
						processBackwardsConnectionClicked = ProcessNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false);
						consumerNodeSelected = -1;
						consumerForwardsConnectionClicked = -1;
						consumerBackwardsConnectionClicked = -1;
						storageNodeSelected = -1;
						storageForwardsConnectionClicked = -1;
						storageBackwardsConnectionClicked = -1;
					}
				}
				//Now deal with consumer nodes being right clicked!
				for (int i = 0; i < ConsumerNodeList.size(); i++){
					if (ConsumerNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && ConsumerNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) == -1){ //we know connections are not being clicked
						if (ConsumerNodeList[i].isMouseOverNode(mouseX, mouseY)){ //we are within x bounds
							OutputDebugString("Consumer Node has been right clicked!\n");
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_REMOVE_CONSUMER, "Delete Consumer Node");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_ADD_F_CONNECTION, "Add Forwards Connector");
							InsertMenu(hPopupMenu, 2, MF_BYPOSITION | MF_STRING, RCM_ADD_B_CONNECTION, "Add Backwards Connector");
							InsertMenu(hPopupMenu, 3, MF_BYPOSITION | MF_STRING, RCM_NODE_PROPERTIES, "Node Properties");
							AppendMenu(hPopupMenu, MF_BYPOSITION | MF_POPUP, (UINT_PTR)hPopupSubmenu, "Resize Node");
							InsertMenu(hPopupSubmenu, 1, MF_BYPOSITION | MF_STRING, RCM_UNLOCK_NODE, "Freehand");
							InsertMenu(hPopupSubmenu, 2, MF_BYPOSITION | MF_STRING, RCM_FIT_TO_TEXT, "Fit to text (singleline)");
							InsertMenu(hPopupSubmenu, 3, MF_BYPOSITION | MF_STRING, RCM_FIT_TO_TEXT_MULTI, "Fit to text (multiline)");
							InsertMenu(hPopupSubmenu, 4, MF_BYPOSITION | MF_STRING, RCM_RESET_NODE_SIZE, "Reset size");
							if (ConsumerNodeList[i].showTitle) {
								InsertMenu(hPopupMenu, 4, MF_BYPOSITION | MF_STRING | MF_CHECKED, RCM_TOGGLE_NODE_TITLE, "Show/Hide Title");
							}
							else {
								InsertMenu(hPopupMenu, 4, MF_BYPOSITION | MF_STRING, RCM_TOGGLE_NODE_TITLE, "Show/Hide Title");
							}
							consumerNodeSelected = i; //define which resource node it is we want to remove
							break; //we have done what we set out to. Now leave! Before anything unintended happens!
						}
					}
					else{ //if connection nodes *are* being right-clicked
						OutputDebugString("Consumer Node Connection has been right clicked!\n");
						if (ConsumerNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) != -1){
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_DISCONNECT_F_NODE, "Disconnect");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_DEL_F_CONNECTION, "Remove forwards connector");
						}
						else if (ConsumerNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) != -1){
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_DISCONNECT_B_NODE, "Disconnect");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_DEL_B_CONNECTION, "Remove backwards connector");
						}
						InsertMenu(hPopupMenu, 2, MF_BYPOSITION | MF_STRING, RCM_ADD_F_CONNECTION, "Add Forwards Connection");
						InsertMenu(hPopupMenu, 3, MF_BYPOSITION | MF_STRING, RCM_ADD_B_CONNECTION, "Add Backwards Connection");

						//make sure all the others are reset!
						resourceNodeSelected = -1;
						resourceForwardsConnectionClicked = -1;
						extractorNodeSelected = -1;
						extractorForwardsConnectionClicked = -1;
						extractorBackwardsConnectionClicked = -1;
						processNodeSelected = -1;
						processForwardsConnectionClicked = -1;
						processBackwardsConnectionClicked = -1;
						// setup the correct process nodes
						consumerNodeSelected = i;
						consumerForwardsConnectionClicked = ConsumerNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false); //deal with both at the same time, since they should neevr both != -1
						consumerBackwardsConnectionClicked = ConsumerNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false);
						//and the rest...
						storageNodeSelected = -1;
						storageForwardsConnectionClicked = -1;
						storageBackwardsConnectionClicked = -1;
					}
				}
				//Finally, deal with any storage nodes being right-clicked
				for (int i = 0; i < StorageNodeList.size(); i++){
					if (StorageNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) == -1 && StorageNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) == -1){ //we know connections are not being clicked
						if (StorageNodeList[i].isMouseOverNode(mouseX, mouseY)){ //we are within x bounds
							OutputDebugString("Storage Node has been right clicked!\n");
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_REMOVE_STORAGE, "Delete Storage Node");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_ADD_F_CONNECTION, "Add Forwards Connection");
							InsertMenu(hPopupMenu, 2, MF_BYPOSITION | MF_STRING, RCM_ADD_B_CONNECTION, "Add Backwards Connection");
							InsertMenu(hPopupMenu, 3, MF_BYPOSITION | MF_STRING, RCM_NODE_PROPERTIES, "Node Properties");
							AppendMenu(hPopupMenu, MF_BYPOSITION | MF_POPUP, (UINT_PTR)hPopupSubmenu, "Resize Node");
							InsertMenu(hPopupSubmenu, 1, MF_BYPOSITION | MF_STRING, RCM_UNLOCK_NODE, "Freehand");
							InsertMenu(hPopupSubmenu, 2, MF_BYPOSITION | MF_STRING, RCM_FIT_TO_TEXT, "Fit to text (singleline)");
							InsertMenu(hPopupSubmenu, 3, MF_BYPOSITION | MF_STRING, RCM_FIT_TO_TEXT_MULTI, "Fit to text (multiline)");
							InsertMenu(hPopupSubmenu, 4, MF_BYPOSITION | MF_STRING, RCM_RESET_NODE_SIZE, "Reset size");
							if (StorageNodeList[i].showTitle) {
								InsertMenu(hPopupMenu, 4, MF_BYPOSITION | MF_STRING | MF_CHECKED, RCM_TOGGLE_NODE_TITLE, "Show/Hide Title");
							}
							else {
								InsertMenu(hPopupMenu, 4, MF_BYPOSITION | MF_STRING, RCM_TOGGLE_NODE_TITLE, "Show/Hide Title");
							}
							storageNodeSelected = i; //define which resource node it is we want to remove
							break; //we have done what we set out to. Now leave! Before anything unintended happens!
						}
					}
					else{ //if connection nodes *are* being right-clicked
						OutputDebugString("Storage Node Connection has been right clicked!\n");
						if (StorageNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false) != -1){
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_DISCONNECT_F_NODE, "Disconnect");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_DEL_F_CONNECTION, "Remove forwards connector");
						}
						else if (StorageNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false) != -1){
							InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_DISCONNECT_B_NODE, "Disconnect");
							InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_DEL_B_CONNECTION, "Remove backwards connector");
						}
						InsertMenu(hPopupMenu, 2, MF_BYPOSITION | MF_STRING, RCM_ADD_F_CONNECTION, "Add Forwards Connection");
						InsertMenu(hPopupMenu, 3, MF_BYPOSITION | MF_STRING, RCM_ADD_B_CONNECTION, "Add Backwards Connection");

						//make sure all the others are reset!
						resourceNodeSelected = -1;
						resourceForwardsConnectionClicked = -1;
						extractorNodeSelected = -1;
						extractorForwardsConnectionClicked = -1;
						extractorBackwardsConnectionClicked = -1;
						processNodeSelected = -1;
						processForwardsConnectionClicked = -1;
						processBackwardsConnectionClicked = -1;
						consumerNodeSelected = -1;
						consumerForwardsConnectionClicked = -1;
						consumerBackwardsConnectionClicked = -1;
						// setup the correct storage nodes
						storageNodeSelected = i;
						storageForwardsConnectionClicked = StorageNodeList[i].isForwardsConnectionNodeClicked(mouseX, mouseY, false); //deal with both at the same time, since they should never both != -1
						storageBackwardsConnectionClicked = StorageNodeList[i].isBackwardsConnectionNodeClicked(mouseX, mouseY, false);
					}
				}
			}

			if (resourceNodeSelected == -1 && extractorNodeSelected == -1 && processNodeSelected == -1 && consumerNodeSelected == -1 && storageNodeSelected == -1){ //if no nodes have been selected, we must have clicked on unoccupied space...
				//First check to see if any arcs have been right clicked
				bool isArcRightClicked = false;
				bool isCommentRightClicked = false;
				for (int i = 0; i < CommentsList.size(); i++) {
					if (CommentsList[i].isMouseOverComment(float(mouseX), float(mouseY))) { //if the mouse is over a node...
						OutputDebugString("Comment right clicked!");
						commentSelected = i;
						isCommentRightClicked = true; //make sure nothing else happens... this will also cause the comment menu to be drawn further down (don't panic, it's not witchcraft! Just bad programming!)
						break;
					}
				}
				for (int i = 0; i < ResourceNodeList.size() && !isCommentRightClicked; i++){
					if (ResourceNodeList[i].isMouseOverArc != -1){
						isArcRightClicked = true;
						//and now do our standard resets
						resourceNodeSelected = i;
						resourceForwardsConnectionClicked = ResourceNodeList[i].isMouseOverArc;
						extractorNodeSelected = -1;
						extractorForwardsConnectionClicked = -1;
						extractorBackwardsConnectionClicked = -1;
						processNodeSelected = -1;
						processForwardsConnectionClicked = -1;
						consumerNodeSelected = -1;
						consumerForwardsConnectionClicked = -1;
						consumerBackwardsConnectionClicked = -1;
						storageNodeSelected = -1;
						storageForwardsConnectionClicked = -1;
						storageBackwardsConnectionClicked = -1;
						commentSelected = -1;
						break; //Don't check for any more. This is a first-come, first-served operation!
					}
				}
				if (!isArcRightClicked && !isCommentRightClicked){ //check the resource node hasn't grabbed all the glory
					for (int i = 0; i < ExtractorNodeList.size(); i++){ //now check the extractor node's forwards connections...
						if (ExtractorNodeList[i].isMouseOverArc != -1){
							isArcRightClicked = true;
							resourceNodeSelected = -1;
							resourceForwardsConnectionClicked = -1;
							extractorNodeSelected = i;
							extractorForwardsConnectionClicked = ExtractorNodeList[i].isMouseOverArc;
							extractorBackwardsConnectionClicked = -1;
							processNodeSelected = -1;
							processForwardsConnectionClicked = -1;
							consumerNodeSelected = -1;
							consumerForwardsConnectionClicked = -1;
							consumerBackwardsConnectionClicked = -1;
							storageNodeSelected = -1;
							storageForwardsConnectionClicked = -1;
							storageBackwardsConnectionClicked = -1;
							commentSelected = -1;
							break; //and leave
						}
					}
				}
				if (!isArcRightClicked && !isCommentRightClicked){
					for (int i = 0; i < ProcessNodeList.size(); i++){ //now check the process node's forwards connections...
						if (ProcessNodeList[i].isMouseOverArc != -1){
							isArcRightClicked = true;
							//...again...
							resourceNodeSelected = -1;
							resourceForwardsConnectionClicked = -1;
							extractorNodeSelected = -1;
							extractorForwardsConnectionClicked = -1;
							extractorBackwardsConnectionClicked = -1;
							processNodeSelected = i;
							processForwardsConnectionClicked = ProcessNodeList[i].isMouseOverArc;
							consumerNodeSelected = -1;
							consumerForwardsConnectionClicked = -1;
							consumerBackwardsConnectionClicked = -1;
							storageNodeSelected = -1;
							storageForwardsConnectionClicked = -1;
							storageBackwardsConnectionClicked = -1;
							commentSelected = -1;
							break; //and break
						}
					}
				}
				if (!isArcRightClicked && !isCommentRightClicked){
					for (int i = 0; i < ConsumerNodeList.size(); i++){ //now check the consumer node's forwards connections...
						if (ConsumerNodeList[i].isMouseOverArc != -1){
							isArcRightClicked = true;
							//Anybody care to work out the maximum number of times this can occur in a frame?
							resourceNodeSelected = -1;
							resourceForwardsConnectionClicked = -1;
							extractorNodeSelected = -1;
							extractorForwardsConnectionClicked = -1;
							extractorBackwardsConnectionClicked = -1;
							processNodeSelected = -1;
							processForwardsConnectionClicked = -1;
							consumerNodeSelected = i;
							consumerForwardsConnectionClicked = ConsumerNodeList[i].isMouseOverArc;
							consumerBackwardsConnectionClicked = -1;
							storageNodeSelected = -1;
							storageForwardsConnectionClicked = -1;
							storageBackwardsConnectionClicked = -1;
							commentSelected = -1;
							break; //and leave
						}
					}
				}
				if (!isArcRightClicked && !isCommentRightClicked){
					for (int i = 0; i < StorageNodeList.size(); i++){ //now check the storage node's forwards connections...
						if (StorageNodeList[i].isMouseOverArc != -1){
							isArcRightClicked = true;
							//<\NerdSnipe>
							resourceNodeSelected = -1;
							resourceForwardsConnectionClicked = -1;
							extractorNodeSelected = -1;
							extractorForwardsConnectionClicked = -1;
							extractorBackwardsConnectionClicked = -1;
							processNodeSelected = -1;
							processForwardsConnectionClicked = -1;
							consumerNodeSelected = -1;
							consumerForwardsConnectionClicked = -1;
							consumerBackwardsConnectionClicked = -1;
							storageNodeSelected = i;
							storageForwardsConnectionClicked = StorageNodeList[i].isMouseOverArc;
							storageBackwardsConnectionClicked = -1;
							commentSelected = -1;
							break; //and leave
						}
					}
				}
				if (!isArcRightClicked && !isCommentRightClicked){
					AppendMenu(hPopupMenu, MF_POPUP, (UINT_PTR)hPopupSubmenu, "Add New Node");
					InsertMenu(hPopupSubmenu, 1, MF_BYPOSITION | MF_STRING, RCM_REQ_RESOURCE, "Resource Node");
					InsertMenu(hPopupSubmenu, 2, MF_BYPOSITION | MF_STRING, RCM_REQ_EXTRACTOR, "Extractor Node");
					InsertMenu(hPopupSubmenu, 3, MF_BYPOSITION | MF_STRING, RCM_REQ_PROCESS, "Process Node");
					InsertMenu(hPopupSubmenu, 4, MF_BYPOSITION | MF_STRING, RCM_REQ_CONSUMER, "Consumer Node");
					InsertMenu(hPopupSubmenu, 5, MF_BYPOSITION | MF_STRING, RCM_REQ_STORAGE, "Storage Node");
					InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_ADD_COMMENT, "Insert Comment Box");
				}
				else if(!isCommentRightClicked){ //draw the arc edit menu
					InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_DISCONNECT_F_NODE, "Remove arc");
					AppendMenu(hPopupMenu, MF_POPUP, (UINT_PTR)hPopupSubmenu, "Change arc style");
					InsertMenu(hPopupSubmenu, 0, MF_BYPOSITION | MF_STRING, RCM_ARC_DEFAULT, "Default");
					InsertMenu(hPopupSubmenu, 1, MF_BYPOSITION | MF_STRING, RCM_ARC_LINEAR, "Linear");
					InsertMenu(hPopupSubmenu, 2, MF_BYPOSITION | MF_STRING, RCM_ARC_SPLINE, "Bezier");
					InsertMenu(hPopupSubmenu, 3, MF_BYPOSITION | MF_STRING, RCM_ARC_PERP, "Perpendicular");
					InsertMenu(hPopupSubmenu, 4, MF_BYPOSITION | MF_STRING, RCM_ARC_CUSTOM, "Custom");
				}
				else if(isCommentRightClicked){ //draw the comment edit menu
					InsertMenu(hPopupMenu, 0, MF_BYPOSITION | MF_STRING, RCM_DEL_COMMENT, "Delete Comment");
					InsertMenu(hPopupMenu, 1, MF_BYPOSITION | MF_STRING, RCM_UNLOCK_COMMENT, "Unlock sizing");
					InsertMenu(hPopupMenu, 2, MF_BYPOSITION | MF_STRING, RCM_EDIT_COMMENT, "Edit Comment");
					InsertMenu(hPopupMenu, 3, MF_BYPOSITION | MF_STRING, RCM_ASSOCIATE_COMMENT, "Associate with Node(s)");
				}
			}
			//draw the menu as composed!
			//SetForegroundWindow(hWnd);
			TrackPopupMenu(hPopupMenu, TPM_TOPALIGN | TPM_LEFTALIGN, screenCursorPos.x, screenCursorPos.y, 0, hWnd, NULL);
			DeleteMenu(hPopupMenu, NULL, NULL);
			DeleteMenu(hPopupSubmenu, NULL, NULL);
		}
		break;

		case WM_VSCROLL: //if vertical scrolling happens
		{
			switch (LOWORD(wParam))
			{
			case SB_THUMBPOSITION: case SB_THUMBTRACK:
			{
				SCROLLINFO si = { sizeof(si), SIF_ALL};
				GetScrollInfo(hWnd, SB_VERT, &si);
				if (si.nPos >= si.nMax - si.nPage - 1) { //if we hit the end of the scrollbar
					SetScrollRange(hWnd, SB_VERT, int(si.nMin), int(si.nMax*1.05), TRUE); //expand our scroll range!
				}
				SetScrollPos(hWnd, SB_VERT, si.nTrackPos, TRUE);
			}
			break;
			case SB_LINEUP:
			{
				SCROLLINFO si = { sizeof(si), SIF_ALL };
				GetScrollInfo(hWnd, SB_VERT, &si);
				SetScrollPos(hWnd, SB_VERT, si.nPos-15, TRUE);
			}
			break;
			case SB_LINEDOWN:
			{
				SCROLLINFO si = { sizeof(si), SIF_ALL };
				GetScrollInfo(hWnd, SB_VERT, &si);
				SetScrollPos(hWnd, SB_VERT, si.nPos + 15, TRUE);
			}
			break;
			}
		}
		break;

		case WM_HSCROLL: //if horizontal scrolling happens
		{
			switch (LOWORD(wParam))
			{
			case SB_THUMBPOSITION: case SB_THUMBTRACK: //if scrolling the actual thumb has been responsible
			{
				SCROLLINFO si = { sizeof(si), SIF_ALL };
				GetScrollInfo(hWnd, SB_HORZ, &si);
				if (si.nPos >= si.nMax - si.nPage - 1) { //if we hit the end of the scrollbar
					SetScrollRange(hWnd, SB_HORZ, int(si.nMin), int(si.nMax*1.05), TRUE); //expand our scroll range!
				}
				SetScrollPos(hWnd, SB_HORZ, si.nTrackPos, TRUE);
			}
			break;
			case SB_LINELEFT:
			{
				SCROLLINFO si = { sizeof(si), SIF_ALL };
				GetScrollInfo(hWnd, SB_HORZ, &si);
				SetScrollPos(hWnd, SB_HORZ, si.nPos + 15, TRUE);
			}
			break;
			case SB_LINERIGHT:
			{
				SCROLLINFO si = { sizeof(si), SIF_ALL };
				GetScrollInfo(hWnd, SB_HORZ, &si);
				SetScrollPos(hWnd, SB_HORZ, si.nPos - 15, TRUE);
			}
			break;
			}
		}
		break;

		//Now deal with command codes we've been sent
		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				//See what the zoom buttons have been up to...
				case IDC_ZOOM_IN:
				{
					zoomFactor *= float(1.05);
				}
				break;
				case IDC_ZOOM_OUT:
				{
					zoomFactor /= float(1.05);
				}
				break;
				//if the right-click menu has fired off any node creation events...
				case RCM_REQ_RESOURCE:
				{
					SendMessage(mainWindowHWND, WM_COMMAND, IDC_REQ_RESOURCE, 0); //fire off the releavnt message to the main window!
				}
				break;
				case RCM_REQ_EXTRACTOR:
				{
					SendMessage(mainWindowHWND, WM_COMMAND, IDC_REQ_EXTRACTOR, 0); //ditto for extractor node
				}
				break;
				case RCM_REQ_PROCESS:
				{
					SendMessage(mainWindowHWND, WM_COMMAND, IDC_REQ_INDUSTRIAL, 0);
				}
				break;
				case RCM_REQ_CONSUMER:
				{
					SendMessage(mainWindowHWND, WM_COMMAND, IDC_REQ_CONSUMER, 0);
				}
				break;
				case RCM_REQ_STORAGE:
				{
					SendMessage(mainWindowHWND, WM_COMMAND, IDC_REQ_STORAGE, 0);
				}
				break;
				case RCM_ADD_COMMENT:
				{
					OutputDebugString("Adding comment...\n");
					Comment newComment(hWnd, (float)mouseX, (float)mouseY, 16);
					CommentsList.push_back(newComment);
				}
				break;

				case RCM_REMOVE_RESOURCE: //if we have been tasked with removing a resource node
				{
					if (resourceNodeSelected >= 0 && resourceNodeSelected < ResourceNodeList.size()){ //Just make sure nothing stupid is happening...
						//disconnect all the nodes to prevent crashes
						for (int i = 0; i < ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList.size(); i++){
							if (ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[i].connectionsList.size() > 0){ //prevent a crash...
								ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[i].disconnectNode(0);
							}
						}
						ResourceNodeList.erase(ResourceNodeList.begin() + resourceNodeSelected); //remove the relevant node!
						resourceNodeSelected = -1; //and reset!
						resourceForwardsConnectionClicked = -1;
					}
				}
				break;

				case RCM_REMOVE_EXTRACTOR:
				{
					if (extractorNodeSelected >= 0 && extractorNodeSelected < ExtractorNodeList.size()){ //Just make sure nothing stupid is happening...
						//disconnect all the nodes to prevent crashes
						for (int i = 0; i < ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList.size(); i++){
							if (ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[i].connectionsList.size() > 0){
								ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[i].disconnectNode(0);
							}
						}
						for (int i = 0; i < ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList.size(); i++){
							if (ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[i].connectionsList.size() > 0){
								ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[i].disconnectNode(0); //and remove the backwards-facing nodes
							}
						}
						ExtractorNodeList.erase(ExtractorNodeList.begin() + extractorNodeSelected); //remove the relevant node!
						//and reset!
						extractorNodeSelected = -1;
						extractorForwardsConnectionClicked = -1;
						extractorBackwardsConnectionClicked = -1;
					}
				}
				break;

				case RCM_REMOVE_INDUSTRIAL:
				{
					if (processNodeSelected >= 0 && processNodeSelected < ProcessNodeList.size()){ //Just make sure nothing stupid is happenning...
						//disconnect all the nodes to prevent crashes
						for (int i = 0; i < ProcessNodeList[processNodeSelected].forwardsConnectionPointsList.size(); i++){
							if (ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[i].connectionsList.size() > 0){
								ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[i].disconnectNode(0);
							}
						}
						for (int i = 0; i < ProcessNodeList[processNodeSelected].backwardsConnectionPointsList.size(); i++){
							if (ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[i].connectionsList.size() > 0){
								ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[i].disconnectNode(0); //and remove the backwards-facing connections
							}
						}
						ProcessNodeList.erase(ProcessNodeList.begin() + processNodeSelected); //remove the relevant node!
						//and reset!
						processNodeSelected = -1;
						processForwardsConnectionClicked = -1;
						processBackwardsConnectionClicked = -1;
					}
				}
				break;

				case RCM_REMOVE_CONSUMER:
				{
					if (consumerNodeSelected >= 0 && consumerNodeSelected < ConsumerNodeList.size()){ //Just make sure nothing stupid is happenning...
						//disconnect all the nodes to prevent crashes
						for (int i = 0; i < ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList.size(); i++){
							if (ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[i].connectionsList.size() > 0){
								ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[i].disconnectNode(0); //remove the forwards-facing connections
							}
						}
						for (int i = 0; i < ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList.size(); i++){
							if (ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[i].connectionsList.size() > 0){
								ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[i].disconnectNode(0); //and remove the backwards-facing nodes
							}
						}
						ConsumerNodeList.erase(ConsumerNodeList.begin() + consumerNodeSelected); //remove the relevant node!
						//and reset!
						consumerNodeSelected = -1;
						consumerForwardsConnectionClicked = -1;
						consumerBackwardsConnectionClicked = -1;
					}
				}
				break;

				case RCM_REMOVE_STORAGE:
				{
					if (storageNodeSelected >= 0 && storageNodeSelected < StorageNodeList.size()){ //Just make sure nothing stupid is happenning...
						//disconnect all the nodes to prevent crashes
						for (int i = 0; i < StorageNodeList[storageNodeSelected].forwardsConnectionPointsList.size(); i++){
							if (StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[i].connectionsList.size() > 0){
								StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[i].disconnectNode(0); //remove the forwards-facing connections
							}
						}
						for (int i = 0; i < StorageNodeList[storageNodeSelected].backwardsConnectionPointsList.size(); i++){
							if (StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[i].connectionsList.size() > 0){
								StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[i].disconnectNode(0); //and remove the backwards-facing nodes
							}
						}
						StorageNodeList.erase(StorageNodeList.begin() + storageNodeSelected); //remove the relevant node!
						//and reset!
						storageNodeSelected = -1;
						storageForwardsConnectionClicked = -1;
						storageBackwardsConnectionClicked = -1;
					}
				}
				break;
				case RCM_UNLOCK_NODE: // unlock the size of the node so the user can scale it as desired
				{
					if (resourceNodeSelected != -1) {
						ResourceNodeList[resourceNodeSelected].unlockSize = true;
					}
					else if (extractorNodeSelected != -1) {
						ExtractorNodeList[extractorNodeSelected].unlockSize = true;
					}
					else if (processNodeSelected != -1) {
						ProcessNodeList[processNodeSelected].unlockSize = true;
					}
					else if (consumerNodeSelected != -1) {
						ConsumerNodeList[consumerNodeSelected].unlockSize = true;
					}
					else if (storageNodeSelected != -1) {
						StorageNodeList[storageNodeSelected].unlockSize = true;
					}
				}
				break;
				case RCM_FIT_TO_TEXT: //Shrink or expand the node so it will just enclose the text
				{
					if (resourceNodeSelected != -1) {
						ResourceNodeList[resourceNodeSelected].resize(1, hWnd);
					}
					else if (extractorNodeSelected != -1) {
						ExtractorNodeList[extractorNodeSelected].resize(1, hWnd);
					}
					else if (processNodeSelected != -1) {
						ProcessNodeList[processNodeSelected].resize(1, hWnd);
					}
					else if (consumerNodeSelected != -1) {
						ConsumerNodeList[consumerNodeSelected].resize(1, hWnd);
					}
					else if (storageNodeSelected != -1) {
						StorageNodeList[storageNodeSelected].resize(1, hWnd);
					}
				}
				break;
				case RCM_FIT_TO_TEXT_MULTI: //Engage the algorithm that will minimise the size of the node by optimising the number of lines the text is on
				{
					if (resourceNodeSelected != -1) {
						ResourceNodeList[resourceNodeSelected].resize(2, hWnd);
					}
					else if (extractorNodeSelected != -1) {
						ExtractorNodeList[extractorNodeSelected].resize(2, hWnd);
					}
					else if (processNodeSelected != -1) {
						ProcessNodeList[processNodeSelected].resize(2, hWnd);
					}
					else if (consumerNodeSelected != -1) {
						ConsumerNodeList[consumerNodeSelected].resize(2, hWnd);
					}
					else if (storageNodeSelected != -1) {
						StorageNodeList[storageNodeSelected].resize(2, hWnd);
					}
				}
				break;
				case RCM_RESET_NODE_SIZE:
				{
					if (resourceNodeSelected != -1) {
						ResourceNodeList[resourceNodeSelected].resize(0, hWnd);
					}
					else if (extractorNodeSelected != -1) {
						ExtractorNodeList[extractorNodeSelected].resize(0, hWnd);
					}
					else if (processNodeSelected != -1) {
						ProcessNodeList[processNodeSelected].resize(0,hWnd);
					}
					else if (consumerNodeSelected != -1) {
						ConsumerNodeList[consumerNodeSelected].resize(0, hWnd);
					}
					else if (storageNodeSelected != -1) {
						StorageNodeList[storageNodeSelected].resize(0, hWnd);
					}
				}
				break;

				//adding forwards connections
				case RCM_ADD_F_CONNECTION:
				{
					OutputDebugString("Case: add forwards connection from RCM\n");
					if (resourceNodeSelected != -1){ //must be the resource node we're complaining about
						ResourceNodeList[resourceNodeSelected].addForwardsConnection(resourceForwardsConnectionClicked + 1/**ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList.size()**/); //add a new point onto the end!
					}
					else if (extractorNodeSelected != -1){ //must be the extractor node
						ExtractorNodeList[extractorNodeSelected].addForwardsConnection(extractorForwardsConnectionClicked + 1/**ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList.size()**/); //add a new point onto the end!
					}
					else if (processNodeSelected != -1){ //process node
						ProcessNodeList[processNodeSelected].addForwardsConnection(processForwardsConnectionClicked + 1/**ProcessNodeList[processNodeSelected].forwardsConnectionPointsList.size()**/); //add a new point onto the end!
					}
					else if (consumerNodeSelected != -1){ //consumer node
						ConsumerNodeList[consumerNodeSelected].addForwardsConnection(consumerForwardsConnectionClicked + 1 /**ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList.size()**/); //add a new point onto the end!
					}
					else if (storageNodeSelected != -1){ //storage node
						StorageNodeList[storageNodeSelected].addForwardsConnection(storageForwardsConnectionClicked + 1 /**StorageNodeList[storageNodeSelected].forwardsConnectionPointsList.size()**/); //add a new point onto the end!
					}
					//and now make sure everything is deselected!
					resourceNodeSelected = -1;
					resourceForwardsConnectionClicked = -1;
					extractorNodeSelected = -1;
					extractorForwardsConnectionClicked = -1;
					extractorBackwardsConnectionClicked = -1;
					processNodeSelected = -1;
					processForwardsConnectionClicked = -1;
					processBackwardsConnectionClicked = -1;
					consumerNodeSelected = -1;
					consumerForwardsConnectionClicked = -1;
					consumerBackwardsConnectionClicked = -1;
					storageNodeSelected = -1;
					storageForwardsConnectionClicked = -1;
					storageBackwardsConnectionClicked = -1;
				}
				break;

				//adding backwards connections
				case RCM_ADD_B_CONNECTION:
				{
					OutputDebugString("Case: add backwards connection from RCM.\n");
					//remember the resource node does not have any backwards connections!
					if (extractorNodeSelected != -1){ //must be the extractor node
						ExtractorNodeList[extractorNodeSelected].addBackwardsConnection(extractorBackwardsConnectionClicked + 1 /**ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList.size()**/); //add a new point onto the end!
					}
					else if (processNodeSelected != -1){ //process node

						ProcessNodeList[processNodeSelected].addBackwardsConnection(processBackwardsConnectionClicked + 1/**ProcessNodeList[processNodeSelected].backwardsConnectionPointsList.size()**/); //add a new point onto the end!
					}
					else if (consumerNodeSelected != -1){ //consumer node
						ConsumerNodeList[consumerNodeSelected].addBackwardsConnection(consumerBackwardsConnectionClicked + 1/**ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList.size()**/); //add a new point onto the end!
					}
					else if (storageNodeSelected != -1){ //storage node
						OutputDebugString("Adding...\n");
						StorageNodeList[storageNodeSelected].addBackwardsConnection(storageBackwardsConnectionClicked + 1/**StorageNodeList[storageNodeSelected].backwardsConnectionPointsList.size()**/); //add a new point onto the end!
					}
					//and now make sure everything is deselected!
					resourceNodeSelected = -1;
					resourceForwardsConnectionClicked = -1;
					extractorNodeSelected = -1;
					extractorForwardsConnectionClicked = -1;
					extractorBackwardsConnectionClicked = -1;
					processNodeSelected = -1;
					processForwardsConnectionClicked = -1;
					processBackwardsConnectionClicked = -1;
					consumerNodeSelected = -1;
					consumerForwardsConnectionClicked = -1;
					consumerBackwardsConnectionClicked = -1;
					storageNodeSelected = -1;
					storageForwardsConnectionClicked = -1;
					storageBackwardsConnectionClicked = -1;
				}
				break;

				case RCM_DISCONNECT_F_NODE:
				{
					if (resourceNodeSelected != -1 && resourceForwardsConnectionClicked != -1){
						OutputDebugString("Disconnecting resource node forwards connection...");
						if (ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].connectionsList.size() > 0){ //see if a resource node has been selected, and you do actually have a connection to disconnect...
							ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].disconnectNode(resourceForwardsConnectionClicked);
						}
						OutputDebugString("done!\n");
					}
					else if (extractorNodeSelected != -1 && extractorForwardsConnectionClicked != -1){
						OutputDebugString("Disconnecting extractor node forwards connection...");
						if (ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].connectionsList.size() > 0){ //see if a extractor node has been selected, and you do actually have a connection to disconnect...
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].disconnectNode(extractorForwardsConnectionClicked);
						}
						OutputDebugString("done!\n");
					}
					else if (processNodeSelected != -1 && processForwardsConnectionClicked != -1){
						OutputDebugString("Disconnecting process node forwards connection...");
						if (ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].connectionsList.size() > 0){ //see if a process node has been selected, and you do actually have a connection to disconnect...
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].disconnectNode(processForwardsConnectionClicked);
						}
						OutputDebugString("done!\n");
					}
					else if (consumerNodeSelected != -1 && consumerForwardsConnectionClicked != -1){
						OutputDebugString("Disconnecting consumer node forwards connection...");
						if (ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].connectionsList.size() > 0){ //see if a consumer node has been selected, and you do actually have a connection to disconnect...
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].disconnectNode(consumerForwardsConnectionClicked);
						}
						OutputDebugString("done!\n");
					}
					else if (storageNodeSelected != -1 && storageForwardsConnectionClicked != -1){
						OutputDebugString("Disconnecting storage node forwards connection...");
						if (StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].connectionsList.size() > 0){ //see if a storage node has been selected, and you do actually have a connection to disconnect...
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].disconnectNode(storageForwardsConnectionClicked);
						}
						OutputDebugString("done!\n");
					}
					//and now make sure everything is deselected!
					resourceNodeSelected = -1;
					resourceForwardsConnectionClicked = -1;
					extractorNodeSelected = -1;
					extractorForwardsConnectionClicked = -1;
					extractorBackwardsConnectionClicked = -1;
					processNodeSelected = -1;
					processForwardsConnectionClicked = -1;
					processBackwardsConnectionClicked = -1;
					consumerNodeSelected = -1;
					consumerForwardsConnectionClicked = -1;
					consumerBackwardsConnectionClicked = -1;
					storageNodeSelected = -1;
					storageForwardsConnectionClicked = -1;
					storageBackwardsConnectionClicked = -1;

				}
				break;

				case RCM_DISCONNECT_B_NODE:
				{
					if (extractorNodeSelected != -1 && ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].connectionsList.size() > 0){ //see if an extractor node has been selected, and you do actually have a connection to disconnect...
						OutputDebugString("Disconnecting extractor node backwards connection...");
						ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].disconnectNode(extractorBackwardsConnectionClicked);
						OutputDebugString("done!\n");
					}
					else if (processNodeSelected != -1 && ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].connectionsList.size() > 0){ //see if a process node has been selected, and you do actually have a connection to disconnect...
						OutputDebugString("Disconnecting process node backwards connection...");
						ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].disconnectNode(processBackwardsConnectionClicked);
						OutputDebugString("done!\n");
					}
					else if (consumerNodeSelected != -1 && ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].connectionsList.size() > 0){ //see if a consumer node has been selected, and you do actually have a connection to disconnect...
						OutputDebugString("Disconnecting consumer node backwards connection...");
						ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].disconnectNode(consumerBackwardsConnectionClicked);
						OutputDebugString("done!\n");
					}
					else if (storageNodeSelected != -1 && StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].connectionsList.size() > 0){ //see if a storage node has been selected, and you do actually have a connection to disconnect...
						OutputDebugString("Disconnecting storage node backwards connection...");
						StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].disconnectNode(storageBackwardsConnectionClicked);
						OutputDebugString("done!\n");
					}
					//and now make sure everything is deselected!
					resourceNodeSelected = -1;
					resourceForwardsConnectionClicked = -1;
					extractorNodeSelected = -1;
					extractorForwardsConnectionClicked = -1;
					extractorBackwardsConnectionClicked = -1;
					processNodeSelected = -1;
					processForwardsConnectionClicked = -1;
					processBackwardsConnectionClicked = -1;
					consumerNodeSelected = -1;
					consumerForwardsConnectionClicked = -1;
					consumerBackwardsConnectionClicked = -1;
					storageNodeSelected = -1;
					storageForwardsConnectionClicked = -1;
					storageBackwardsConnectionClicked = -1;
				}
				break;

				//set default line style
				case RCM_ARC_DEFAULT:
				{
					if (resourceNodeSelected != -1) {
						if (resourceForwardsConnectionClicked != -1) {
							ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].setStyle(0); //set default style
						}
					}
					else if (extractorNodeSelected != -1) {
						if (extractorForwardsConnectionClicked != -1) {
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].setStyle(0); //set default style
						}
					}
					else if (processNodeSelected != -1) {
						if (processForwardsConnectionClicked != -1) {
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].setStyle(0); //set default style
						}
					}
					else if (consumerNodeSelected != -1) {
						if (consumerForwardsConnectionClicked != -1) {
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].setStyle(0); //set default style
						}
					}
					else if (storageNodeSelected != -1) {
						if (storageForwardsConnectionClicked != -1) {
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].setStyle(0); //set default style
						}
					}
					//and now make sure everything is deselected!
					resourceNodeSelected = -1;
					resourceForwardsConnectionClicked = -1;
					extractorNodeSelected = -1;
					extractorForwardsConnectionClicked = -1;
					extractorBackwardsConnectionClicked = -1;
					processNodeSelected = -1;
					processForwardsConnectionClicked = -1;
					processBackwardsConnectionClicked = -1;
					consumerNodeSelected = -1;
					consumerForwardsConnectionClicked = -1;
					consumerBackwardsConnectionClicked = -1;
					storageNodeSelected = -1;
					storageForwardsConnectionClicked = -1;
					storageBackwardsConnectionClicked = -1;
					commentSelected = -1;
				}
				break;
				//set linear (straight-then-diagonal-then-straight) line style
				case RCM_ARC_LINEAR:
				{
					if (resourceNodeSelected != -1) {
						if (resourceForwardsConnectionClicked != -1) {
							ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].setStyle(1); //set style
						}
					}
					else if (extractorNodeSelected != -1) {
						if (extractorForwardsConnectionClicked != -1) {
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].setStyle(1); //set linear style
						}
					}
					else if (processNodeSelected != -1) {
						if (processForwardsConnectionClicked != -1) {
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].setStyle(1); //set linear style
						}
					}
					else if (consumerNodeSelected != -1) {
						if (consumerForwardsConnectionClicked != -1) {
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].setStyle(1); //set linear style
						}
					}
					else if (storageNodeSelected != -1) {
						if (storageForwardsConnectionClicked != -1) {
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].setStyle(1); //set linear style
						}
					}
					//and now make sure everything is deselected!
					resourceNodeSelected = -1;
					resourceForwardsConnectionClicked = -1;
					extractorNodeSelected = -1;
					extractorForwardsConnectionClicked = -1;
					extractorBackwardsConnectionClicked = -1;
					processNodeSelected = -1;
					processForwardsConnectionClicked = -1;
					processBackwardsConnectionClicked = -1;
					consumerNodeSelected = -1;
					consumerForwardsConnectionClicked = -1;
					consumerBackwardsConnectionClicked = -1;
					storageNodeSelected = -1;
					storageForwardsConnectionClicked = -1;
					storageBackwardsConnectionClicked = -1;
					commentSelected = -1;
				}
				break;
				case RCM_ARC_SPLINE:
				{
					if (resourceNodeSelected != -1) {
						if (resourceForwardsConnectionClicked != -1) {
							ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].setStyle(2); //set style
						}
					}
					else if (extractorNodeSelected != -1) {
						if (extractorForwardsConnectionClicked != -1) {
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].setStyle(2); //set Spline/Bezier style
						}
					}
					else if (processNodeSelected != -1) {
						if (processForwardsConnectionClicked != -1) {
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].setStyle(2); //set Bezier style
						}
					}
					else if (consumerNodeSelected != -1) {
						if (consumerForwardsConnectionClicked != -1) {
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].setStyle(2); //set Bezier style
						}
					}
					else if (storageNodeSelected != -1) {
						if (storageForwardsConnectionClicked != -1) {
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].setStyle(2); //set Bezier style
						}
					}
					//and now make sure everything is deselected!
					resourceNodeSelected = -1;
					resourceForwardsConnectionClicked = -1;
					extractorNodeSelected = -1;
					extractorForwardsConnectionClicked = -1;
					extractorBackwardsConnectionClicked = -1;
					processNodeSelected = -1;
					processForwardsConnectionClicked = -1;
					processBackwardsConnectionClicked = -1;
					consumerNodeSelected = -1;
					consumerForwardsConnectionClicked = -1;
					consumerBackwardsConnectionClicked = -1;
					storageNodeSelected = -1;
					storageForwardsConnectionClicked = -1;
					storageBackwardsConnectionClicked = -1;
					commentSelected = -1;
				}
				break;
				case RCM_ARC_PERP:
				{
					if (resourceNodeSelected != -1) {
						if (resourceForwardsConnectionClicked != -1) {
							ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].setStyle(3); //set style
						}
					}
					else if (extractorNodeSelected != -1) {
						if (extractorForwardsConnectionClicked != -1) {
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].setStyle(3); //set perp style
						}
					}
					else if (processNodeSelected != -1) {
						if (processForwardsConnectionClicked != -1) {
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].setStyle(3); //set perp style
						}
					}
					else if (consumerNodeSelected != -1) {
						if (consumerForwardsConnectionClicked != -1) {
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].setStyle(3); //set perp style
						}
					}
					else if (storageNodeSelected != -1) {
						if (storageForwardsConnectionClicked != -1) {
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].setStyle(3); //set perp style
						}
					}
					//and now make sure everything is deselected!
					resourceNodeSelected = -1;
					resourceForwardsConnectionClicked = -1;
					extractorNodeSelected = -1;
					extractorForwardsConnectionClicked = -1;
					extractorBackwardsConnectionClicked = -1;
					processNodeSelected = -1;
					processForwardsConnectionClicked = -1;
					processBackwardsConnectionClicked = -1;
					consumerNodeSelected = -1;
					consumerForwardsConnectionClicked = -1;
					consumerBackwardsConnectionClicked = -1;
					storageNodeSelected = -1;
					storageForwardsConnectionClicked = -1;
					storageBackwardsConnectionClicked = -1;
					commentSelected = -1;
				}
				break;
				case RCM_ARC_CUSTOM:
				{
					if (resourceNodeSelected != -1) {
						if (resourceForwardsConnectionClicked != -1) {
							ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].setStyle(4); //set custom style
						}
					}
					else if (extractorNodeSelected != -1) {
						if (extractorForwardsConnectionClicked != -1) {
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].setStyle(4); //set custom style
						}
					}
					else if (processNodeSelected != -1) {
						if (processForwardsConnectionClicked != -1) {
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].setStyle(4); //set custom style
						}
					}
					else if (consumerNodeSelected != -1) {
						if (consumerForwardsConnectionClicked != -1) {
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].setStyle(4); //set custom style
						}
					}
					else if (storageNodeSelected != -1) {
						if (storageForwardsConnectionClicked != -1) {
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].setStyle(4); //set custom style
						}
					}
					//and now make sure everything is deselected!
					resourceNodeSelected = -1;
					resourceForwardsConnectionClicked = -1;
					extractorNodeSelected = -1;
					extractorForwardsConnectionClicked = -1;
					extractorBackwardsConnectionClicked = -1;
					processNodeSelected = -1;
					processForwardsConnectionClicked = -1;
					processBackwardsConnectionClicked = -1;
					consumerNodeSelected = -1;
					consumerForwardsConnectionClicked = -1;
					consumerBackwardsConnectionClicked = -1;
					storageNodeSelected = -1;
					storageForwardsConnectionClicked = -1;
					storageBackwardsConnectionClicked = -1;
					commentSelected = -1;
				}
				break;

				case RCM_DEL_B_CONNECTION: //Remove a backwards connection on a node
				{
					if (extractorNodeSelected != -1){ //Start with an extractor node, since resource nodes have no backwards connections
						if (extractorBackwardsConnectionClicked != -1){
							if (ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].connectionsList.size() > 0){
								ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList[extractorBackwardsConnectionClicked].disconnectNode(0);
							}
							ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList.erase(ExtractorNodeList[extractorNodeSelected].backwardsConnectionPointsList.begin() + extractorBackwardsConnectionClicked);
						}
					}
					else if (processNodeSelected != -1){
						if (processBackwardsConnectionClicked != -1){
							if (ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].connectionsList.size() > 0){
								ProcessNodeList[processNodeSelected].backwardsConnectionPointsList[processBackwardsConnectionClicked].disconnectNode(0);
							}
							ProcessNodeList[processNodeSelected].backwardsConnectionPointsList.erase(ProcessNodeList[processNodeSelected].backwardsConnectionPointsList.begin() + processBackwardsConnectionClicked);
						}
					}
					else if (consumerNodeSelected != -1){
						if (consumerBackwardsConnectionClicked != -1){
							if (ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].connectionsList.size() > 0){
								ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList[consumerBackwardsConnectionClicked].disconnectNode(0);
							}
							ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList.erase(ConsumerNodeList[consumerNodeSelected].backwardsConnectionPointsList.begin() + consumerBackwardsConnectionClicked);
						}
					}
					else if (storageNodeSelected != -1){
						if (storageBackwardsConnectionClicked != -1){
							if (StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].connectionsList.size() > 0){
								StorageNodeList[storageNodeSelected].backwardsConnectionPointsList[storageBackwardsConnectionClicked].disconnectNode(0);
							}
							StorageNodeList[storageNodeSelected].backwardsConnectionPointsList.erase(StorageNodeList[storageNodeSelected].backwardsConnectionPointsList.begin() + storageBackwardsConnectionClicked);
						}
					}
				}
				break;

				case RCM_DEL_F_CONNECTION:
				{
					if (resourceNodeSelected != -1 && resourceForwardsConnectionClicked != -1){
						if (ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].connectionsList.size() > 0){
							ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList[resourceForwardsConnectionClicked].disconnectNode(0);
						}
						ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList.erase(ResourceNodeList[resourceNodeSelected].forwardsConnectionPointsList.begin() + resourceForwardsConnectionClicked);
						resourceNodeSelected = -1;
						resourceForwardsConnectionClicked = -1;
					}
					else if (extractorNodeSelected != -1){
						if (extractorForwardsConnectionClicked != -1){
							if (ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].connectionsList.size() > 0){
								ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList[extractorForwardsConnectionClicked].disconnectNode(0);
							}
							ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList.erase(ExtractorNodeList[extractorNodeSelected].forwardsConnectionPointsList.begin() + extractorForwardsConnectionClicked);
						}
						extractorNodeSelected = -1;
						extractorBackwardsConnectionClicked = -1;
						extractorForwardsConnectionClicked = -1;
					}
					else if (processNodeSelected != -1){
						if (processForwardsConnectionClicked != -1){
							if (ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].connectionsList.size() > 0){
								ProcessNodeList[processNodeSelected].forwardsConnectionPointsList[processForwardsConnectionClicked].disconnectNode(0);
							}
							ProcessNodeList[processNodeSelected].forwardsConnectionPointsList.erase(ProcessNodeList[processNodeSelected].forwardsConnectionPointsList.begin() + processForwardsConnectionClicked);
						}
						processNodeSelected = -1;
						processBackwardsConnectionClicked = -1;
						processForwardsConnectionClicked = -1;
					}
					else if (consumerNodeSelected != -1){
						if (consumerForwardsConnectionClicked != -1){
							if (ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].connectionsList.size() > 0){
								ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList[consumerForwardsConnectionClicked].disconnectNode(0);
							}
							ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList.erase(ConsumerNodeList[consumerNodeSelected].forwardsConnectionPointsList.begin() + consumerForwardsConnectionClicked);
						}
						consumerNodeSelected = -1;
						consumerBackwardsConnectionClicked = -1;
						consumerForwardsConnectionClicked = -1;
					}
					else if (storageNodeSelected != -1){
						if (storageForwardsConnectionClicked != -1){
							if (StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].connectionsList.size() > 0){
								StorageNodeList[storageNodeSelected].forwardsConnectionPointsList[storageForwardsConnectionClicked].disconnectNode(0);
							}
							StorageNodeList[storageNodeSelected].forwardsConnectionPointsList.erase(StorageNodeList[storageNodeSelected].forwardsConnectionPointsList.begin() + storageForwardsConnectionClicked);
						}
						storageNodeSelected = -1;
						storageBackwardsConnectionClicked = -1;
						storageForwardsConnectionClicked = -1;
					}
				}
				break;
				case RCM_TOGGLE_NODE_TITLE:
				{
					if (resourceNodeSelected != -1) {
						ResourceNodeList[resourceNodeSelected].showTitle = !(ResourceNodeList[resourceNodeSelected].showTitle == true); //and toggle!
						resourceNodeSelected = -1;
						extractorNodeSelected = -1;
						processNodeSelected = -1;
						consumerNodeSelected = -1;
						storageNodeSelected = -1;
					}
					else if (extractorNodeSelected != -1) {
						ExtractorNodeList[extractorNodeSelected].showTitle = !(ExtractorNodeList[extractorNodeSelected].showTitle == true);
						resourceNodeSelected = -1;
						extractorNodeSelected = -1;
						processNodeSelected = -1;
						consumerNodeSelected = -1;
						storageNodeSelected = -1;
					}
					else if (processNodeSelected != -1) {
						ProcessNodeList[processNodeSelected].showTitle = !(ProcessNodeList[processNodeSelected].showTitle == true);
						resourceNodeSelected = -1;
						extractorNodeSelected = -1;
						processNodeSelected = -1;
						consumerNodeSelected = -1;
						storageNodeSelected = -1;
					}
					else if (consumerNodeSelected != -1) {
						ConsumerNodeList[consumerNodeSelected].showTitle = !(ConsumerNodeList[consumerNodeSelected].showTitle == true); //and toggle!
						resourceNodeSelected = -1;
						extractorNodeSelected = -1;
						processNodeSelected = -1;
						consumerNodeSelected = -1;
						storageNodeSelected = -1;
					}
					else if (storageNodeSelected != -1) {
						StorageNodeList[storageNodeSelected].showTitle = !(StorageNodeList[storageNodeSelected].showTitle == true); //and toggle!
						resourceNodeSelected = -1;
						extractorNodeSelected = -1;
						processNodeSelected = -1;
						consumerNodeSelected = -1;
						storageNodeSelected = -1;
					}
				}
				break;
				case RCM_DEL_COMMENT:
				{
					OutputDebugString("Deleting comment...\n");
					if(commentSelected != -1){ //check we really have selected one...
						CommentsList[commentSelected].destroy(); //destroy the edit box window
						CommentsList.erase(CommentsList.begin() + commentSelected); //... and remove it!
						commentSelected = -1;
					}
				}
				break;
				case RCM_EDIT_COMMENT:
				{
					if (commentSelected != -1) {
						//first make sure no other comments are being edited
						for (int i = 0; i < CommentsList.size(); i++) {
							CommentsList[i].isEditing = false;
							CommentsList[i].isPlaced = true;
						}
						//now select this one!
						CommentsList[commentSelected].isEditing = true;
						commentSelected = -1; //and reset the variable that got us here.
					}
				}
				break;
				case RCM_ASSOCIATE_COMMENT:
				{
					if (commentSelected != -1) {
						//First, we have to make sure nothing else is going on with comments...
						for (int i = 0; i < CommentsList.size(); i++) {
							CommentsList[i].isEditing = false;
							CommentsList[i].isPlaced = true;
							CommentsList[i].isDefiningArea = false;
						}
						CommentsList[commentSelected].isDefiningArea = true;
					}
				}
				break;
			}

		}
		break;

		case WM_ERASEBKGND:
			return (LRESULT)1;

		case WM_DESTROY:
			PostQuitMessage(0);
			return 0;
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			// TODO: Add any drawing code here...
			RECT rect;
			GetClientRect(hWnd, &rect);
			int width = rect.right;
			int height = rect.bottom;

			HDC backbuffDC = CreateCompatibleDC(hdc);

			HBITMAP backbuffer = CreateCompatibleBitmap(hdc, width, height);

			int savedDC = SaveDC(backbuffDC);
			SelectObject(backbuffDC, backbuffer);
			//HBRUSH hBrush = CreateSolidBrush(RGB(0, 255, 255));
			//FillRect(backbuffDC, &rect, hBrush);
			//DeleteObject(hBrush);

			/*************************************************************************************
			*
			*	Drawing code called here!
			*
			**************************************************************************************/

			draw(ps, backbuffDC, hWnd); //I'm the anti-climax! Draw to the flowchart subwindow & contents

			BitBlt(hdc, 0, 0, width, height, backbuffDC, 0, 0, SRCCOPY);
			RestoreDC(backbuffDC, savedDC);

			DeleteObject(backbuffer);
			DeleteDC(backbuffDC);

			EndPaint(hWnd, &ps);

			break;
		}
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

/*********************************************************************************
*
*	Window main Process for the Extractable Resource Editor!
*
**********************************************************************************/

LRESULT CALLBACK ExtractableResourceCreationWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	HDC hdc;
	PAINTSTRUCT ps;
	HGDIOBJ hfDefault = GetStockObject(DEFAULT_GUI_FONT);

	/******************************************************************************************
	*	Dealing with the dynamically created window per-output buttons!
	*******************************************************************************************/
	if (message == WM_COMMAND && LOWORD(wParam) >= 720 && LOWORD(wParam) < 800) { //if the value is in the range for the dynamically created buttons
		if (LOWORD(wParam) >= 720 && LOWORD(wParam) < 740) { //the 'import new component' button

		}
		else if (LOWORD(wParam) >= 740 && LOWORD(wParam) < 760) { //The 'create new component' button
			SendMessage(ResourceComponentCreationWindowHandle, WM_COMMAND, RCCW_CREATE_NEW, 0);
		}
		else if (LOWORD(wParam) >= 760 && LOWORD(wParam) < 780) { //The 'remove component' button
			int outputVal = LOWORD(wParam) - 760;
			//update all the connections to reflect the control's values
			for (u_int i = 0; i < NewExtractableResourceComponentsList.size(); i++) {
				//get the edit box text for the flow rate
				//char data[32];
				//GetWindowText(NodeOutputTypeList[i][1], data, 32);
				//NewExtractableResourceComponentsList[i].maxFlowRate = (float)atof(data); //explicit conversion to float because atof() should really be called atod()...
				//NewExtractableResourceComponentsList[i].maxFlowRateUnits = FlowRateUnitsList[SendMessage(NodeOutputTypeList[i][2], CB_GETCURSEL, 0, 0)]; //get the combobox's current text, and assign use it to update the connection
			}
			NewExtractableResourceComponentsList.erase(NewExtractableResourceComponentsList.begin() + outputVal); //remove this particular output
			SendMessage(hWnd, WM_COMMAND, ERCW_UPDATE_WIN_CONTROLS, NULL); //And refresh the buttons!
		}
	}

	switch (message)
	{
	case WM_CREATE:
	{
		// Create resource name and description edit boxes
		ResourceNameBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "New Resource", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 55, 10, 280, 20, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		ResourceDescBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "[Default]", WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL, 55, 35, 280, 50, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		//Despatch the relevant messages to set up fonts etc.
		SendMessage(ResourceNameBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(ResourceDescBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

		NewResourceCreateButton = CreateWindowEx(NULL, "BUTTON", "Create", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 30, 420, 100, 25, hWnd, (HMENU)ERCW_CREATE_NEW_RESOURCE, GetModuleHandle(NULL), NULL);
		NewResourceCancelButton = CreateWindowEx(NULL, "BUTTON", "Cancel", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 140, 420, 100, 25, hWnd, (HMENU)ERCW_CANCEL_NEW_RESOURCE, GetModuleHandle(NULL), NULL);
		NewResourceExportButton = CreateWindowEx(NULL, "BUTTON", "Export", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 250, 420, 100, 25, hWnd, (HMENU)ERCW_EXPORT_NEW_RESOURCE, GetModuleHandle(NULL), NULL);

		SendMessage(NewResourceCreateButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(NewResourceCancelButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(NewResourceExportButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

		NodeResourceAddNewComponentButton = CreateWindowEx(NULL, "BUTTON", "Add Component", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 210 + (NewResourceComponentsWindowsControls.size()) * 60, 90, 22, hWnd, (HMENU)ERCW_CREATE_NEW_COMPONENT, GetModuleHandle(NULL), NULL); //This button adds a new output row to the menu
		SendMessage(NodeResourceAddNewComponentButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
	}
	break;
	case WM_COMMAND:
	{
		switch (LOWORD(wParam)) {
		//command to create a new resource creation window!
		case ERCW_CREATE_NEW:
		{
			//clear the current list (although it should have already been cleared from last time, but hey!)
			NewExtractableResourceComponentsList.clear(); //Wipe out everything else...
			// ...and now add a new one!
			ResourceComponent newComponent = ResourceComponent();
			NewExtractableResourceComponentsList.push_back(newComponent);
			SendMessage(hWnd, WM_COMMAND, ERCW_UPDATE_WIN_CONTROLS, 0); //Notify ourselves that the win32 controls need updating
			ShowWindow(hWnd, SW_SHOW); //SHow the window now everything has been sorted
		}
		break;
		case ERCW_UPDATE_WIN_CONTROLS:
		{
			//first destroy the current windows
			for (int i = 0; i < NewResourceComponentsWindowsControls.size(); i++) {
				for (int j = 0; j < NewResourceComponentsWindowsControls[i].size(); j++) {
					DestroyWindow(NewResourceComponentsWindowsControls[i][j]);
				}
			}
			NewResourceComponentsWindowsControls.clear();
			//Now, create some new ones!
			for (int i = 0; i < NewExtractableResourceComponentsList.size(); i++) {
				//Create name & edit boxes for the new component
				HWND newResourceComponent = CreateWindow("COMBOBOX", "Input", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 10, 150 + (i * 60), 172, 100, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
				SendMessage(newResourceComponent, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
				for (u_int j = 0; j < GlobalResourceComponentList.size(); j++) {
					SendMessage(newResourceComponent, CB_ADDSTRING, 0, (LPARAM)GlobalResourceComponentList[j].componentName.c_str());
				}
				SendMessage(newResourceComponent, CB_SETCURSEL, 0, 0); //select element '0' (the NULL-resource)
				HWND ComponentAbundanceBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "25", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 185, 150 + i * 60, 75, 21, hWnd, (HMENU)IDC_NODE_CREATE_NAME, GetModuleHandle(NULL), NULL);
				SendMessage(ComponentAbundanceBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
				HWND ComponentAbundanceUnits = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 265, 150 + i * 60, 70, 450, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
				SendMessage(ComponentAbundanceUnits, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
				//Add the list of acceptable flow rate units into the units box
				for (int j = 0; j < AbundanceUnitsList.size(); j++) {
					SendMessage(ComponentAbundanceUnits, CB_ADDSTRING, 0, (LPARAM)AbundanceUnitsList[j].c_str());
				}
				SendMessage(ComponentAbundanceUnits, CB_SETCURSEL, 0, 0); //select element '0' (% mass)
				HWND ImportNewResourceComponentButton = CreateWindowEx(NULL, "BUTTON", "Import Comp.", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 175 + i * 60, 90, 22, hWnd, (HMENU)(720+i), GetModuleHandle(NULL), NULL); //This button adds a new output row to the menu
				HWND CreateNewResourceComponentButton = CreateWindowEx(NULL, "BUTTON", "Create New", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 110, 175 + i * 60, 90, 22, hWnd, (HMENU)(740+i), GetModuleHandle(NULL), NULL); //This button adds a new output row to the menu
				HWND RemoveResourceComponentButton = CreateWindowEx(NULL, "BUTTON", "Remove", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 210, 175 + i * 60, 90, 22, hWnd, (HMENU)(760+i), GetModuleHandle(NULL), NULL); //This button adds a new output row to the menu
				SendMessage(ImportNewResourceComponentButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
				SendMessage(CreateNewResourceComponentButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
				SendMessage(RemoveResourceComponentButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

				std::array<HWND, 6> NewWindowsControls = { newResourceComponent, ComponentAbundanceBox, ComponentAbundanceUnits, ImportNewResourceComponentButton, CreateNewResourceComponentButton, RemoveResourceComponentButton };
				NewResourceComponentsWindowsControls.push_back(NewWindowsControls);
			}
			SetWindowPos(NodeResourceAddNewComponentButton, NULL, 10, 148 + (NewExtractableResourceComponentsList.size()) * 60, 0, 0, SWP_NOSIZE); //Keep the "New Component" button in the right place
			RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE); //and refresh the window!
		}
		break;
		//Button commands
		case ERCW_CREATE_NEW_COMPONENT:
		{
			//Add a new one!
			ResourceComponent newComponent = ResourceComponent();
			NewExtractableResourceComponentsList.push_back(newComponent);
			SendMessage(hWnd, WM_COMMAND, ERCW_UPDATE_WIN_CONTROLS, 0); //Notify ourselves that the win32 controls need updating
		}
		break;
		case ERCW_CREATE_NEW_RESOURCE:
		{

		}
		break;
		case ERCW_CANCEL_NEW_RESOURCE:
		{
			ShowWindow(hWnd, SW_HIDE);
			//destroy the current windows for good measure
			for (int i = 0; i < NewResourceComponentsWindowsControls.size(); i++) {
				for (int j = 0; j < NewResourceComponentsWindowsControls[i].size(); j++) {
					DestroyWindow(NewResourceComponentsWindowsControls[i][j]);
				}
			}
			NewResourceComponentsWindowsControls.clear();
		}
		break;
		case ERCW_EXPORT_NEW_RESOURCE:
		{

		}
		break;
		}
	}
	break;
	case WM_PAINT:
	{
		hdc = BeginPaint(hWnd, &ps);
		HFONT hFont;
		HPEN hPen;
		HBRUSH hBrush;
		SetBkColor(hdc, RGB(255, 255, 255));
		RECT clientRect;
		HRGN bgRgn;
		GetClientRect(hWnd, &clientRect);
		win_width = clientRect.right - clientRect.left;
		win_height = clientRect.bottom - clientRect.top;
		bgRgn = CreateRectRgnIndirect(&clientRect);
		hBrush = CreateSolidBrush(RGB(255, 255, 255)); //colour it white
		FillRgn(hdc, bgRgn, hBrush); //draw to buffer
		DeleteObject(hBrush);

		//add text GUI labels
		TextOut(hdc, 10, 10, "Name:", _tcslen("Name:"));
		TextOut(hdc, 10, 35, "Desc:", _tcslen("Desc:"));

		//Draw line under the name/description boxes
		hPen = CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
		SelectObject(hdc, hPen);
		MoveToEx(hdc, 0, 100, NULL);
		LineTo(hdc, 400, 100);
		DeleteObject(hPen);

		//Now draw out column titles!
		hFont = CreateFont(17, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		RECT textRect = { 0, 105, 360, 110 };
		DrawText(hdc, "Resource Components", 19, &textRect, DT_CENTER | DT_NOCLIP);
		DeleteObject(hFont);

		//Now title each column
		hFont = CreateFont(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		textRect = { 10, 130, 172, 140 };
		DrawText(hdc, "Component Name", 14, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 185, 130, 350, 140 };
		DrawText(hdc, "Abundance", 9, &textRect, DT_LEFT | DT_NOCLIP);
		DeleteObject(hFont);

		//draw a line under each component
		for (int i = 0; i < NewResourceComponentsWindowsControls.size(); i++) {
			hPen = CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
			SelectObject(hdc, hPen);
			MoveToEx(hdc, 0, 202 + i * 60, NULL);
			LineTo(hdc, 400, 202 + i * 60);
			DeleteObject(hPen);
		}

		EndPaint(hWnd, &ps);
	}
	break;
	case WM_CLOSE: //when the user requests the window to be closed...
	{
		ShowWindow(hWnd, SW_HIDE); //We hide the window instead
		return 1;
	}
	break;
	case WM_DESTROY: //but if they insist...
	{
		PostQuitMessage(0);
		return 1;
	}
	break;
	}
	DeleteObject(hfDefault);
	return DefWindowProc(hWnd, message, wParam, lParam);
}