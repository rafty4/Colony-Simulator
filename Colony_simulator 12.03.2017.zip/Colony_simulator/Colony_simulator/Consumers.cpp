#include "stdafx.h"

/****************************************************************************************
*
*	HumanConsumer class:
*	Represents a human in terms of resource consumption per unit of time
*
*****************************************************************************************/

HumanConsumer::HumanConsumer(){
}
HumanConsumer::~HumanConsumer(){
}

/****************************************************************************************
*
*	Consumer class:
*	Stores all the data about a generic consumer, and the relevant functions
*
****************************************************************************************/

Consumer::Consumer(){
}
Consumer::~Consumer(){
}