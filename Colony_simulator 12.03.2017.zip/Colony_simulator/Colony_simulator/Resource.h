/****************************************************************************************
*
*	Resource.h
*	Contains all the definitions required for windows controls and other purposes.
*
*****************************************************************************************/


#define IDS_APP_TITLE				103

#define IDR_MAINFRAME				128
#define IDD_WIN32PROJECT1_DIALOG	102
#define IDD_ABOUTBOX				103

//Menu definitions
#define IDM_ABOUT				104 //About message request
#define IDM_EXIT				105 //Exit message request
//#define IDC_MAIN_EDIT			106	//Edit box identifier (for demo purposes only!)
#define IDC_NODE_CREATE_NAME	107 //Code to identify the node creation window's naming box
#define IDC_NODE_CREATE_DESC	108 //Code to identify the node creation window's description box

//File menu definitions
#define IDM_NEW_SIM				200 //start new colony
#define IDM_OPEN				201 //open previous colony
#define IDM_IMPT_NEW_RESOURCE	202 //Import new resource node
#define IDM_IMPT_NEW_EXTRACTOR	199 //Import new Extractor node
#define IDM_IMPT_NEW_PROCESS	203 //Import new process node
#define IDM_IMPT_NEW_CONSUMER	204 //Import new consumer node
#define IDM_IMPT_NEW_STORAGE	198 //Import new Storage node
#define IDM_SAVE				205 //save setup
#define IDM_SAVE_AS				206 //save setup as
#define IDM_EVERYTHING			207 //save everything!
#define IDM_SAVE_COPY_AS		208 //save a copy
//Edit menu definitions
#define IDM_UNDO				209 //undo last action
#define IDM_REDO				210 //redo last action
//View Menu
#define IDM_RESOURCE_FLOW			211 //Switch to resource flow chart
#define IDM_ZOOM_IN					250 //Zoom the flowchart in
#define IDM_ZOOM_OUT				251 //Zoom the flowchart out
#define IDM_RESET_VIEW				252 //Reset the view controls
#define IDM_SET_BKGND_STATIC_GRID	253 //Set the background to be a static grid (default)
#define IDM_SET_BKGND_MOBILE_GRID	254 //Set background to be a grid that moves and scales with the nodes
#define IDM_SET_BKGND_PLAIN			255 //Set background to be plain white. Appropriately defined as 255!
//Settings menu definitions
#define IDM_SETTINGS			212 //placeholder
//Colony menu
#define IDM_ADD_RESOURCE		213 //add new resource node from menu
#define IDM_ADD_EXTRACTOR		214 //add new extractor node from menu
#define IDM_ADD_PROCESS			215 //add new process from menu
#define IDM_ADD_CONSUMER		216 //add new consumer from menu
#define IDM_ADD_STORAGE			217 //add new storage mode from menu
#define IDM_CREATE_RESOURCE		218 //create new resource from menu
#define IDM_CREATE_EXTRACTOR	219 //create new extractor from menu
#define IDM_CREATE_PROCESS		220 //create new process from menu
#define IDM_CREATE_CONSUMER		221 //create new consumer from menu
#define IDM_CREATE_STORAGE		222 //create new storage from menu
//Simulate menu
#define IDM_RUN_ENTIRE_PROJECT	223 //run the project with whatever settings have beenn specified
#define IDM_SIMULATION_SETTINGS	224 //open up the simulation settings dialog

//Button definitions
#define IDC_ADD_RESOURCE		301 //Add resource node command
#define IDC_ADD_EXTRACTOR		302 //Add extractor node command
#define IDC_ADD_INDUSTRIAL		303 //Add industrial process to flowchart command
#define IDC_ADD_CONSUMER		304 //Add consumer node command
#define IDC_ADD_STORAGE			305 //Add storage node command
#define IDC_REQ_NEW_NODE		306 //Command to create the dialog to create the new node
#define IDC_REQ_RESOURCE		307 //Request resource command. Will open up the dialog box.
#define IDC_REQ_EXTRACTOR		308 //Request extractor command
#define IDC_REQ_INDUSTRIAL		309 //Request industrial process to flowchart command
#define IDC_REQ_CONSUMER		310 //Request consumer command
#define IDC_REQ_STORAGE			311	//Request storage node command
#define IDC_ZOOM_IN				312 //Zoom the flowchart window in
#define IDC_ZOOM_OUT			313 //Zoom the flowchart window out

//Right click menu definitions
//General right click menu on the flowchart window:
#define IDR_POPUPMENU					400	//Placeholder!
#define RCM_REQ_RESOURCE				401 //Command from right-click menu to request a new resource
#define RCM_REQ_EXTRACTOR				402 //Request a new extractor
#define RCM_REQ_PROCESS					403 //Request a new process
#define RCM_REQ_CONSUMER				404 //Request a new consumer. Also everybody's favorite error code!
#define RCM_REQ_STORAGE					405	//Request a new storage mode
#define RCM_REMOVE_RESOURCE				406 //Remove a resource node (as commanded from a Right Click Menu)
#define RCM_REMOVE_EXTRACTOR			407	//Remove an extractor node
#define RCM_REMOVE_INDUSTRIAL			408	//Remove an industrial process node
#define RCM_REMOVE_CONSUMER				409	//Remove a consumer node
#define RCM_REMOVE_STORAGE				410 //remove a storage node
#define RCM_ADD_F_CONNECTION			411 //Notification to add a forwards connection to the node
#define RCM_ADD_B_CONNECTION			412 //Notification to add a rearwards connection to the node
#define RCM_DISCONNECT_F_NODE			413 //Command from right click menu to disconnect a forwards-facing connection
#define RCM_DISCONNECT_B_NODE			414 //Disconnect a rearwards-facing connection from a right-click menu
#define RCM_DEL_F_CONNECTION			415 //Delete the selected forwards connection from a right-click menu
#define RCM_DEL_B_CONNECTION			416 //Delete the selected rearwards connection from right-click menu
#define RCM_NODE_PROPERTIES				417 //command to open the node properties box from the right-click menu
#define RCM_UNLOCK_NODE					418 //Unlock node dimensions for freehand resize
#define RCM_TOGGLE_NODE_TITLE			419 //Toggle the title above the node
#define RCM_RESET_NODE_SIZE				420 //Reset node to default size
#define RCM_FIT_TO_TEXT					421 //Fit the node to its description text within on a single line
#define RCM_FIT_TO_TEXT_MULTI			422 //Fit the node to multiline text - i.e. get the smallest perimeter by splitting at the ' ' marks
//Comment right click commands
#define RCM_ADD_COMMENT					430 //Command to add a comment box
#define RCM_DEL_COMMENT					431 //Command to delete comment
#define RCM_UNLOCK_COMMENT				432 //Allow comment resizing to occur (de-occurs when clicked off)
#define RCM_EDIT_COMMENT				433 //Allow the comment to be edited
#define RCM_ASSOCIATE_COMMENT			434 //Send the command that initiates the user's task of dragging a rectangle around some nodes
//Flowchart arc commands
#define RCM_ARC_DEFAULT					450 //Define an arc to have the default, straight, style
#define RCM_ARC_LINEAR					451 //Define an arc to have the straight-then-default style
#define RCM_ARC_SPLINE					452 //Define arc to have spline curve type
#define RCM_ARC_PERP					453 //Define arc to be of the perpendicular style
#define RCM_ARC_CUSTOM					454 //Define arc to be of user-defined vertices
//Chemical Structure window right-click commands
#define RCM_EDIT_CHEMICAL_COMPONENT		455 //Paste the formula into the formula bar for editing
#define RCM_DUP_CHEMICAL_COMPONENT		456 //Duplicate the chemical component in the window
#define RCM_DELETE_CHEMICAL_COMPONENT	457 //Delete the selected component. Also breaks all the relevant bonds
#define RCM_TOGGLE_COMPONENT_BORDER		458 //Toggle that grey border on and off

//Node creation window definitions
#define IDW_CANCEL_NODE_CREATION	500 //cancel the node creation operation
#define IDW_APPROVE_NODE_CREATION	501 //approve the node's creation!
#define IDW_FORWARDS_CONN_INC		502 //increment forwards connection number
#define IDW_FORWARDS_CONN_DEC		503 //decrement forwards connection number
#define IDW_BACKWARDS_CONN_INC		504 //increment backwards connection number
#define IDW_BACKWARDS_CONN_DEC		505 //decrement backwards connection number
#define IDW_EDIT_CONNECTIONS		506 //code to bring up the connections editor

//Connection point edit window definitions
#define IDCE_EDIT_CONNECTIONS		600 //We want to edit the connection points on a node!
#define IDCE_CANCEL_EDIT			601 //Cancel the edit operation when the cancel button is hit
#define IDCE_FINISH_EDIT			602 //Approve edit and close
#define IDCE_APPLY_EDIT				603 //Apply edit operation, but don't close
#define IDCE_ADD_INPUT				604 //Add a new input to the node
#define IDCE_ADD_OUTPUT				605 //Add a new output to the node
#define IDCE_UPDATE_CONTROLS		606 //Update the windows controls shown
#define IDCE_UPDATE_FORWARDS		607 //Save the forwards connection nodes to the list ready for transfer
#define IDCE_UPDATE_PROCESSES		608 //Save the process windows control values to the list
#define IDCE_UPDATE_BACKWARDS		609 //Save the backwards connection nodes to the lst ready for transfer
//#defines 620-639 are reserved for 'import' buttons
//#defines 640-659 are reserved for 'create new' buttons
//#defines 660-679 are reserved for 'remove' buttons
//#defines 680-699 are reserved for 'delimit' checkboxes

//Extractable Resource Creation Window definitions
#define ERCW_CREATE_NEW				700 //Command to wipe, reset & show the window to create a new resource
#define ERCW_UPDATE_WIN_CONTROLS	701 //Command to actually update the windows controls
#define ERCW_CREATE_NEW_RESOURCE	702 //Button command to create the new resource
#define ERCW_CANCEL_NEW_RESOURCE	703 //Button command to cancel the new resource
#define ERCW_EXPORT_NEW_RESOURCE	704 //Button command to export the resource to an external text file
#define ERCW_CREATE_NEW_COMPONENT	705 //Button command to add a new component to the resource
//#defines 720-739 are reserved for 'import' buttons
//#defines 740-759 are reserved for 'create new' buttons
//#defines 760-779 are reserved for 'remove' buttons

//Resource Component Creation window definitions
#define RCCW_CREATE_NEW				800 //Command to wipe, reset, and then show the new component window.
#define RCCW_APPLY_RESOURCE_CHANGES	802 //Button command to create the new component
#define RCCW_CANCEL_NEW_RESOURCE	803 //Button command to cancel the new component
#define RCCW_EXPORT_NEW_RESOURCE	804 //Button command to export the component to an external text file
#define RCCW_EDIT_CHEMISTRY			805 //Button to edit (or remove) the chemistry of the substance
#define RCCW_IMPORT_NEW_RESOURCE	806

//Chemical Structure edit window definitions
#define CSW_FINISH_EDIT				900 //Command to save changes and close
#define CSW_APPLY_EDIT				901 //Command to apply changes, but remain open
#define CSW_CANCEL_EDIT				902 //Close without saving changes
#define CSW_START_EDIT				903 //Command to load the relevant compound, and show the window
#define CSW_EDIT_NEW_COMPONENT		904 //Command to edit the component in the edit box. Opens up the periodic table!
#define CSW_ADD_NEW_COMPONENT		905 //Add the element to the main structural formula window
#define CSW_UPDATE_STRUCTURE_EDITBOX	906 //Command to stick whatever is in the Periodic Table Window's chemical component vector list into this window's editbox!

//Periodic table window definitions
#define PTW_SHOW					1000 //Setup then show periodic table window
#define PTW_FINISH_COMPONENT		1001 //Finish editing the component, apply it, and close the window
#define PTW_APPLY_COMPONENT			1002 //Apply the component, but don't close the window
#define PTW_CANCEL_COMPONENT		1003 //Don't apply it, and close the window!
#define PTW_TOGGLE_TOTAL_CHARGE		1004 //Notification for when the charge toggling button is pressed
#define PTW_TOTAL_CHARGE_EDITBOX	1005 //For when the editbox containing the total charge has been tweaked
#define PTW_ELEMENT_BUTTON			1100 /*1100 to 1250 reserved for element buttons*/

//Project definitions
#define IDI_WIN32PROJECT1		107
#define IDI_SMALL				108
#define IDC_WIN32PROJECT1		109
#define IDC_MYICON				2
#ifndef IDC_STATIC
#define IDC_STATIC				-1
//#define WM_REFRESH_WINDOW		0
#endif
// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	129
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		110
#endif
#endif
