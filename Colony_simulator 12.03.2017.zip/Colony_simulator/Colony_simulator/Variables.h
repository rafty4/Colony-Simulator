#pragma once
#ifndef VARIABLES_H
#define VARIABLES_H

//#include "stdafx.h"

extern HWND hEdit;
LRESULT CALLBACK FlowchartWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
extern HWND FlowchartWindowHandle;
extern TOOLINFO ti;
extern HWND toolTipWnd;

extern std::vector<ResourceComponent> GlobalResourceComponentList; //Global list that contains *all* loaded resource components!
extern std::string applicationDirectory;
int UpdateResourceComponentCreationWindowTextFields(ResourceComponent ThisComponent);
ResourceComponent LoadResourceComponentFromFile(std::vector<std::string> fileLines);
ResourceComponent GetResourceComponentData();
int SaveResourceComponent(char* szFileName);

/**************************************************************************************************
*
*	Node creation window variables!
*
***************************************************************************************************/

extern HWND NodeCreateWindowHandle;
LRESULT CALLBACK NodeCreationWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
extern HWND nodeNameBox; //naming box for the node creation window
extern HWND nodeDescBox; //description box for the node creation window!
extern HWND mainWindowHWND; //the main window handle!
extern int fowardsConnectionsNum;
extern int backwardsConnectionsNum;
extern std::vector<ConnectionPoint> ForwardsConnectionsToAdd;
extern std::vector<ConnectionPoint> BackwardsConnectionsToAdd;

/****************************************************************************************************
*
*	Edit Node Connections window variables
*
****************************************************************************************************/

extern HWND NodeConnEditWindowHandle; //window handle
LRESULT CALLBACK NodeConnEditWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam); //main window process
extern HWND NodeEditTabControl;
extern HWND NodeEditAddNewOutputButton;
extern HWND NodeEditAddNewInputButton;
extern HWND NodeEditApplyButton;
extern HWND NodeEditOkButton;
extern HWND NodeEditCancelButton;
extern std::vector<ConnectionPoint> NewForwardsConnectionsToAdd;
extern std::vector<ConnectionPoint> NewBackwardsConnectionsToAdd;
extern std::vector<std::array<HWND, 7>> NodeOutputTypeList;
extern std::vector<std::array<HWND, 7>> NodeInputTypeList;

/**************************************************************************************************
*
*	Extractable Resource Creation/Edit window global variables
*
***************************************************************************************************/

extern HWND ExtractableResourceCreationWindowHandle;
LRESULT CALLBACK ExtractableResourceCreationWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
extern HWND ResourceNameBox;
extern HWND ResourceDescBox;
extern HWND NewResourceCreateButton;
extern HWND NewResourceCancelButton;
extern HWND NewResourceExportButton;
extern HWND NodeResourceAddNewComponentButton;
extern std::vector<ResourceComponent> NewExtractableResourceComponentsList;
extern std::vector<std::array<HWND, 6>> NewResourceComponentsWindowsControls;

/**************************************************************************************************
*
*	Resource Component Creation/Edit window global variables
*
**************************************************************************************************/

LRESULT CALLBACK ResourceComponentCreationWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
extern HWND ResourceComponentCreationWindowHandle;
extern HDC IntermediateChemicalStructureRender;
extern HDC ChemicalStructureRender;
extern __int64 CurrentResourceComponentUniqueID;
//Human interface boxes
extern HWND ResourceComponentNameBox;
extern HWND ResourceComponentDescBox;
//Metadata boxes
extern HWND ResourceComponentSolidDensityBox;
extern HWND SolidDensityUnitsBox;
extern HWND ResourceComponentLiquidDensityBox;
extern HWND LiquidDensityUnitsBox;
extern HWND ResourceComponentMeltingPointBox;
extern HWND MeltingPointUnitsBox;
extern HWND ResourceComponentBoilingPointBox;
extern HWND BoilingPointUnitsBox;
extern HWND ResourceComponentPercentAbundanceBox;
extern HWND PercentAbundanceUnitsBox;
extern HWND ResourceComponentMassStoredBox;
extern HWND MassStoredUnitsBox;
extern HWND ResourceComponentVolStoredBox;
extern HWND VolStoredUnitsBox;
extern HWND ResourceComponentTempBox;
extern HWND TemperatureUnitsBox;
extern HWND ResourceComponentHeatCapacityBox;
extern HWND HeatCapacityUnitsBox;
extern HWND CurrentStateCombobox;
extern HWND isDissolvedCheckbox;
extern HWND isMiscibleCheckbox;
extern HWND isRadioactiveCheckbox;
//Creation control buttons
extern HWND NewComponentImportButton;;
extern HWND NewComponentCreateButton;
extern HWND NewComponentCancelButton;
extern HWND NewComponentExportButton;

/**************************************************************************************************
*
*	Chemistry creation window global variables
*
***************************************************************************************************/

LRESULT CALLBACK ChemicalFormulaCreationWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
extern HWND ChemicalFormulaCreationWindowHandle;
extern HWND NewCompoundEditBox;
extern std::vector<Atom> ChemistryCreationComponentList;
extern int ChemicalFormulaComponentCharge;

/**************************************************************************************************
*
*	Chemistry creation window embedded child window global variables
*
***************************************************************************************************/

LRESULT CALLBACK ChemicalStructureWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
extern HWND ChemicalStructureWindowHandle;
extern std::vector<MolecularComponent> ChemicalStructureComponentCompound; //A list of the components that make up the compound
extern bool chemicalStructureWindowMousePressed;
extern int selectedChemicalStructureComponent;

/**************************************************************************************************
*
*	Periodic table window main process
*
***************************************************************************************************/

LRESULT CALLBACK PeriodicTableWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
extern HWND PeriodicTableWindowHandle;
extern HWND NumberOfAtomsToAddEditBoxHandle;
extern HWND TotalChargeEditBoxHandle;
extern HWND TogglePosOrNegComponentCharge;
extern std::vector<Atom> PeriodicTableChemicalComponentList;
extern int PeriodicTableChemicalComponentCharge;

/**************************************************************************************************
*
*	General-purpose global variables!
*
**************************************************************************************************/

LRESULT CALLBACK WinProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
extern HINSTANCE mainHinst;
extern HWND Tooltip;
extern HWND FlowchartZoomInButton;
extern HWND FlowchartZoomOutButton;
extern std::vector <ResourceNode> ResourceNodeList;
extern std::vector <ExtractorNode> ExtractorNodeList;
extern std::vector <ProcessNode> ProcessNodeList;
extern std::vector <ConsumerNode> ConsumerNodeList;
extern std::vector <StorageNode> StorageNodeList;
extern std::vector <Comment> CommentsList;
extern bool addResourceNode;
extern POINT cursorPos;
extern int mouseX;
extern int mouseY;
extern int lastMouseX;
extern int lastMouseY;
extern bool mousePressedL;
extern bool mouseLDblClk;
extern int frameCount;
extern int backgroundMode; //0 for plain white, 1 for static grid, 2 for mobile grid (default)
extern int nodeEditWindowMode; //0 for resource, 1 for extractor, ect. Defines the visual appearance & functionality of the node edit window
extern std::array <std::string, 5> MassUnitsList; //List of acceptable units of mass
extern std::array <std::string, 5> DistanceUnitsList; //List of acceptable units of distance
extern std::array <std::string, 5> AreaUnitsList; //List of acceptable units of area
extern std::array <std::string, 5> VolumeUnitsList; //List of acceptable units of volume
extern std::array <std::string, 5> PowerUnitsList;
extern std::array <std::string, 3> TemperatureUnitsList; //Farenheit is included against by better judgement for our backwards pals across the pond
extern std::array <std::string, 15> FlowRateUnitsList; //List of acceptable units of flow rate
extern std::array <std::string, 32> AbundanceUnitsList; //list of acceptable units of abundance
extern std::array <std::string, 8> DensityUnitsList;
extern std::array <std::string, 5> HeatCapacityUnitsList; //List of acceptable heat capacity units per unit mass
extern std::vector <Atom> PeriodicTable;

//indications of which nodes and/or connections have been selected
extern int resourceNodeSelected;
extern int resourceForwardsConnectionClicked;

extern int extractorNodeSelected;
extern int extractorBackwardsConnectionClicked;
extern int extractorForwardsConnectionClicked;

extern int processNodeSelected;
extern int processBackwardsConnectionClicked;
extern int processForwardsConnectionClicked;

extern int consumerNodeSelected;
extern int consumerBackwardsConnectionClicked;
extern int consumerForwardsConnectionClicked;

extern int storageNodeSelected;
extern int storageBackwardsConnectionClicked;
extern int storageForwardsConnectionClicked;

extern int commentSelected;

bool isAnyNodesFloating();

extern bool isPainting; //variable to track whether we are painting to prevent being interrupted

//window size variables
extern int win_width; //width
extern int win_height; //height

//View variables
extern float zoomFactor;
extern float viewX;
extern float viewY;

//node creation window global variables
extern int nodeCreationType;
#endif