#pragma once

#include "stdafx.h"

//String function prototypes
std::string trimString(std::string stringToTrim); //Trim the white space off a string
std::vector<std::string> splitString(std::string stringToSplit, std::string delim); //Split a string up at the delimiting character(s)
//function protoypes allowing the node lists to be obtained and updated from this .cpp file
//std::vector <ResourceNode> getResourceNodeList();
//std::vector <ExtractorNode> getExtractorNodeList();
//std::vector <ConsumerNode> getConsumerNodeList();
//std::vector <ProcessNode> getProcessNodeList();
//std::vector <StorageNode> getStorageNodeList();
//Flowchart node list update command prototypes
//int updateResourceNodeList(std::vector<ResourceNode> ResourceNodeList);
//int updateExtractorNodeList(std::vector<ExtractorNode> ExtractorNodeList);
//int updateConsumerNodeList(std::vector<ConsumerNode> ConsumerNodeList);
//int updateProcessNodeList(std::vector<ProcessNode> ProcessNodeList);
//int updateStorageNodeList(std::vector<StorageNode> StorageNodeList);
//Prototypes allowing all acceptable units to be obtained for this cpp file
std::array <std::string, 5> getMassUnitsList();
std::array <std::string, 5> getDistanceUnitsList();
std::array <std::string, 5> getVolumeUnitsList();
std::array <std::string, 5> getPowerUnitsList();
std::array <std::string, 15> getFlowRateUnitsList();
//get view variables function prototypes
float getZoomFactor();
float getViewX();
float getViewY();
//HWND reference prototypes
HWND getNodeNameBox();
HWND getNodeDescBox();
//Tooltip functions
HWND createTooltip(HWND hwndParent, HWND tooltip, TCHAR* text);
HWND destroyTooltip(HWND tooltip);