#pragma once

/****************************************************************************************
*
*	HumanConsumer class:
*	Represents a human in terms of resource consumption per unit of time
*
*****************************************************************************************/
class HumanConsumer{
private:
public:
	HumanConsumer(); //Create a (default) human. Don't ever let anybody tell you you're different any longer!
	~HumanConsumer(); //Destroy a human (by the default method). I hope you realise what you just did. Murderer!
};

/****************************************************************************************
*
*	Consumer class:
*	Stores all the data about a generic consumer, and the relevant functions
*
****************************************************************************************/

class Consumer{
private:
public:
	Consumer();
	~Consumer();
};