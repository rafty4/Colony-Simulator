#include "stdafx.h"

HWND hEdit;
LRESULT CALLBACK FlowchartWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
HWND FlowchartWindowHandle;
TOOLINFO ti = { 0 };
HWND toolTipWnd;

std::vector<ResourceComponent> GlobalResourceComponentList; //Global list that contains *all* loaded resource components!
std::string applicationDirectory = "";

/**************************************************************************************************
*
*	Node creation window variables!
*
***************************************************************************************************/

HWND NodeCreateWindowHandle;
LRESULT CALLBACK NodeCreationWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
HWND nodeNameBox; //naming box for the node creation window
HWND nodeDescBox; //description box for the node creation window!
HWND mainWindowHWND; //the main window handle!
int fowardsConnectionsNum = 1;
int backwardsConnectionsNum = 1;
std::vector<ConnectionPoint> ForwardsConnectionsToAdd;
std::vector<ConnectionPoint> BackwardsConnectionsToAdd;

/****************************************************************************************************
*
*	Edit Node Connections window variables
*
****************************************************************************************************/

HWND NodeConnEditWindowHandle; //window handle
LRESULT CALLBACK NodeConnEditWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam); //main window process
HWND NodeEditTabControl;
HWND NodeEditAddNewOutputButton;
HWND NodeEditAddNewInputButton;
HWND NodeEditApplyButton;
HWND NodeEditOkButton;
HWND NodeEditCancelButton;
std::vector<ConnectionPoint> NewForwardsConnectionsToAdd;
std::vector<ConnectionPoint> NewBackwardsConnectionsToAdd;
std::vector<std::array<HWND, 7>> NodeOutputTypeList;
std::vector<std::array<HWND, 7>> NodeInputTypeList;

/**************************************************************************************************
*
*	Extractable Resource Creation/Edit window global variables
*
***************************************************************************************************/

HWND ExtractableResourceCreationWindowHandle;
LRESULT CALLBACK ExtractableResourceCreationWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
HWND ResourceNameBox;
HWND ResourceDescBox;
HWND NewResourceCreateButton;
HWND NewResourceCancelButton;
HWND NewResourceExportButton;
HWND NodeResourceAddNewComponentButton;
std::vector<ResourceComponent> NewExtractableResourceComponentsList;
std::vector<std::array<HWND, 6>> NewResourceComponentsWindowsControls;

/**************************************************************************************************
*
*	Resource Component Creation/Edit window global variables
*
**************************************************************************************************/

LRESULT CALLBACK ResourceComponentCreationWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
HWND ResourceComponentCreationWindowHandle;
HDC IntermediateChemicalStructureRender;
HDC ChemicalStructureRender;
__int64 CurrentResourceComponentUniqueID;
//Human interface boxes
HWND ResourceComponentNameBox;
HWND ResourceComponentDescBox;
//Metadata boxes
HWND ResourceComponentSolidDensityBox;
HWND SolidDensityUnitsBox;
HWND ResourceComponentLiquidDensityBox;
HWND LiquidDensityUnitsBox;
HWND ResourceComponentMeltingPointBox;
HWND MeltingPointUnitsBox;
HWND ResourceComponentBoilingPointBox;
HWND BoilingPointUnitsBox;
HWND ResourceComponentPercentAbundanceBox;
HWND PercentAbundanceUnitsBox;
HWND ResourceComponentMassStoredBox;
HWND MassStoredUnitsBox;
HWND ResourceComponentVolStoredBox;
HWND VolStoredUnitsBox;
HWND ResourceComponentTempBox;
HWND TemperatureUnitsBox;
HWND ResourceComponentHeatCapacityBox;
HWND HeatCapacityUnitsBox;
HWND CurrentStateCombobox;
HWND isDissolvedCheckbox;
HWND isMiscibleCheckbox;
HWND isRadioactiveCheckbox;
//Creation control buttons
HWND NewComponentImportButton;
HWND NewComponentCreateButton;
HWND NewComponentCancelButton;
HWND NewComponentExportButton;

/**************************************************************************************************
*
*	Chemistry creation window global variables
*
***************************************************************************************************/

LRESULT CALLBACK ChemicalFormulaCreationWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
HWND ChemicalFormulaCreationWindowHandle;
HWND NewCompoundEditBox;
std::vector<Atom> ChemistryCreationComponentList;
int ChemicalFormulaComponentCharge = 0;

/**************************************************************************************************
*
*	Chemistry creation window embedded child window global variables
*
***************************************************************************************************/

LRESULT CALLBACK ChemicalStructureWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
HWND ChemicalStructureWindowHandle;
std::vector<MolecularComponent> ChemicalStructureComponentCompound; //A list of the components that make up the compound
bool chemicalStructureWindowMousePressed = false;
int selectedChemicalStructureComponent = -1;

/**************************************************************************************************
*
*	Periodic table window main process
*
***************************************************************************************************/

LRESULT CALLBACK PeriodicTableWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
HWND PeriodicTableWindowHandle;
HWND NumberOfAtomsToAddEditBoxHandle;
HWND TotalChargeEditBoxHandle;
HWND TogglePosOrNegComponentCharge;
std::vector<Atom> PeriodicTableChemicalComponentList;
int PeriodicTableChemicalComponentCharge = 0;

/**************************************************************************************************
*
*	General-purpose global variables!
*
**************************************************************************************************/

LRESULT CALLBACK WinProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
HINSTANCE mainHinst;
HWND Tooltip;
HWND FlowchartZoomInButton;
HWND FlowchartZoomOutButton;
std::vector <ResourceNode> ResourceNodeList;
std::vector <ExtractorNode> ExtractorNodeList;
std::vector <ProcessNode> ProcessNodeList;
std::vector <ConsumerNode> ConsumerNodeList;
std::vector <StorageNode> StorageNodeList;
std::vector <Comment> CommentsList;
bool addResourceNode = false;
POINT cursorPos;
int mouseX = 0;
int mouseY = 0;
int lastMouseX = 0;
int lastMouseY = 0;
bool mousePressedL = false;
bool mouseLDblClk = false;
int frameCount = 0;
int backgroundMode = 2; //0 for plain white, 1 for static grid, 2 for mobile grid (default)
int nodeEditWindowMode = 0; //0 for resource, 1 for extractor, ect. Defines the visual appearance & functionality of the node edit window
std::array <std::string, 5> MassUnitsList = { "mT", "kg", "g", "mg", "mol" }; //List of acceptable units of mass
std::array <std::string, 5> DistanceUnitsList = { "km", "m", "cm", "mm" }; //List of acceptable units of distance
std::array <std::string, 5> AreaUnitsList = { "km2", "m2", "cm2", "mm2" }; //List of acceptable units of area
std::array <std::string, 5> VolumeUnitsList = { "km3", "m3", "dm3", "cm3", "mm3" }; //List of acceptable units of volume
std::array <std::string, 5> PowerUnitsList = { "GW", "MW", "kW", "W", "mW" };
std::array <std::string, 3> TemperatureUnitsList = { "K", "C", "F" }; //Farenheit is included against by better judgement for our backwards pals across the pond
std::array <std::string, 15> FlowRateUnitsList = { "mT/s", "kg/s", "g/s", "mg/s", "km3/s", "m3/s", "dm3/s", "cm3/s", "mm3/s", "mol/s", "GW", "MW", "kW", "W", "mW" }; //List of acceptable units of flow rate
std::array <std::string, 32> AbundanceUnitsList = { "% mass", "% vol", "mT/m3", "kg/m3", "g/m3", "mg/m3", "mol/m3", "mol/dm3", "kg/dm3", "g/dm3", "mg/dm3", "g/cm3", "mg/cm3", "g/mm3", "mg/mm3", "mT/km2", "kg/km2", "g/km2", "mg/km2", "mT/m2", "kg/m2", "g/m2", "mg/m2", "kg/cm2", "g/cm2", "mg/cm2", "g/mm2", "mg/mm2", "n/km2", "n/m2", "n/cm2", "n/mm2" }; //list of acceptable units of abundance
std::array <std::string, 8> DensityUnitsList = { "mT/km3", "mT/m3", "kg/m3", "kg/dm3", "g/m3", "g/dm3", "g/cm3", "g/mm3" };
std::array <std::string, 5> HeatCapacityUnitsList = { "J/kg/K", "J/g/K", "J/Mol/K", "J/kg/F", "Cal/kg"};
std::vector <Atom> PeriodicTable;

//indications of which nodes and/or connections have been selected
int resourceNodeSelected = -1;
int resourceForwardsConnectionClicked = -1;

int extractorNodeSelected = -1;
int extractorBackwardsConnectionClicked = -1;
int extractorForwardsConnectionClicked = -1;

int processNodeSelected = -1;
int processBackwardsConnectionClicked = -1;
int processForwardsConnectionClicked = -1;

int consumerNodeSelected = -1;
int consumerBackwardsConnectionClicked = -1;
int consumerForwardsConnectionClicked = -1;

int storageNodeSelected = -1;
int storageBackwardsConnectionClicked = -1;
int storageForwardsConnectionClicked = -1;

int commentSelected = -1;

bool isAnyNodesFloating();

bool isPainting = false; //variable to track whether we are painting to prevent being interrupted

//window size variables
int win_width = 0; //width
int win_height = 0; //height

//View variables
float zoomFactor = 1;
float viewX = 0;
float viewY = 0;

//node creation window global variables
int nodeCreationType = -1;