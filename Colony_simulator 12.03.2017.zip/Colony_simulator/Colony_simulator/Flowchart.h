#pragma once

#include "stdafx.h"

class ConnectionPoint; //Prototype for the node connection class
class Comment; //Prototype for the comment class

/************************************************************************
*	Misc function prototypes.
*************************************************************************/
//Correct positions
float correctX(float xpos);
float correctY(float ypos);
//Or go the other way
float deCorrectX(float xpos);
float deCorrectY(float ypos);
//function prototypes to get the mouseX and mouseY positions
int getMouseX();
int getMouseY();
int getLastMouseX();
int getLastMouseY();
bool isMousePressedL();
bool isMouseLDblClk();
std::array<int, 4> resizeNode(HDC hdc, int x, int y, int defWidth, int defHeight, int width, int height, int largestConnectionNum);
std::string getResizeMultilineText(HDC thisHDC, std::string name, float &width, float &height, int defaultHeight);

/*************************************************************************
*
*	Resource Node Class:
*	Stores all the data for a resource node in the resources flowchart
*	The beginning element of any flowchart
*
**************************************************************************/

class ResourceNode{
private:
	HWND DescTooltip; //multi-line tooltip which appears when you hover over the node with its description
	bool tooltipActive;
public:
	std::string name; //displayed name of the node
	TCHAR desc[512]; //description of the node that will be displayed
	float x; //x position on chart. Float to make life simple in later scaling operations.
	float y; //y position on chart
	float width; //node width in x. Same reason for floating.
	float height; //node height in y
	float defaultWidth; //the default width
	float defaultHeight; //the default height
	int isMouseOverArc; //The index of which arc the mouse is over. -1 if none. Set in the draw() subroutine.
	bool showTitle; //whether or not to display the main title over the node
	bool unlockSize; //True if the node has been unlocked

	std::vector <ConnectionPoint> forwardsConnectionPointsList; //list of the connection points on the RHS of the node. Resource nodes do not have any LHS connections.
	
	bool isPlaced; //whether the node is placed or free-floating with the mouse
	
	//constructors
	ResourceNode(float xpos,float ypos, float width,float height, std::vector<ConnectionPoint> ForwardsConnections);
	ResourceNode(); //default constructor
	~ResourceNode();
	
	//functions!
	int draw(HDC hdc, HWND hWnd, int mouseX, int mouseY, bool highlight); //draw the node
	bool place(int mouseX, int mouseY); //place it at the provided window co-ordinates
	int isConnectionNodeClicked(int mouseX, int mouseY, bool modify = true); //Check if any connection points have been clicked, and return the index of the one that has. Also default to toggling free-floating bool.
	bool isMouseOverNode(int mouseX, int mouseY); //true when the mouse is over the node
	int addForwardsConnection(int index); //add a connection to the list at the specified index
	int removeForwardsConnection(int index); //remove a connection from the list
	int resize(int mode, HWND hWnd); //reset the node's size. 0 = default, 1 = singleline text fit, 2 = multiline text fit.
};

/*************************************************************************
*
*	Extractor Node Class:
*	Stores all the data for a extractor node in the resources flowchart
*
**************************************************************************/

class ExtractorNode{
private:
	HWND DescTooltip; //multi-line tooltip which appears when you hover over the node with its description
	bool tooltipActive;
public:
	std::string name; //node name
	TCHAR desc[512]; //description of the node that will be displayed
	float x; //x position on chart. Float to make life simple in later scaling operations.
	float y; //y position on chart
	float width; //node width in x. Same reason for floating.
	float height; //node height in y
	float defaultWidth; //the default width
	float defaultHeight; //the default height
	int isMouseOverArc; //The index of which connection arc the mouse is over. -1 if none, only applies to forwards connections.
	bool showTitle; //whether or not to display the main title over the node
	bool unlockSize; //True if the node has been unlocked

	std::vector <ConnectionPoint> forwardsConnectionPointsList; //list of the connection points on the RHS of the node.
	std::vector <ConnectionPoint> backwardsConnectionPointsList; //list of the connection points on the LHS of the node. The important list.

	bool isPlaced; //whether the node is placed or free-floating with the mouse

	//constructors!
	ExtractorNode(float xpos, float ypos, float Width, float Height, std::vector<ConnectionPoint> ForwardsConnections, std::vector<ConnectionPoint> BackwardsConnections);
	ExtractorNode(); //blank constructor
	~ExtractorNode();

	//functions!
	int draw(HDC hdc, HWND hWnd, int mouseX, int mouseY, bool highlight); //draw the full node
	bool place(int mouseX, int mouseY);
	int isBackwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify = true); //check to see if any of the endpoint arrows have been clicked on the LHS. Default to modify *and* observe parameters
	int isForwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify = true); //check to see if any of the endpoint arrows have been clicked on the RHS
	bool isMouseOverNode(int mouseX, int mouseY); //true if the mouse is over the node, otherwise false
	
	int addForwardsConnection(int index); //add a connection to the list
	int removeForwardsConnection(int index); //remove a connection from the list
	int addBackwardsConnection(int index); //add a backwards connection to the list
	int removeBackwardsConnection(int index); //remove a backwards connection from the list
	int resize(int mode, HWND hWnd); //reset the node's size. 0 = default, 1 = singleline text fit, 2 = multiline text fit.
};

/*************************************************************************
*
*	Industrial Process Node Class:
*	Stores all the data for a industrial process node in the resources
*	flowchart.
*
**************************************************************************/

class ProcessNode{
private:
	HWND DescTooltip; //multi-line tooltip which appears when you hover over the node with its description
	bool tooltipActive;
public:
	std::string name; //node name
	TCHAR desc[512]; //description of the node that will be displayed
	float x; //x position on chart. Float to make life simple in later scaling operations.
	float y; //y position on chart
	float width; //node width in x. Same reason for floating.
	float height; //node height in y
	float defaultWidth; //the default width
	float defaultHeight; //the default height
	bool isPlaced; //whether the node is placed or free-floating with the mouse
	int isMouseOverArc; //The index of which connection arc the mouse is over. -1 if none, only applies to forwards connections.
	bool showTitle; //whether or not to display the main title over the node
	bool unlockSize; //True if the node has been unlocked

	std::vector <ConnectionPoint> forwardsConnectionPointsList; //list of the connection points on the RHS of the node.
	std::vector <ConnectionPoint> backwardsConnectionPointsList; //list of the connection points on the LHS of the node. The important list.

	ProcessNode(float xpos, float ypos, float Width, float Height, std::vector<ConnectionPoint> ForwardsConnections, std::vector<ConnectionPoint> BackwardsConnections);
	ProcessNode();
	~ProcessNode();

	int draw(HDC hdc, HWND hWnd, int mouseX, int mouseY, bool highlight);
	bool place(int mouseX, int mouseY);
	int isBackwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify = true); //check to see if any of the endpoint arrows have been clicked on the LHS. Default to modify *and* observe parameters
	int isForwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify = true); //check to see if any of the endpoint arrows have been clicked on the RHS
	bool isMouseOverNode(int mouseX, int mouseY); //true if the mouse is over the node, otherwise false

	int addForwardsConnection(int index); //add a forwards connection to the list
	int removeForwardsConnection(int index); //remove a forwards connection from the list
	int addBackwardsConnection(int index); //add a backwards connection to the list
	int removeBackwardsConnection(int index); //remove a backwards connection from the list
	int resize(int mode, HWND hWnd); //reset the node's size. 0 = default, 1 = singleline text fit, 2 = multiline text fit.
};

/*************************************************************************
*
*	Consumer Node Class:
*	Stores all the data for a consumer node in the resources flowchart
*	Normally the end of any flowchart
*
**************************************************************************/

class ConsumerNode{
private:
	HWND DescTooltip; //multi-line tooltip which appears when you hover over the node with its description
	bool tooltipActive;
public:
	std::string name; //node name
	TCHAR desc[512]; //description of the node that will be displayed
	float x; //x position on chart. Float to make life simple in later scaling operations.
	float y; //y position on chart
	float width; //node width in x. Same reason for floating.
	float height; //node height in y
	float defaultWidth; //the default width
	float defaultHeight; //the default height
	bool isPlaced; //whether the node is placed or free-floating with the mouse
	int isMouseOverArc; //The index of which connection arc the mouse is over. -1 if none, only applies to forwards connections.
	bool showTitle; //whether or not to display the main title over the node
	bool unlockSize; //True if the node has been unlocked

	std::vector <ConnectionPoint> forwardsConnectionPointsList; //list of the connection points on the RHS of the node.
	std::vector <ConnectionPoint> backwardsConnectionPointsList; //list of the connection points on the LHS of the node. The important list.

	ConsumerNode(float xpos, float ypos, float Width, float Height, std::vector<ConnectionPoint> ForwardsConnections, std::vector<ConnectionPoint> BackwardsConnections); //main constructor
	ConsumerNode(); //default, empty constructor
	~ConsumerNode(); //default, empty destructor

	int draw(HDC hdc, HWND hWnd, int mouseX, int mouseY, bool highlight); //draw function
	bool place(int mouseX, int mouseY); //place function
	int isBackwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify = true); //check to see if any of the endpoint arrows have been clicked on the LHS. Default to modify *and* observe parameters
	int isForwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify = true); //check to see if any of the endpoint arrows have been clicked on the RHS
	bool isMouseOverNode(int mouseX, int mouseY); //true if the mouse is over the node, otherwise false

	int addForwardsConnection(int index); //add a connection to the list, at the specified index
	int removeForwardsConnection(int index); //remove a connection from the list
	int addBackwardsConnection(int index); //add a backwards connection to the list, at the specified index
	int removeBackwardsConnection(int index); //remove a backwards connection from the list
	int resize(int mode, HWND hWnd); //reset the node's size. 0 = default, 1 = singleline text fit, 2 = multiline text fit.
};

/*************************************************************************
*
*	Storage Node Class:
*	Stores any extracted resource. Keeps it, and can spew it out at
*	request!
*
**************************************************************************/

class StorageNode{
private:
	HWND DescTooltip; //multi-line tooltip which appears when you hover over the node with its description
	bool tooltipActive;
public:
	std::string name; //node name
	TCHAR desc[512]; //description of the node that will be displayed. Max 512 characters.
	float x; //x position on chart. Float to make life simple in later scaling operations.
	float y; //y position on chart
	float width; //node width in x. Same reason for floating.
	float height; //node height in y
	float defaultWidth; //the default width
	float defaultHeight; //the default height
	bool isPlaced; //whether the node is placed or free-floating with the mouse
	int isMouseOverArc; //The index of which connection arc the mouse is over. -1 if none, only applies to forwards connections.
	bool showTitle; //whether or not to display the main title over the node
	bool unlockSize; //True if the node has been unlocked

	std::vector <ConnectionPoint> forwardsConnectionPointsList; //list of the connection points on the RHS of the node.
	std::vector <ConnectionPoint> backwardsConnectionPointsList; //list of the connection points on the LHS of the node. The important list.

	StorageNode(float xpos, float ypos, float Width, float Height, std::vector<ConnectionPoint> ForwardsConnections, std::vector<ConnectionPoint> BackwardsConnections); //main constructor
	StorageNode(); //default, empty constructor
	~StorageNode(); //default, empty destructor

	int draw(HDC hdc, HWND hWnd, int mouseX, int mouseY, bool highlight); //draw function
	bool place(int mouseX, int mouseY); //place function
	int isBackwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify = true); //check to see if any of the endpoint arrows have been clicked on the LHS. Default to modify *and* observe parameters
	int isForwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify = true); //check to see if any of the endpoint arrows have been clicked on the RHS
	bool isMouseOverNode(int mouseX, int mouseY); //true if the mouse is over the node, otherwise false

	int addForwardsConnection(int index); //add a connection to the list, at the specified index
	int removeForwardsConnection(int index); //remove a connection from the list
	int addBackwardsConnection(int index); //add a backwards connection to the list, at the specified index
	int removeBackwardsConnection(int index); //remove a backwards connection from the list
	int resize(int mode, HWND hWnd); //reset the node's size. 0 = default, 1 = singleline text fit, 2 = multiline text fit.
};

/*************************************************************************
*
*	Node connection class:
*	Stores all the relevant data about the arcs connecting the flowchart
*	nodes on the main graph, with particular reference to the endpoints.
*	Note that the connections are listed in effectively reverse order,
*	with each connection point being connected to an earlier node, as
*	opposed to a later one. However, 'forward' connections are still
*	stored just in case.
*
**************************************************************************/

class ConnectionPoint{
private:
	//data for the potential unconnected line that will float around at some point....
	bool isUnconnectedArc = false;
	float unconnectedStartX = -1;
	float unconnectedStartY = -1;
	int style; //the style of the connecting arc. 0 = default, 1 = linear, 2 = spline, 3 = perpendicular, 4 = custom vertices
	float beginX, beginY;
	float finishX, finishY;
	int listSize; //total size of the list it is stored on
public:
	float maxFlowRate; //the maximum input or output flow rate that can be obtained
	bool isMaxFlowRateDelimited; //whether or not that is infinate (i.e. conforms exactly with demands)
	int flowRateMode; //0 for input defined, 1 for output defined, 2 for process defined and 3 for delimited
	std::string maxFlowRateUnits;
	ExtractableResource OutputExtractableResource; //Class type which holds all the data about what this particular connection point can output from a resource node!
	StoredResource InputResource; //Class type for non-resource node's connections
	StoredResource OutputResource;

	int index; //index on the std::vector list it is stored on
	std::vector<std::array<float, 2>> additionalArcVertices; //additional arc vertices for different styles
	bool isUserEditingLine;

	bool isFreeFloating; //does it have a loose wire waiting to be connected?
	std::vector <std::array<int, 8>> connectionsList; //list of the nodes this connection point is connected to [0] = type (0, 1, 2, 3), [1] = parent node index, [2] = LHS or RHS, [3] = connection point index; ditto for elements [4] (T), [5] (P), [6] (L/R) and [7] (Index).

	ConnectionPoint(int pointIndex);
	ConnectionPoint(); //blank default constructor
	~ConnectionPoint(); //blank default destructor
	int drawUnconnectedArc(HDC hdc, HWND hWnd, int mouseX, int mouseY); //draw the line chasing the mouse when it is unconnected
	int setUnconnectedArc(float startX, float startY); //create the conditions for a free-floating arc
	int unsetUnconnectedArc(); //do the exact opposite!
	int isMouseOverLine(float mouseX, float mouseY, float startX, float startY, float endX, float endY); //determine if the mouse is within a few pixels of the line joining two nodes.
	int draw(HDC hdc, HWND hWnd, bool isForwardNode, float x, float y, float width, float height, float defaultHeight, int currentIndex, int totalConnections); //draw the connection node itself, and the relevant lines!
	bool placeConnection(int typeConnectedTo, int LR, int parentNodeIndex, int connectionIndex, int endTypeConnectedTo, int endParentNodeIndex, int endLR, int endConnectionIndex); //Place the end node. Node type (0, 1, 2, 3); LR (0,1) for in, then out; index of connection node, and index of the connection "plug"
	int disconnectNode(int connectionIndex); //disconnect connection node
	int setStyle(int newStyle); //set the style of the connecting arc. 0 = default, 1 = linear, 2 = spline, 3 = perpendicular, 4 = custom
};

/**************************************************************************
*
*	Comment class
*	Structure which contains all the information about a comment.
*	Comments can be standalone, tied to a particular node or group of
*	nodes. Designed to make all graphs more readable.
*
***************************************************************************/

class Comment {
private:
	HWND EditBoxHandle; //handle for the edit box that will be concealed inside the comment box
public:
	std::string text; //Text contained within the comment
	float xpos;
	float ypos;
	float width;
	float height;
	bool isEdited;
	bool isPlaced;
	float textSize;
	bool isEditing;
	bool isDefiningArea;
	RECT TempAssociationRect;
	RECT AssociationRect;

	Comment(); //default constructor
	Comment(HWND parent, float x, float y, float textHeight); //the usual constructor
	~Comment(); //default destructor
	bool destroy(); //removes the text box from existance
	int draw(HDC hdc); //draw the comment box
	bool isMouseOverComment(float mouseX, float mouseY); //returns true if the mouse is over a comment
};