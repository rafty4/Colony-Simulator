
/****************************************************************************************
*
*	Flowchart.cpp
*	Includes all the functions required to complete the classes outlined in Flowchart.h
*	Each class represents a different type of node - Resource, Extractor, Process,
*	Consumer and Storage, with each's different functions.
*
*****************************************************************************************/

#include "stdafx.h"

/**************************************************************************
*
*	Comment class
*	Structure which contains all the information about a comment.
*	Comments can be standalone, tied to a particular node or group of
*	nodes. Designed to make all graphs more readable.
*
***************************************************************************/

//default constructor
Comment::Comment() {
	xpos = 0;
	ypos = 0;
	width = 0;
	height = 0;
	text = "";
	isPlaced = true;
}

//default destructor
Comment::~Comment() {
}

//usual constructor
Comment::Comment(HWND parent, float x, float y, float textHeight) {
	xpos = deCorrectX(x);
	ypos = deCorrectY(y);
	width = 5;
	height = textHeight + 4;
	textSize = textHeight;
	text = "This\n is a comment";
	width = text.length()*(textSize / 2) + 4;
	isPlaced = false;
	EditBoxHandle = CreateWindowEx(0, "EDIT", text.c_str(), WS_BORDER | WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_AUTOVSCROLL | ES_MULTILINE | ES_LEFT | ES_WANTRETURN, (int)xpos, (int)ypos, 10, 20, parent, NULL, NULL, NULL);
	TempAssociationRect = { 0,0,0,0 };
	AssociationRect = { 0,0,0,0 };
}

bool Comment::destroy() {
	return (BOOL)DestroyWindow(EditBoxHandle);
}

//Draw subroutine
int Comment::draw(HDC hdc) {
	HBRUSH hBrush = NULL;
	HPEN hPen = NULL;
	SendMessage(EditBoxHandle, WM_PAINT, 0, 0);
	if (!isPlaced) { //if the node is being dragged around by the mouse
		//position the center for the node under the mouse
		xpos = deCorrectX(getMouseX())-getZoomFactor()*(int(width) / 2.0);
		ypos = deCorrectY(getMouseY())-getZoomFactor()*(int(height) / 2.0);
		int width2 = AssociationRect.right - AssociationRect.left;
		//make sure the association box follows us about!
		AssociationRect.left = LONG(xpos);
		AssociationRect.bottom = LONG(ypos + (AssociationRect.bottom - AssociationRect.top) + height);
		AssociationRect.top = LONG(ypos + height);
		AssociationRect.right = LONG(xpos + width2);
		isEditing = false;
	}

	SIZE textSize; //structure which we will store details about the string's physical dimensions
	GetTextExtentPoint32(hdc, text.c_str(), text.size(), &textSize);
	if (textSize.cy < 15) {//make sure we don't get a graphical bug....
		textSize.cy = 20;
	}
	MoveWindow(EditBoxHandle, (int)correctX(xpos), (int)correctY(ypos), textSize.cx+10, textSize.cy+1, TRUE);
	int textLength = GetWindowTextLength(EditBoxHandle) + 3;
	char windowText[128];
	GetWindowText(EditBoxHandle,windowText,textLength);
	text = windowText;
	//Now either allow or prevent editing of the comment...
	if (isEditing) {
		EnableWindow(EditBoxHandle, TRUE);
		isPlaced = true;
	}
	else {
		EnableWindow(EditBoxHandle, FALSE);
	}

	if (isDefiningArea) {
		isPlaced = true;
		if (TempAssociationRect.left != 0 && TempAssociationRect.top != 0) {
			if (TempAssociationRect.right != 0 && TempAssociationRect.bottom != 0) {
				hPen = CreatePen(PS_DASH, 1, RGB(0, 0, 0)); //since this is a temporary rectangle, give it a dotted outline
				SelectObject(hdc, hPen);
				SelectObject(hdc, GetStockObject(NULL_BRUSH)); //make sure this is an unfilled rectangle
				Rectangle(hdc, (int)correctX(float(TempAssociationRect.left)), (int)correctY(float(TempAssociationRect.top)), (int)correctX(float(TempAssociationRect.right)), (int)correctY(float(TempAssociationRect.bottom)));
				DeleteObject(hPen);
			}
			TempAssociationRect.right = (LONG)deCorrectX((float)getMouseX());
			TempAssociationRect.bottom = (LONG)deCorrectY((float)getMouseY());
			//ensure we get non-zero values!
			if (TempAssociationRect.right == 0) {
				TempAssociationRect.right++;
			}
			if(TempAssociationRect.bottom == 0){
				TempAssociationRect.bottom++;
			}
		}
	}
	else if(AssociationRect.left != 0 && AssociationRect.right != 0 && AssociationRect.top != 0){
		hPen = CreatePen(PS_SOLID, 4, RGB(80, 80, 80)); //give the 'permanent' one a thick grey outline
		SelectObject(hdc, hPen);
		SelectObject(hdc, GetStockObject(NULL_BRUSH)); //make sure this is an unfilled rectangle
		Rectangle(hdc, (int)correctX((float)AssociationRect.left), (int)correctY((float)AssociationRect.top), (int)correctX((float)AssociationRect.right), (int)correctY((float)AssociationRect.bottom));
		DeleteObject(hPen);
	}

	//Plug any memory leaks
	DeleteObject(hPen);
	DeleteObject(hBrush);
	return 0;
}

//detect if the mouse is over the comment box
bool Comment::isMouseOverComment(float mouseX, float mouseY) {
	mouseX = deCorrectX(mouseX);
	mouseY = deCorrectY(mouseY);
	if (mouseX > xpos && mouseX < xpos + width) { //check the x bounds
		if (mouseY > ypos && mouseY < ypos + height) { //check the y bounds
			SendMessage(EditBoxHandle, WM_PAINT, 0, 0);
			return true;
		}
	}
	return false;
}

/*************************************************************************
*
*	Node connection class:
*	Stores all the relevant data about the arcs connecting the flowchart
*	nodes on the main graph
*
**************************************************************************/

ConnectionPoint::ConnectionPoint(int pointIndex){
	index = pointIndex;
	style = 0;
	isUserEditingLine = false;
	additionalArcVertices.clear();
	maxFlowRate = 100; //default max flow rate value
	isMaxFlowRateDelimited = false;
	flowRateMode = 1; //Default to output defined
	maxFlowRateUnits = getFlowRateUnitsList()[1]; //set default flow rate to kg/s
	OutputExtractableResource = ExtractableResource();
	InputResource = StoredResource();
	OutputResource = StoredResource();
}

ConnectionPoint::ConnectionPoint(){ //default constructor, does nothing but make life easier for the poor programmer.
}

ConnectionPoint::~ConnectionPoint(){

}

int ConnectionPoint::setUnconnectedArc(float startX, float startY){ //tell the node it has an unconnected line that needs to float around artistically
	isUnconnectedArc = true; //inform the node we now have a random floating line...
	unconnectedStartX = startX;
	unconnectedStartY = startY;
	return 0;
}

int ConnectionPoint::unsetUnconnectedArc(){ //remove the free-floating arc!
	isUnconnectedArc = false; //inform the node we no longer have a random floating line...
	unconnectedStartX = 0;
	unconnectedStartY = 0;
	return 0;
}

int ConnectionPoint::drawUnconnectedArc(HDC hdc, HWND hWnd, int mouseX, int mouseY){ //draw the line chasing the mouse when it is unconnected
	HPEN hPen = CreatePen(PS_DOT, 1, RGB(0, 0, 0)); //Dotted black line
	SelectObject(hdc, hPen);
	MoveToEx(hdc, (int)correctX(unconnectedStartX), (int)correctY(unconnectedStartY), NULL);
	LineTo(hdc, mouseX, mouseY);
	SelectObject(hdc, NULL); //reset pen color
	DeleteObject(hPen); //clear up memory
	return 0;
}

int ConnectionPoint::isMouseOverLine(float mouseX, float mouseY, float startX, float startY, float endX, float endY){ //check to see if the mouse is over a connection arc
	//map the mouseX/Y to the same co-ordinate system as the start/endX's
	mouseX = deCorrectX(mouseX);
	mouseY = deCorrectY(mouseY);
	if (additionalArcVertices.size() == 0) { //if it is a single line
		if ((mouseX > startX-4 && mouseX < endX+4) || (mouseX < startX+4 && mouseX > endX-4)) { //check the mouse is within the bounds of the line
			float d = abs((endX - startX)*(startY - mouseY) - (startX - mouseX)*(endY - startY)) / (sqrt((endX - startX)*(endX - startX) + (endY - startY)*(endY - startY))); //Vector maths ftw!
			if (d < 4) {
				return 2; //if the mouse is within 4 pixels of the line
			}
		}
	}
	else { //if we have additional vertices
		std::array <float, 2> startVertex;
		std::array <float, 2> endVertex;
		for (int i = 0; i <= additionalArcVertices.size(); i++) {
			if (additionalArcVertices.size() == 1) {
				startVertex[0] = startX;
				startVertex[1] = startY;

				std::array <float, 2> midVertex;
				midVertex[0] = additionalArcVertices[0][0];
				midVertex[1] = additionalArcVertices[0][1];

				endVertex[0] = endX;
				endVertex[1] = endY;
				if ((mouseX > startX-4 && mouseX < midVertex[0]+4) || (mouseX < startX+4 && mouseX > midVertex[0]-4)) { //check the mouse is within the bounds of the line
					float d = abs((midVertex[0] - startX)*(startY - mouseY) - (startX - mouseX)*(midVertex[1] - startY)) / (sqrt((midVertex[0] - startX)*(midVertex[0] - startX) + (midVertex[1] - startY)*(midVertex[1] - startY))); //Vector maths ftw!
					if (d < 4) {
						return i+1; //if the mouse is within 4 pixels of the line
					}
				}
				if ((mouseX > midVertex[0]-4 && mouseX < endX+4) || (mouseX < midVertex[0]+4 && mouseX > endX-4)) { //check the mouse is within the bounds of the line
					float d = abs((endX - midVertex[0])*(midVertex[1] - mouseY) - (midVertex[0] - mouseX)*(endY - midVertex[1])) / (sqrt((endX - midVertex[0])*(endX - midVertex[0]) + (endY - midVertex[1])*(endY - midVertex[1])));
					if (d < 4) {
						return additionalArcVertices.size()+2; //if the mouse is within 4 pixels of the line
					}
				}
			}
			else{
				if (i == 0) {
					startVertex[0] = startX;
					startVertex[1] = startY;
				}
				else {
					startVertex = additionalArcVertices[i-1];
				}
				if (i == additionalArcVertices.size()) {
					endVertex[0] = endX;
					endVertex[1] = endY;
				}
				else {
					endVertex = additionalArcVertices[i];
				}
				if ((mouseX > startVertex[0]-4 && mouseX < endVertex[0]+4) || (mouseX < startVertex[0]+4 && mouseX > endVertex[0]-4)) { //check the mouse is within the bounds of the line
					float d = abs((endVertex[0] - startVertex[0])*(startVertex[1] - mouseY) - (startVertex[0] - mouseX)*(endVertex[1] - startVertex[1])) / (sqrt((endVertex[0] - startVertex[0])*(endVertex[0] - startVertex[0]) + (endVertex[1] - startVertex[1])*(endVertex[1] - startVertex[1]))); //Vector maths ftw!
					if (d < 4) {
						if (i == additionalArcVertices.size()) {
							i += additionalArcVertices.size() + 1; //to make sure we leave the loop after here!
							return additionalArcVertices.size() + 2;
						}
						return i+1; //if the mouse is within 4 pixels of the line
					}
				}
			}
		}
	}
	return false;
}

int ConnectionPoint::draw(HDC hdc, HWND hWnd, bool isForwardConnector, float x, float y, float width, float height, float defaultHeight, int currentIndex, int totalConnections){
	HBRUSH hBrush;
	HPEN hPen = NULL;
	int returnVal = -1;
	listSize = totalConnections;
	index = currentIndex;
	totalConnections -= 1;
	if (isUnconnectedArc){
		drawUnconnectedArc(hdc, hWnd, getMouseX(), getMouseY());
	}
	//draw forwards connection arrows
	POINT pt[3];
	if (isForwardConnector){
		pt[0].x = (LONG)correctX(x + width - 1);
		pt[0].y = (LONG)correctY(y + (height / 2) + (defaultHeight / 2)*(index - float(totalConnections) / 2));
		pt[1].x = (LONG)correctX(x + width - 11);
		pt[1].y = (LONG)correctY(y + (height / 2) + (defaultHeight / 2)*(index - float(totalConnections) / 2) - 5);
		pt[2].x = (LONG)correctX(x + (width - 11));
		pt[2].y = (LONG)correctY(y + (height / 2) + (defaultHeight / 2)*(index - float(totalConnections) / 2) + 5);
	}
	else{
		pt[0].x = (LONG)correctX(x + 1);
		pt[0].y = (LONG)correctY(y + (height / 2) + (defaultHeight / 2)*(index - float(totalConnections) / 2));
		pt[1].x = (LONG)correctX(x + 11);
		pt[1].y = (LONG)correctY(y + (height / 2) + (defaultHeight / 2)*(index - float(totalConnections) / 2) - 5);
		pt[2].x = (LONG)correctX(x + 11);
		pt[2].y = (LONG)correctY(y + (height / 2) + (defaultHeight / 2)*(index - float(totalConnections) / 2) + 5);
	}
	hPen = CreatePen(PS_SOLID, 1, RGB(0,0,0)); //give it a black outline
	if (connectionsList.size() > 0){ //if there are any nodes connected to this list, fill it
		hBrush = CreateSolidBrush(RGB(0, 0, 0)); //color the triangle black
	}
	else{//leave it blank
		hBrush = (HBRUSH)GetStockObject(HOLLOW_BRUSH); ///SelectObject(hdc, NULL);
	}
	//select the pen and brush
	SelectObject(hdc, hBrush);
	SelectObject(hdc, hPen);
	Polygon(hdc, pt, 3); //draw it!
	//draw the connection lines
	for (int i = 0; i < connectionsList.size(); i++){ //iterate through the connections list
		//data on the start of the line
		float startX;
		float startY;
		float endX;
		float endY;
		std::array<int, 8> line = connectionsList[i];
		//Make sure the index is correct
		if (isForwardConnector) { //if it is the RHS we are dealing with
			if (line[2] == 1) { //if the first element is connected  the right hand side, we need to update the ones connected on the LHS
				line[3] = index;
				connectionsList[i] = line;
				if (line[4] == 0) { //resource!
					OutputDebugString("Error: line[2] claims to be a RHS connection, and line[4] claims to be a resource node!\n");
				}
				else if (line[4] == 1 && ExtractorNodeList.size() > line[5] && ExtractorNodeList[line[5]].backwardsConnectionPointsList.size() > line[7] && ExtractorNodeList[line[5]].backwardsConnectionPointsList[line[7]].connectionsList.size() > 0){ //If extractor and we are not about to crash...
					ExtractorNodeList[line[5]].backwardsConnectionPointsList[line[7]].connectionsList[0] = line;
				}
				else if (line[4] == 2 && ProcessNodeList.size() > line[5] && ProcessNodeList[line[5]].backwardsConnectionPointsList.size() > line[7] && ProcessNodeList[line[5]].backwardsConnectionPointsList[line[7]].connectionsList.size() > 0) { //If extractor and we are not about to crash...
					ProcessNodeList[line[5]].backwardsConnectionPointsList[line[7]].connectionsList[0] = line;
				}
				else if (line[4] == 3 && ConsumerNodeList.size() > line[5] && ConsumerNodeList[line[5]].backwardsConnectionPointsList.size() > line[7] && ConsumerNodeList[line[5]].backwardsConnectionPointsList[line[7]].connectionsList.size() > 0) { //If extractor and we are not about to crash...
					ConsumerNodeList[line[5]].backwardsConnectionPointsList[line[7]].connectionsList[0] = line;
				}
				else if (line[4] == 4 && StorageNodeList.size() > line[5] && StorageNodeList[line[5]].backwardsConnectionPointsList.size() > line[7] && StorageNodeList[line[5]].backwardsConnectionPointsList[line[7]].connectionsList.size() > 0) { //If extractor and we are not about to crash...
					StorageNodeList[line[5]].backwardsConnectionPointsList[line[7]].connectionsList[0] = line;
				}
			}
			else if (line[6] == 1) { //else if the last element is connected to the RHS of a node
				line[7] = index;
				connectionsList[i] = line;
				//now update the other node (the one with LHS connections, and is on the RHS! Confused? :P)
				if (line[0] == 0){
					OutputDebugString("Error: line[6] claims to be a RHS connection, and line[0] claims to be a resource node!\n");
				}
				else if (line[0] == 1 && ExtractorNodeList.size() > line[1] && ExtractorNodeList[line[1]].backwardsConnectionPointsList.size() > line[3] && ExtractorNodeList[line[1]].backwardsConnectionPointsList[line[3]].connectionsList.size() > 0) { //Extractor!
					ExtractorNodeList[line[1]].backwardsConnectionPointsList[line[3]].connectionsList[0] = line;
				}
				else if (line[0] == 2 && ProcessNodeList.size() > line[1] && ProcessNodeList[line[1]].backwardsConnectionPointsList.size() > line[3] && ProcessNodeList[line[1]].backwardsConnectionPointsList[line[3]].connectionsList.size() > 0) {
					ProcessNodeList[line[1]].backwardsConnectionPointsList[line[3]].connectionsList[0] = line;
				}
				else if (line[0] == 3 && ConsumerNodeList.size() > line[1] && ConsumerNodeList[line[1]].backwardsConnectionPointsList.size() > line[3] && ConsumerNodeList[line[1]].backwardsConnectionPointsList[line[3]].connectionsList.size() > 0) {
					ConsumerNodeList[line[1]].backwardsConnectionPointsList[line[3]].connectionsList[0] = line;
				}
				else if (line[0] == 4 && StorageNodeList.size() > line[1] && StorageNodeList[line[1]].backwardsConnectionPointsList.size() > line[3] && StorageNodeList[line[1]].backwardsConnectionPointsList[line[3]].connectionsList.size() > 0) {
					StorageNodeList[line[1]].backwardsConnectionPointsList[line[3]].connectionsList[0] = line;
				}
			}
			else {
				OutputDebugString("Error: could not update forwards connection node index.");
			}
		}
		else { //if we are dealing with a backwards connector! So we need to update the forwards connectors!
			if (line[2] == 0) { //if the first element is connected on the left hand side, we need to update the ones connected on the RHS
				line[3] = index;
				connectionsList[i] = line;
				if (line[4] == 0 && ResourceNodeList.size() > line[5] && ResourceNodeList[line[5]].forwardsConnectionPointsList.size() > line[7] && ResourceNodeList[line[5]].forwardsConnectionPointsList[line[7]].connectionsList.size() > 0) {
					ResourceNodeList[line[5]].forwardsConnectionPointsList[line[7]].connectionsList[0] = line;
				}
				else if (line[4] == 1 && ExtractorNodeList.size() > line[5] && ExtractorNodeList[line[5]].forwardsConnectionPointsList.size() > line[7] && ExtractorNodeList[line[5]].forwardsConnectionPointsList[line[7]].connectionsList.size() > 0) {
					ExtractorNodeList[line[5]].forwardsConnectionPointsList[line[7]].connectionsList[0] = line;
				}
				else if (line[4] == 2 && ProcessNodeList.size() > line[5] && ProcessNodeList[line[5]].forwardsConnectionPointsList.size() > line[7] && ProcessNodeList[line[5]].forwardsConnectionPointsList[line[7]].connectionsList.size() > 0) {
					ProcessNodeList[line[5]].forwardsConnectionPointsList[line[7]].connectionsList[0] = line;
				}
				else if (line[4] == 3 && ConsumerNodeList.size() > line[5] && ConsumerNodeList[line[5]].forwardsConnectionPointsList.size() > line[7] && ConsumerNodeList[line[5]].forwardsConnectionPointsList[line[7]].connectionsList.size() > 0) {
					ConsumerNodeList[line[5]].forwardsConnectionPointsList[line[7]].connectionsList[0] = line;
				}
				else if (line[4] == 4 && StorageNodeList.size() > line[5] && StorageNodeList[line[5]].forwardsConnectionPointsList.size() > line[7] && StorageNodeList[line[5]].forwardsConnectionPointsList[line[7]].connectionsList.size() > 0) {
					StorageNodeList[line[5]].forwardsConnectionPointsList[line[7]].connectionsList[0] = line;
				}
			}
			else if (line[6] == 0) { //else if the last element is connected to the LHS of a node
				line[7] = index;
				connectionsList[i] = line;
				//now update the other node
				if (line[0] == 0 && ResourceNodeList.size() > line[1] && ResourceNodeList[line[1]].forwardsConnectionPointsList.size() > line[3] && ResourceNodeList[line[1]].forwardsConnectionPointsList[line[3]].connectionsList.size() > 0) { //Resource connection!
					ResourceNodeList[line[1]].forwardsConnectionPointsList[line[3]].connectionsList[0] = line;
				}
				else if (line[0] == 1 && ExtractorNodeList.size() > line[1] && ExtractorNodeList[line[1]].forwardsConnectionPointsList.size() > line[3] && ExtractorNodeList[line[1]].forwardsConnectionPointsList[line[3]].connectionsList.size() > 0) { //Extractor!
					ExtractorNodeList[line[1]].forwardsConnectionPointsList[line[3]].connectionsList[0] = line;
				}
				else if (line[0] == 2 && ProcessNodeList.size() > line[1] && ProcessNodeList[line[1]].forwardsConnectionPointsList.size() > line[3] && ProcessNodeList[line[1]].forwardsConnectionPointsList[line[3]].connectionsList.size() > 0) {
					ProcessNodeList[line[1]].forwardsConnectionPointsList[line[3]].connectionsList[0] = line;
				}
				else if (line[0] == 3 && ConsumerNodeList.size() > line[1] && ConsumerNodeList[line[1]].forwardsConnectionPointsList.size() > line[3] && ConsumerNodeList[line[1]].forwardsConnectionPointsList[line[3]].connectionsList.size() > 0) {
					ConsumerNodeList[line[1]].forwardsConnectionPointsList[line[3]].connectionsList[0] = line;
					break;
				}
				else if (line[0] == 4 && StorageNodeList.size() > line[1] && StorageNodeList[line[1]].forwardsConnectionPointsList.size() > line[3] && StorageNodeList[line[1]].forwardsConnectionPointsList[line[3]].connectionsList.size() > 0) {
					StorageNodeList[line[1]].forwardsConnectionPointsList[line[3]].connectionsList[0] = line;
				}
			}
			else {
				OutputDebugString("Error: could not update forwards connection node index.");
			}
		}
		if (line[2] == 0){//LHS
			if (line[0] == 0 && ResourceNodeList.size() > line[1]){//resource node
				//except resource nodes don't have any backwards nodes! Jokes on you, optimiser!
				OutputDebugString("Error: Line[0] claims to be a Resource Node with a LHS connection!\n");
			}
			else if (line[0] == 1 && ExtractorNodeList.size() > line[1]){//extraction node
				ExtractorNode startNode;
				startNode = ExtractorNodeList[line[1]]; //get the correct extractor node
				endX = startNode.x;
				endY = startNode.y + (startNode.height / 2) + (startNode.defaultHeight / 2)*(line[3] - float(startNode.backwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[0] == 2 && ProcessNodeList.size() > line[1]){//process node
				ProcessNode startNode;
				startNode = ProcessNodeList[line[1]]; //get the correct process node
				endX = startNode.x;
				endY = startNode.y + (startNode.height / 2) + (startNode.defaultHeight / 2)*(line[3] - float(startNode.backwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[0] == 3 && ConsumerNodeList.size() > line[1]){//consumer node
				ConsumerNode startNode;
				startNode = ConsumerNodeList[line[1]]; //get the correct consumer node
				endX = startNode.x;
				endY = startNode.y + (startNode.height / 2) + (startNode.defaultHeight / 2)*(line[3] - float(startNode.backwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[0] == 4 && StorageNodeList.size() > line[1]){//storage node
				StorageNode startNode;
				startNode = StorageNodeList[line[1]]; //get the correct storage node
				endX = startNode.x;
				endY = startNode.y + (startNode.height / 2) + (startNode.defaultHeight / 2)*(line[3] - float(startNode.backwardsConnectionPointsList.size() - 1) / 2);
			}
			else{
				OutputDebugString("Error: line[0] does not have a valid LHS value\n"); //give appropriate error message, and begin a new line in the debugger...
			}
		}
		else if (line[2] == 1){//RHS
			if (line[0] == 0 && ResourceNodeList.size() > line[1]){//resource node
				ResourceNode startNode;
				startNode = ResourceNodeList[line[1]]; //get the correct resource node
				startX = startNode.x + startNode.width-2;
				startY = startNode.y + (startNode.height / 2) + (startNode.defaultHeight / 2)*(line[3] - float(startNode.forwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[0] == 1 && ExtractorNodeList.size() > line[1]){//extraction node
				ExtractorNode startNode;
				startNode = ExtractorNodeList[line[1]]; //get the correct extractor node
				startX = startNode.x + startNode.width-2;
				startY = startNode.y + (startNode.height / 2) + (startNode.defaultHeight / 2)*(line[3] - float(startNode.forwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[0] == 2 && ProcessNodeList.size() > line[1]){//process node
				ProcessNode startNode;
				startNode = ProcessNodeList[line[1]]; //get the correct process node
				startX = startNode.x + startNode.width - 2;
				startY = startNode.y + (startNode.height / 2) + (startNode.defaultHeight / 2)*(line[3] - float(startNode.forwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[0] == 3 && ConsumerNodeList.size() > line[1]){//consumer node
				ConsumerNode startNode;
				startNode = ConsumerNodeList[line[1]]; //get the correct consumer node
				startX = startNode.x + startNode.width - 2;
				startY = startNode.y + (startNode.height / 2) + (startNode.defaultHeight / 2)*(line[3] - float(startNode.forwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[0] == 4 && StorageNodeList.size() > line[1]){//storage node
				StorageNode startNode;
				startNode = StorageNodeList[line[1]]; //get the correct storage node
				startX = startNode.x + startNode.width - 2;
				startY = startNode.y + (startNode.height / 2) + (startNode.defaultHeight / 2)*(line[3] - float(startNode.forwardsConnectionPointsList.size() - 1) / 2);
			}
			else{
				OutputDebugString("Error: line[0] does not have a valid RHS value\n");
			}
		}
		else{ //THERE HAS BEEN A BUG! RUN FOR THE HILLS!
			OutputDebugString("Error: Line[1] is neither 1, nor 0!\n");
		}
		//get data for the end of the line!
		if (line[6] == 0){//LHS
			if (line[4] == 0 && ResourceNodeList.size() > line[5]){//resource node
				//except resource nodes don't have any backwards nodes! Jokes on you, optimiser!
				OutputDebugString("Error: Line[4] claims to be a Resource Node with a LHS connection!\n"); //Complain, bitterly.
			}
			else if (line[4] == 1 && ExtractorNodeList.size() > line[5]){//extraction node
				ExtractorNode endNode;
				endNode = ExtractorNodeList[line[5]]; //get the correct extractor (parent) node
				endX = endNode.x;
				endY = endNode.y + (endNode.height / 2) + (endNode.defaultHeight / 2)*(line[7] - float(endNode.backwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[4] == 2 && ProcessNodeList.size() > line[5]){//process node
				ProcessNode endNode;
				endNode = ProcessNodeList[line[5]]; //get the correct process (parent) node
				endX = endNode.x;
				endY = endNode.y + (endNode.height / 2) + (endNode.defaultHeight / 2)*(line[7] - float(endNode.backwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[4] == 3 && ConsumerNodeList.size() > line[5]){//consumer node
				ConsumerNode endNode;
				endNode = ConsumerNodeList[line[5]]; //get the correct consumer (parent) node
				endX = endNode.x;
				endY = endNode.y + (endNode.height / 2) + (endNode.defaultHeight / 2)*(line[7] - float(endNode.backwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[4] == 4 && StorageNodeList.size() > line[5]){//storage node
				StorageNode endNode;
				endNode = StorageNodeList[line[5]]; //get the correct storage (parent) node
				endX = endNode.x;
				endY = endNode.y + (endNode.height / 2) + (endNode.defaultHeight / 2)*(line[7] - float(endNode.backwardsConnectionPointsList.size() - 1) / 2);
			}
			else{
				OutputDebugString(std::to_string(line[5]).c_str());
				OutputDebugString("Error: line[4] does not have a valid LHS value, or line[5] is out of range\n");
			}
		}
		else if (line[6] == 1){//RHS
			if (line[4] == 0 && ResourceNodeList.size() > line[5]){//resource node
				ResourceNode endNode;
				endNode = ResourceNodeList[line[5]]; //get the correct resource (parent) node
				startX = endNode.x+endNode.width-2;
				startY = endNode.y + (endNode.height / 2) + (endNode.defaultHeight / 2)*(line[7] - float(endNode.forwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[4] == 1 && ExtractorNodeList.size() > line[5]){//extraction node
				ExtractorNode endNode;
				endNode = ExtractorNodeList[line[5]]; //get the correct extractor (parent) node
				startX = endNode.x+endNode.width-2;
				startY = endNode.y + (endNode.height / 2) + (endNode.defaultHeight / 2)*(line[7] - float(endNode.forwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[4] == 2 && ProcessNodeList.size() > line[5]){//process node
				ProcessNode endNode;
				endNode = ProcessNodeList[line[5]]; //get the correct extractor (parent) node
				startX = endNode.x + endNode.width - 2;
				startY = endNode.y + (endNode.height / 2) + (endNode.defaultHeight / 2)*(line[7] - float(endNode.forwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[4] == 3 && ConsumerNodeList.size() > line[5]){//consumer node
				ConsumerNode endNode;
				endNode = ConsumerNodeList[line[5]]; //get the correct consumer (parent) node
				startX = endNode.x + endNode.width - 2;
				startY = endNode.y + (endNode.height / 2) + (endNode.defaultHeight / 2)*(line[7] - float(endNode.forwardsConnectionPointsList.size() - 1) / 2);
			}
			else if (line[4] == 4 && StorageNodeList.size() > line[5]){//storage node
				StorageNode endNode;
				endNode = StorageNodeList[line[5]]; //get the correct storage (parent) node
				startX = endNode.x + endNode.width - 2;
				startY = endNode.y + (endNode.height / 2) + (endNode.defaultHeight / 2)*(line[7] - float(endNode.forwardsConnectionPointsList.size() - 1) / 2);
			}
			else{
				OutputDebugString("Error: line[4] does not have a valid RHS value\n");
			}
		}
		else{ //THERE HAS BEEN A BUG! RUN FOR THE HILLS!
			OutputDebugString("Error: Line[1] is neither 1, nor 0!");
		}
		//update our start/end points so different line styles can update
		beginX = startX;
		beginY = startY;
		finishX = endX;
		finishY = endY;

		//and now *FINALLY* draw the line! Whew, that was hard!
		//Update the connections wires
		if (style != 4) { //If it's not custom shape. Let the user sort their own mess out!
			setStyle(style); //and update!
		}
		MoveToEx(hdc, (int)correctX(startX), (int)correctY(startY), NULL);
		bool hasFoundVertex = false; //To make sure we don't pick up random extra points
		bool lineDoubleClicked = false;
		for (int i = 0; i < additionalArcVertices.size() && style != 2; i++) { //draw any additional vertices in the line
			//set the pen color to be black
			SelectObject(hdc, GetStockObject(BLACK_PEN));
			LineTo(hdc, (int)correctX(additionalArcVertices[i][0]), (int)correctY(additionalArcVertices[i][1]));
			MoveToEx(hdc, (int)correctX(additionalArcVertices[i][0]), (int)correctY(additionalArcVertices[i][1]), NULL);
			if (isUserEditingLine) {
				SelectObject(hdc, GetStockObject(NULL_BRUSH)); //set our default circle colouring (nothing)
				//I find the lack of sq() in C++... concerning...
				if (!hasFoundVertex && (deCorrectX(getMouseX()) - additionalArcVertices[i][0]) * (deCorrectX(getMouseX()) - additionalArcVertices[i][0]) + ((deCorrectY(getMouseY()) - additionalArcVertices[i][1]) * (deCorrectY(getMouseY()) - additionalArcVertices[i][1])) < (5 + abs(getMouseX() - getLastMouseX()) + abs(getMouseY() - getLastMouseY()))*(5 + abs(getMouseY() - getLastMouseY()) + abs(getMouseX() - getLastMouseX()))) {
					hasFoundVertex = true; // make sure we don't pick up more than one vertex
					hBrush = CreateSolidBrush(RGB(255, 0, 0));
					SelectObject(hdc, hBrush);
					if (isMousePressedL()) { //make the vertices follow the mouse around while it's pressed
						additionalArcVertices[i][0] = deCorrectX(getMouseX());
						additionalArcVertices[i][1] = deCorrectY(getMouseY());
					}
					setStyle(4); //keep the other arcs updated
					isUserEditingLine = true; //make sure we don't flip states!
				}
				else if (isMouseLDblClk()) { //if the user has double clicked...
					if (isMouseOverLine(getMouseX(), getMouseY(), startX, startY, endX, endY) == i + 1) { //... first check if we are trying to add a new vertex
						float mouseX = deCorrectX(getMouseX());
						float mouseY = deCorrectY(getMouseY());
						std::array<float, 2> newPoint = { deCorrectX(getMouseX()), deCorrectY(getMouseY()) };
						std::vector<std::array<float, 2>>::iterator it = additionalArcVertices.begin();
						for (int j = 0; j < i; j++) {
							it++;
						}
						additionalArcVertices.insert(it, newPoint); //slip our new element in!
						lineDoubleClicked = true;
						break;
					}
				}
				hPen = CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
				SelectObject(hdc, hPen);
				Ellipse(hdc, correctX(additionalArcVertices[i][0] - 5), correctY(additionalArcVertices[i][1] - 5), correctX(additionalArcVertices[i][0] + 5), correctY(additionalArcVertices[i][1] + 5));
				DeleteObject(hPen);
				DeleteObject(hBrush);
			}
		}
		if (isMouseLDblClk() && !lineDoubleClicked) {
			if (isMouseOverLine(getMouseX(), getMouseY(), startX, startY, endX, endY) == additionalArcVertices.size()+2) {
				float mouseX = deCorrectX(getMouseX());
				float mouseY = deCorrectY(getMouseY());
				std::array<float, 2> newPoint = { deCorrectX(getMouseX()), deCorrectY(getMouseY()) };
				additionalArcVertices.push_back(newPoint); //slip our new element in!
				lineDoubleClicked = true;
			}
			else {
				setStyle(style); //make sure it is all updated!
				isUserEditingLine = false;
			}
		}
		//set the pen color to be black
		SelectObject(hdc, GetStockObject(BLACK_PEN));
		if (style != 2) {
			LineTo(hdc, correctX(endX), correctY(endY));
		}
		else {
			POINT curvePoints[6] = { (LONG)beginX,(LONG)beginY, LONG(beginX + 40),(LONG)beginY, LONG(beginX+endX)/2,LONG(beginY+endY)/2, LONG(beginX + endX) / 2,LONG(beginY + endY) / 2, LONG(endX - 40),(LONG)endY, (LONG)endX,(LONG)endY};
			PolyBezierTo(hdc, curvePoints, 3*2);
		}

		if (isMouseOverLine((float)getMouseX(), (float)getMouseY(), startX, startY, endX, endY)){
			returnVal = index;
		}
	}
	DeleteObject(hBrush);
	DeleteObject(hPen);
	return returnVal;
}

bool ConnectionPoint::placeConnection(int typeConnectedTo, int LR, int parentNodeIndex, int connectionIndex, int endTypeConnectedTo, int endLR, int endParentNodeIndex, int endConnectionIndex){
	isUnconnectedArc = false;
	if (connectionsList.size() == 0) { //for the moment we will only allow one arc per connector. Expect this to change soon(TM)!
		std::array <int, 8> newConnection = { typeConnectedTo, parentNodeIndex, LR, connectionIndex, endTypeConnectedTo, endParentNodeIndex, endLR, endConnectionIndex }; //create the array with relevant values
		connectionsList.push_back(newConnection); //push it onto the resource list.
		OutputDebugString("Placed connection\n");
	}
	setStyle(style); //make sure the relevant extra vertices appear...
	return false;
}

int ConnectionPoint::disconnectNode(int connectionIndex){
	additionalArcVertices.clear(); //remove all the connections!
	std::array<int, 8> thisConnection = connectionsList[0]; //get the list with all the relevant data...
	if (thisConnection[0] == 0){ //the start is a resource node
		if (thisConnection[2] == 0){ //this resource node apparently has a LHS node (heathen!), which means...
			OutputDebugString("Error: This connection claims to be connecting to the LHS of a resource node!\n"); //...error!
		}
		else if (thisConnection[2] == 1 && ResourceNodeList.size() > thisConnection[1] && ResourceNodeList[thisConnection[1]].forwardsConnectionPointsList.size() > thisConnection[3]){ //if it ends on the RHS
			ResourceNodeList[thisConnection[1]].forwardsConnectionPointsList[thisConnection[3]].connectionsList.erase(ResourceNodeList[thisConnection[1]].forwardsConnectionPointsList[thisConnection[3]].connectionsList.begin()); //remove the relevant connection!
		}
	}
	else if (thisConnection[0] == 1){ //the start end is an extractor node
		if (thisConnection[2] == 0 && ExtractorNodeList.size() > thisConnection[1] && ExtractorNodeList[thisConnection[1]].backwardsConnectionPointsList.size() > thisConnection[3]){ //deal with the LHS
			ExtractorNodeList[thisConnection[1]].backwardsConnectionPointsList[thisConnection[3]].connectionsList.erase(ExtractorNodeList[thisConnection[1]].backwardsConnectionPointsList[thisConnection[3]].connectionsList.begin()); //remove the relevant connection!
		}
		else if (thisConnection[2] == 1 && ExtractorNodeList.size() > thisConnection[1] && ExtractorNodeList[thisConnection[1]].forwardsConnectionPointsList.size() > thisConnection[3]){ //if it ends on the RHS
			ExtractorNodeList[thisConnection[1]].forwardsConnectionPointsList[thisConnection[3]].connectionsList.erase(ExtractorNodeList[thisConnection[1]].forwardsConnectionPointsList[thisConnection[3]].connectionsList.begin()); //remove the relevant connection!
		}
	}
	else if (thisConnection[0] == 2){ //the start end is a process node
		if (thisConnection[2] == 0 && ProcessNodeList.size() > thisConnection[1] && ProcessNodeList[thisConnection[1]].backwardsConnectionPointsList.size() > thisConnection[3]){ //deal with the LHS
			ProcessNodeList[thisConnection[1]].backwardsConnectionPointsList[thisConnection[3]].connectionsList.erase(ProcessNodeList[thisConnection[1]].backwardsConnectionPointsList[thisConnection[3]].connectionsList.begin()); //remove the relevant connection!
		}
		else if (thisConnection[2] == 1 && ProcessNodeList.size() > thisConnection[1] && ProcessNodeList[thisConnection[1]].forwardsConnectionPointsList.size() > thisConnection[3]){ //it ends on the RHS
			ProcessNodeList[thisConnection[1]].forwardsConnectionPointsList[thisConnection[3]].connectionsList.erase(ProcessNodeList[thisConnection[1]].forwardsConnectionPointsList[thisConnection[3]].connectionsList.begin()); //remove the relevant connection!
		}
	}
	else if (thisConnection[0] == 3){ //the start end is a consumer node
		if (thisConnection[2] == 0 && ConsumerNodeList.size() > thisConnection[1] && ConsumerNodeList[thisConnection[1]].backwardsConnectionPointsList.size() > thisConnection[3]){ //deal with the LHS
			ConsumerNodeList[thisConnection[1]].backwardsConnectionPointsList[thisConnection[3]].connectionsList.erase(ConsumerNodeList[thisConnection[1]].backwardsConnectionPointsList[thisConnection[3]].connectionsList.begin()); //remove the relevant connection!
		}
		else if (thisConnection[2] == 1 && ConsumerNodeList.size() > thisConnection[1] && ConsumerNodeList[thisConnection[1]].forwardsConnectionPointsList.size() > thisConnection[3]){ //if it ends on the RHS
			ConsumerNodeList[thisConnection[1]].forwardsConnectionPointsList[thisConnection[3]].connectionsList.erase(ConsumerNodeList[thisConnection[1]].forwardsConnectionPointsList[thisConnection[3]].connectionsList.begin()); //remove the relevant connection!
		}
	}
	else if (thisConnection[0] == 4){ //the start end is a storage node
		if (thisConnection[2] == 0 && StorageNodeList.size() > thisConnection[1] && StorageNodeList[thisConnection[1]].backwardsConnectionPointsList.size() > thisConnection[3] ){ //deal with the LHS
			StorageNodeList[thisConnection[1]].backwardsConnectionPointsList[thisConnection[3]].connectionsList.erase(StorageNodeList[thisConnection[1]].backwardsConnectionPointsList[thisConnection[3]].connectionsList.begin()); //remove the relevant connection!
		}
		else if (thisConnection[2] == 1 && StorageNodeList.size() > thisConnection[1] && StorageNodeList[thisConnection[1]].forwardsConnectionPointsList.size() > thisConnection[3]){ //if it ends on the RHS
			StorageNodeList[thisConnection[1]].forwardsConnectionPointsList[thisConnection[3]].connectionsList.erase(StorageNodeList[thisConnection[1]].forwardsConnectionPointsList[thisConnection[3]].connectionsList.begin()); //remove the relevant connection!
		}
	}


	if (thisConnection[4] == 0){ //the other end is a resource node
		if (thisConnection[6] == 0){ //this resource node apparently has a LHS node which means...
			OutputDebugString("Error: This connection claims to be connecting to the LHS of a resource node!\n"); //...an error!
		}
		else if (thisConnection[6] == 1 && ResourceNodeList.size() > thisConnection[5] && ResourceNodeList[thisConnection[5]].forwardsConnectionPointsList.size() > thisConnection[7]){ //if it ends on the RHS, and we aren't about to crash...
			ResourceNodeList[thisConnection[5]].forwardsConnectionPointsList[thisConnection[7]].connectionsList.erase(ResourceNodeList[thisConnection[5]].forwardsConnectionPointsList[thisConnection[7]].connectionsList.begin()); //remove the connection!
		}
	}
	else if (thisConnection[4] == 1){ //the other end is an extractor node
		if (thisConnection[6] == 0 && ExtractorNodeList.size() > thisConnection[5] && ExtractorNodeList[thisConnection[5]].backwardsConnectionPointsList.size() > thisConnection[7]){ //LHS
			ExtractorNodeList[thisConnection[5]].backwardsConnectionPointsList[thisConnection[7]].connectionsList.erase(ExtractorNodeList[thisConnection[5]].backwardsConnectionPointsList[thisConnection[7]].connectionsList.begin()); //remove the connection!
		}
		else if (thisConnection[6] == 1 && ExtractorNodeList.size() > thisConnection[5] && ExtractorNodeList[thisConnection[5]].forwardsConnectionPointsList.size() > thisConnection[7]){ //if it ends on the RHS
			ExtractorNodeList[thisConnection[5]].forwardsConnectionPointsList[thisConnection[7]].connectionsList.erase(ExtractorNodeList[thisConnection[5]].forwardsConnectionPointsList[thisConnection[7]].connectionsList.begin()); //remove the relevant node!
		}
	}
	else if (thisConnection[4] == 2){ //the other end is a process node
		if (thisConnection[6] == 0 && ProcessNodeList.size() > thisConnection[5] && ProcessNodeList[thisConnection[5]].backwardsConnectionPointsList.size() > thisConnection[7]){ //LHS
			ProcessNodeList[thisConnection[5]].backwardsConnectionPointsList[thisConnection[7]].connectionsList.erase(ProcessNodeList[thisConnection[5]].backwardsConnectionPointsList[thisConnection[7]].connectionsList.begin()); //remove the connection!
		}
		else if (thisConnection[6] == 1 && ProcessNodeList.size() > thisConnection[5] && ProcessNodeList[thisConnection[5]].forwardsConnectionPointsList.size() > thisConnection[7]){ //if it ends on the RHS
			ProcessNodeList[thisConnection[5]].forwardsConnectionPointsList[thisConnection[7]].connectionsList.erase(ProcessNodeList[thisConnection[5]].forwardsConnectionPointsList[thisConnection[7]].connectionsList.begin()); //remove the relevant node!
		}
	}
	else if (thisConnection[4] == 3){ //the other end is a consumer node
		if (thisConnection[6] == 0 && ConsumerNodeList.size() > thisConnection[5] && ConsumerNodeList[thisConnection[5]].backwardsConnectionPointsList.size() > thisConnection[7]){ //LHS
			ConsumerNodeList[thisConnection[5]].backwardsConnectionPointsList[thisConnection[7]].connectionsList.erase(ConsumerNodeList[thisConnection[5]].backwardsConnectionPointsList[thisConnection[7]].connectionsList.begin()); //remove the connection!
		}
		else if (thisConnection[6] == 1 && ConsumerNodeList.size() > thisConnection[5] && ConsumerNodeList[thisConnection[5]].forwardsConnectionPointsList.size() > thisConnection[7]){ //if it ends on the RHS
			ConsumerNodeList[thisConnection[5]].forwardsConnectionPointsList[thisConnection[7]].connectionsList.erase(ConsumerNodeList[thisConnection[5]].forwardsConnectionPointsList[thisConnection[7]].connectionsList.begin()); //remove the relevant node!
		}
	}
	else if (thisConnection[4] == 4){ //the other end is a storage node
		if (thisConnection[6] == 0 && StorageNodeList.size() > thisConnection[5] && StorageNodeList[thisConnection[5]].backwardsConnectionPointsList.size() > thisConnection[7]){ //LHS
			StorageNodeList[thisConnection[5]].backwardsConnectionPointsList[thisConnection[7]].connectionsList.erase(StorageNodeList[thisConnection[5]].backwardsConnectionPointsList[thisConnection[7]].connectionsList.begin()); //remove the connection!
		}
		else if (thisConnection[6] == 1 && StorageNodeList.size() > thisConnection[5] && StorageNodeList[thisConnection[5]].forwardsConnectionPointsList.size() > thisConnection[7]){ //if it ends on the RHS
			StorageNodeList[thisConnection[5]].forwardsConnectionPointsList[thisConnection[7]].connectionsList.erase(StorageNodeList[thisConnection[5]].forwardsConnectionPointsList[thisConnection[7]].connectionsList.begin()); //remove the relevant node!
		}
	}
	return 0;
}

//change the style of the connecting arc
int ConnectionPoint::setStyle(int newStyle) {
	if (newStyle == 0) { //A single, straight, line
		style = 0;
		additionalArcVertices.clear(); //clear out any additional vertices
		isUserEditingLine = false; //Make sure those little red circles will dissappear!
	}
	else if (newStyle == 1) { //Each end has a straight line, followed by a diagonal
		additionalArcVertices.clear(); //clear out any additional vertices
		style = 1;
		std::array<float, 2> newPoint = { beginX + 20, beginY };
		additionalArcVertices.push_back(newPoint);
		newPoint = { finishX - 20, finishY };
		additionalArcVertices.push_back(newPoint);
		isUserEditingLine = false;
	}
	else if (newStyle == 2) { //Spline curve
		additionalArcVertices.clear(); //clear out any additional vertices
		style = 2;
		std::array<float, 2> newPoint = { beginX + 40, beginY };
		additionalArcVertices.push_back(newPoint);
		newPoint = { finishX - 40, finishY };
		additionalArcVertices.push_back(newPoint);

		isUserEditingLine = false;
	}
	else if (newStyle == 3) { //Perpendicular style
		additionalArcVertices.clear(); //clear out any additional vertices
		style = 3;
		std::array<float, 2> newPoint = { (beginX + finishX) / 2, beginY };
		additionalArcVertices.push_back(newPoint);
		newPoint = { (beginX + finishX) / 2, finishY };
		additionalArcVertices.push_back(newPoint);
		isUserEditingLine = false;
	}
	else if (newStyle == 4) { //Custom style. The user can position the vertices as they wish.
		style = 4;
		isUserEditingLine = !isUserEditingLine; //invert the editing state!
	}

	//And now we deal with the node we are connected to!
	if (connectionsList.size() > 0) { //avoid any embarrassments
		std::array<int, 8> otherConnection = connectionsList[0];
		if (otherConnection[2] == 0) { //LHS, aka the other end...
			if (otherConnection[0] == 1) { //resource nodes do not have LHS connections, so we start with extractors
				if (ExtractorNodeList.size() > otherConnection[1] && ExtractorNodeList[otherConnection[1]].backwardsConnectionPointsList.size() > otherConnection[3]) { //prevent a potential crash!
					ExtractorNodeList[otherConnection[1]].backwardsConnectionPointsList[otherConnection[3]].style = newStyle;
					ExtractorNodeList[otherConnection[1]].backwardsConnectionPointsList[otherConnection[3]].additionalArcVertices = additionalArcVertices; //copy across the arc vertices!
				}
			}
			else if (otherConnection[0] == 2) { //Process node
				if (ProcessNodeList.size() > otherConnection[1] && ProcessNodeList[otherConnection[1]].backwardsConnectionPointsList.size() > otherConnection[3]) {
					ProcessNodeList[otherConnection[1]].backwardsConnectionPointsList[otherConnection[3]].style = newStyle;
					ProcessNodeList[otherConnection[1]].backwardsConnectionPointsList[otherConnection[3]].additionalArcVertices = additionalArcVertices; //copy across the arc vertices!
				}
			}
			else if (otherConnection[0] == 3) { //Consumer node
				if (ConsumerNodeList.size() > otherConnection[1] && ConsumerNodeList[otherConnection[1]].backwardsConnectionPointsList.size() > otherConnection[3]) {
					ConsumerNodeList[otherConnection[1]].backwardsConnectionPointsList[otherConnection[3]].style = newStyle;
					ConsumerNodeList[otherConnection[1]].backwardsConnectionPointsList[otherConnection[3]].additionalArcVertices = additionalArcVertices; //copy across the arc vertices!
				}
			}
			else if (otherConnection[0] == 4) { //Storage node
				if (StorageNodeList.size() > otherConnection[1] && StorageNodeList[otherConnection[1]].backwardsConnectionPointsList.size() > otherConnection[3]) {
					StorageNodeList[otherConnection[1]].backwardsConnectionPointsList[otherConnection[3]].style = newStyle;
					StorageNodeList[otherConnection[1]].backwardsConnectionPointsList[otherConnection[3]].additionalArcVertices = additionalArcVertices; //copy across the arc vertices!
				}
			}
		}
		else if (otherConnection[6] == 0) { //LHS, aka the other end...
			if (otherConnection[4] == 1) { //resource nodes do not have LHS connections, so we start with extractors, since we are always modifying from L->R
				if (ExtractorNodeList.size() > otherConnection[5] && ExtractorNodeList[otherConnection[5]].backwardsConnectionPointsList.size() > otherConnection[7]) {
					ExtractorNodeList[otherConnection[5]].backwardsConnectionPointsList[otherConnection[7]].style = newStyle;
					ExtractorNodeList[otherConnection[5]].backwardsConnectionPointsList[otherConnection[7]].additionalArcVertices = additionalArcVertices; //copy across the arc vertices!
				}
			}
			else if (otherConnection[4] == 2) { //Process node
				if (ProcessNodeList.size() > otherConnection[5] && ProcessNodeList[otherConnection[5]].backwardsConnectionPointsList.size() > otherConnection[7]) {
					ProcessNodeList[otherConnection[5]].backwardsConnectionPointsList[otherConnection[7]].style = newStyle;
					ProcessNodeList[otherConnection[5]].backwardsConnectionPointsList[otherConnection[7]].additionalArcVertices = additionalArcVertices; //copy across the arc vertices!
				}
			}
			else if (otherConnection[4] == 3) { //Consumer node
				if (ConsumerNodeList.size() > otherConnection[5] && ConsumerNodeList[otherConnection[5]].backwardsConnectionPointsList.size() > otherConnection[7]) {
					ConsumerNodeList[otherConnection[5]].backwardsConnectionPointsList[otherConnection[7]].style = newStyle;
					ConsumerNodeList[otherConnection[5]].backwardsConnectionPointsList[otherConnection[7]].additionalArcVertices = additionalArcVertices; //copy across the arc vertices!
				}
			}
			else if (otherConnection[4] == 4) { //Storage node
				if (StorageNodeList.size() > otherConnection[5] && StorageNodeList[otherConnection[5]].backwardsConnectionPointsList.size() > otherConnection[7]) {
					StorageNodeList[otherConnection[5]].backwardsConnectionPointsList[otherConnection[7]].style = newStyle;
					StorageNodeList[otherConnection[5]].backwardsConnectionPointsList[otherConnection[7]].additionalArcVertices = additionalArcVertices; //copy across the arc vertices!
				}
			}
		}
	}

	return newStyle;
}

/*************************************************************************
*
*	Resource Node Class:
*	Stores all the data for a resource node in the resources flowchart
*	The beginning element of any flowchart.
*
**************************************************************************/

//Constructor
ResourceNode::ResourceNode(float xpos, float ypos, float Width, float Height, std::vector<ConnectionPoint> ForwardsConnections){
	x = xpos;
	y = ypos;
	defaultWidth = Width;
	defaultHeight = Height;
	width = defaultWidth;
	height = defaultHeight;
	//add the requested forwards connections
	forwardsConnectionPointsList = ForwardsConnections;
	isPlaced = false; //default to being unplaced
	showTitle = true; //default to displaying the title

	//and now extract all the data from the node creation window!
	char data[32];
	GetWindowText(getNodeNameBox(), data, 32);
	name = data;
	SendMessage(getNodeDescBox(), WM_GETTEXT, sizeof(desc) / sizeof(desc[0]), reinterpret_cast<LPARAM>(desc));
}

//default constructor. Does nothing of real consequence, apart from allowing me to create blank resources without issues.
ResourceNode::ResourceNode(){
}

//Destructor
ResourceNode::~ResourceNode(){
}

//Draw loop!
int ResourceNode::draw(HDC hdc, HWND hWnd, int mouseX, int mouseY, bool highlight){
	HPEN hPen;
	HBRUSH hBrush;
	HFONT hFont;
	mouseX = (int)deCorrectX(float(mouseX));
	mouseY = (int)deCorrectY(float(mouseY));
	if (highlight){
		hPen = CreatePen(PS_SOLID, 2, RGB(255, 255, 255)); //draw a thin white outline
	}
	else{
		hPen = CreatePen(PS_NULL, 0, NULL); //don't color it!
	}
	SelectObject(hdc, hPen);

	//draw main rectangle
	if (isPlaced){ //if it is free-floating, following the mouse...
		hBrush = CreateSolidBrush(RGB(252, 119, 31)); //color the node a darker orange when placed. Why orange? All nodes lead to Mars!
	}
	else{
		hBrush = CreateSolidBrush(RGB(255, 75, 0)); //color the unplaced rectangle a lighter orange
		//make the node follow the mouse around
		x = mouseX;
		y = mouseY;
	}
	SelectObject(hdc, hBrush); //select the brush
	if (forwardsConnectionPointsList.size() > 0 && height < (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size())){
		height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
	}
	else if(height < defaultHeight){ //make sure it doesn't go all squishy
		height = defaultHeight;
	}
	if (width < defaultWidth / 2) {
		width = defaultWidth / 2;
	}
	RoundRect(hdc, (int)correctX(x), (int)correctY(y), (int)correctX(x + width), (int)correctY(y + height), int(defaultHeight*getZoomFactor()), int(defaultHeight*getZoomFactor())); //draw the surrounding rectangle, and scale it.
	DeleteObject(hBrush);

	isMouseOverArc = -1;

	//draw forwards connection arrows
	for (int i = 0; i < forwardsConnectionPointsList.size(); i++){
		int currentVal = isMouseOverArc;
		isMouseOverArc = forwardsConnectionPointsList[i].draw(hdc, hWnd, true, x,y, width, height, defaultHeight, i, forwardsConnectionPointsList.size()); //draw, and find out which (if any) line the mouse is over.
		if (currentVal != -1) {
			isMouseOverArc = currentVal; //make sure we get the arc the mouse is really over, not just the first arc!
		}
	}

	SetTextColor(hdc, RGB(0, 0, 0)); //set text black
	hFont = CreateFont(int(16 * getZoomFactor()), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
	SelectObject(hdc, hFont);
	RECT textRect{ (LONG)correctX(x+20), (LONG)correctY(y+(height/2)-16/2), (LONG)correctX(x+width-20), LONG(correctY(y+(height/2) + (16/2)*int(height/defaultHeight))) };
	DrawText(hdc, name.c_str(), name.size(), &textRect, DT_CENTER | DT_WORD_ELLIPSIS);
	DeleteObject(hFont);

	//draw node type name above the node
	if (showTitle) { //user permitting!
		hFont = CreateFont(int(17*getZoomFactor()), 0, 0, 0, FW_HEAVY, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		std::string nodeTitle = "Resource";
		RECT titleRect = { (LONG)correctX(x), LONG(correctY(y) - 17 * getZoomFactor()), (LONG)correctX(x + width), (LONG)correctY(y) }; //define the rectangle to draw the text where we want it
		DrawText(hdc, nodeTitle.c_str(), nodeTitle.size(), &titleRect, DT_CENTER | DT_SINGLELINE | DT_NOCLIP); //Draw the text. We don't clip because it's faster & we don't need to!
		DeleteObject(hFont);
	}

	if (unlockSize) { //if the node's sizing has been unlocked, show the resize handles and resize!
		std::array <int, 4> resizedPos = resizeNode(hdc, x, y, defaultWidth, defaultHeight, width, height, forwardsConnectionPointsList.size());
		x = float(resizedPos[0]);
		y = float(resizedPos[1]);
		width = float(resizedPos[2]);
		height = float(resizedPos[3]);
	}

	//and now for the tooltip (my hands down favourite bit of GUI programming ever!)
	if (isMouseOverNode(getMouseX(), getMouseY()) && !unlockSize) {
		if (!tooltipActive) {
			tooltipActive = true;
			DescTooltip = createTooltip(hWnd, DescTooltip, desc); //create the tooltip
		}
	}
	else if (tooltipActive) { //if the mouse is no longer over the node
		DescTooltip = destroyTooltip(DescTooltip); //destroy the tooltip
		tooltipActive = false;
	}

	//Clear up memory
	DeleteObject(hPen);
	DeleteObject(hBrush);
	return 0;
}

//place the node
bool ResourceNode::place(int mouseX, int mouseY){
	x = (int)deCorrectX(mouseX);
	y = (int)deCorrectY(mouseY);
	isPlaced = true;
	return true;
}

bool ResourceNode::isMouseOverNode(int mouseX, int mouseY){
	if ((!unlockSize && deCorrectX(mouseX) > x && deCorrectX(mouseX) < x + width) || (unlockSize && deCorrectX(mouseX) > x-10 && deCorrectX(mouseX) < x + width + 10)){ //we are within x bounds
		if ((!unlockSize && deCorrectY(mouseY) > y && deCorrectY(mouseY) < y + height) || (unlockSize && deCorrectY(mouseY) > y - 10 && deCorrectY(mouseY) < y + height + 10)){ //we are within y bounds
			return true;
		}
	}
	return false;
}

//check to see if a connection node has been clicked. Called upon the mouse being released. Returns the index of the connection
int ResourceNode::isConnectionNodeClicked(int mouseX, int mouseY, bool modify){
	mouseX = (int)deCorrectX(float(mouseX));
	mouseY = (int)deCorrectY(float(mouseY));
	if (!unlockSize && mouseX > x + width - 13 && mouseX < x + width){//if the mouse is within the x bounds
		for (int i = 0; i < forwardsConnectionPointsList.size(); i++){
			if (mouseY > (y + (height / 2) + (defaultHeight / 2)*(i - float(forwardsConnectionPointsList.size()-1) / 2) - 6) && mouseY < (y + (height / 2) + (defaultHeight / 2)*(i - float(forwardsConnectionPointsList.size()-1) / 2) + 6)){ //if the mouse is within the y bounds
				if (modify){ //observe, and modify!
					if (forwardsConnectionPointsList[i].isFreeFloating == true){
						//de-free float it if it is clicked again
						forwardsConnectionPointsList[i].isFreeFloating = false; //modify
						return -1; //and observe
					}
					else{
						//or free float it, and return the connection index
						forwardsConnectionPointsList[i].isFreeFloating = true; //modify
						return i; //and observe
					}
				}
				else{
					return i; //just observe
				}
			}
		}
	}
	return -1;
}

//add a forwards connection at the specified position
int ResourceNode::addForwardsConnection(int index){
	std::vector<ConnectionPoint>::iterator it = forwardsConnectionPointsList.begin();
	ConnectionPoint newConnectionPoint(index);
	forwardsConnectionPointsList.insert(it + index, newConnectionPoint); //add it!
	//and now update all the other connections!
	for (int i = index+1; i < forwardsConnectionPointsList.size(); i++){ //iterate through all the other connection nodes after the updated one
		forwardsConnectionPointsList[i].index++; //increment the stored indices
		for (int j = 0; j < forwardsConnectionPointsList[i].connectionsList.size(); j++){
			std::array<int, 8> connectionData = forwardsConnectionPointsList[i].connectionsList[j];
			if (connectionData[2] == 1){ //if startpoint is RHS
				OutputDebugString("Updating resource node RHS as startpoint\n");
				connectionData[3]++; //increment the connection's index on the resource node
				//Now update the node it is connected to!
				if (connectionData[4] == 1){ //Extractor node. No zero since resource nodes cannot be daisy-chained
					std::vector<std::array<int,8>> endPointData = ExtractorNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
			}
			else if (connectionData[6] == 1){ //if endpoint is RHS
				OutputDebugString("Updating resource node RHS as endpoint\n");
				connectionData[7]++; //increment the endpoint on the resource node!
				//Now update the node(s) it is connected to!
				if (connectionData[0] == 1){ //Extractor node. No zero since resource nodes cannot be daisy-chained
					std::vector<std::array<int,8>> endPointData = ExtractorNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
			}
			forwardsConnectionPointsList[i].connectionsList[j] = connectionData;
		}
	}
	return 0;
}

int ResourceNode::removeForwardsConnection(int index){ //remove a connection from the list
	return 0;
}

int ResourceNode::resize(int mode, HWND hWnd) {
	SIZE textSize; //structure which we will store details about the string's physical dimensions
	PAINTSTRUCT ps; //create all the stuff we need to to simulate a drawing environment
	HDC thisHDC = BeginPaint(hWnd, &ps);
	HFONT hFont = CreateFont(15 * getZoomFactor(), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL); //duplicate the normal font
	SelectObject(thisHDC, hFont);
	GetTextExtentPoint32(thisHDC, name.c_str(), name.size(), &textSize);
	
	if (mode == 0) { //reset
		width = defaultWidth;
		name.erase(std::remove(name.begin(), name.end(), '\n'), name.end()); //remove all instances of newlines that might be present
		if (forwardsConnectionPointsList.size() > 0) {
			height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
		}
		else { //make sure it doesn't go all squishy
			height = defaultHeight;
		}
	}
	else if (mode == 1) { //reset to single Line
		name.erase(std::remove(name.begin(), name.end(), '\n'), name.end()); //remove all instances of newlines that might be present
		if (textSize.cx+44 > defaultWidth / 2) { //check we really do want to resize this...
			width = textSize.cx + 44; //44. Give ourselves 4 pixels of leeway!
			if (forwardsConnectionPointsList.size() > 0) { //and now deal with the height!
				height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
			}
			else { //make sure it doesn't go all squishy
				height = defaultHeight;
			}
		}
	}
	else if (mode == 2) { //set to multi line
		if (textSize.cx + 30 > defaultWidth / 2) { //check we really do want to resize this...
			name = getResizeMultilineText(thisHDC, name, width, height, defaultHeight);
		}
	}
	DeleteObject(hFont);
	EndPaint(hWnd, &ps); //and remove this artificial environment!
	return 0;
}

/*************************************************************************
*
*	Extractor Node Class:
*	Stores all the data for a extractor node in the resources flowchart
*
**************************************************************************/

//Constructor
ExtractorNode::ExtractorNode(float xpos, float ypos, float Width, float Height, std::vector<ConnectionPoint> ForwardsConnections, std::vector<ConnectionPoint> BackwardsConnections){
	x = deCorrectX(xpos);
	y = deCorrectY(ypos);
	defaultWidth = Width;
	defaultHeight = Height;
	width = defaultWidth;
	height = defaultHeight;
	isPlaced = false;
	showTitle = true; //default to displaying the title
	//add requested forwards and backwards nodes
	forwardsConnectionPointsList = ForwardsConnections;
	backwardsConnectionPointsList = BackwardsConnections;

	//and now extract all the data!
	char data[32];
	GetWindowText(getNodeNameBox(), data, 32);
	name = data;
	SendMessage(getNodeDescBox(), WM_GETTEXT, sizeof(desc) / sizeof(desc[0]), reinterpret_cast<LPARAM>(desc));
}

//Default constructor
ExtractorNode::ExtractorNode(){
}

//Destructor
ExtractorNode::~ExtractorNode(){
}

//Draw loop!
int ExtractorNode::draw(HDC hdc, HWND hWnd, int mouseX, int mouseY, bool highlight) {
	HPEN hPen;
	HBRUSH hBrush;
	HFONT hFont;
	if (highlight) {
		hPen = CreatePen(PS_SOLID, 2, RGB(255, 255, 255)); //draw a thin white outline
	}
	else {
		hPen = CreatePen(PS_NULL, 0, NULL); //don't color it!
	}
	SelectObject(hdc, hPen);
	//draw main rectangle
	if (isPlaced) {
		SetBkColor(hdc, RGB(0, 82, 165)); //color the text dark blue so it won't show
		hBrush = CreateSolidBrush(RGB(0, 82, 165));
		SelectObject(hdc, hBrush); //color it a darker blue when placed
	}
	else {
		SetBkColor(hdc, RGB(0, 121, 231)); //color the text dark blue so it won't show
		hBrush = CreateSolidBrush(RGB(0, 121, 231)); // colour the unplaced rectangle a lighter blue
		SelectObject(hdc, hBrush);
		//making the node follow the mouse around
		x = (int)deCorrectX(float(mouseX));
		y = (int)deCorrectY(float(mouseY));
	}

	if (forwardsConnectionPointsList.size() > backwardsConnectionPointsList.size() && forwardsConnectionPointsList.size() > 0 && height < (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size())) {
		height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
	}
	else if (backwardsConnectionPointsList.size() > 0 && height < (defaultHeight / 2)*(1 + backwardsConnectionPointsList.size())) {
		height = (defaultHeight / 2)*(1 + backwardsConnectionPointsList.size());
	}
	else if (height < defaultHeight) { //make sure it doesn't go all squishy
		height = defaultHeight;
	}
	if (width < defaultWidth / 2) {
		width = defaultWidth / 2;
	}
	RoundRect(hdc, (int)correctX(x), (int)correctY(y), (int)correctX(x + width), (int)correctY(y + height), int(defaultHeight*getZoomFactor()), int(defaultHeight*getZoomFactor())); //draw the surrounding rectangle, and scale it.
	DeleteObject(hBrush);

	//draw the forwards and backwards connection arrows
	isMouseOverArc = -1;
	for (int i = 0; i < forwardsConnectionPointsList.size(); i++) {
		int currentVal = isMouseOverArc;
		isMouseOverArc = forwardsConnectionPointsList[i].draw(hdc, hWnd, true, x, y, width, height, defaultHeight, i, forwardsConnectionPointsList.size()); //draw, and query if the mouse is over any connecting arcs
		if (currentVal != -1) {
			isMouseOverArc = currentVal; //make sure we get the arc the mouse is really over, not just the first arc!
		}
	}
	for (int i = 0; i < backwardsConnectionPointsList.size(); i++) {
		backwardsConnectionPointsList[i].draw(hdc, hWnd, false, x, y, width, height, defaultHeight, i, backwardsConnectionPointsList.size());
	}

	//draw text showing extractor name
	SetTextColor(hdc, RGB(0, 0, 0)); //set text black
	hFont = CreateFont(int(16 * getZoomFactor()), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
	SelectObject(hdc, hFont);
	RECT textRect{ (LONG)correctX(x + 20), (LONG)correctY(y + (height / 2) - (16 / 2)), (LONG)correctX(x + width - 20), (LONG)correctY(y + (height / 2) + (16 / 2)*int(height / defaultHeight)) };
	DrawText(hdc, name.c_str(), name.size(), &textRect, DT_CENTER | DT_WORD_ELLIPSIS);
	DeleteObject(hFont);

	//draw node type name above the node
	if (showTitle) { //user permitting!
		hFont = CreateFont(int(17 * getZoomFactor()), 0, 0, 0, FW_HEAVY, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		std::string nodeTitle = "Extractor";
		RECT titleRect = { (LONG)correctX(x), LONG(correctY(y) - 17 * getZoomFactor()), (LONG)correctX(x + width), (LONG)correctY(y) }; //define the rectangle to draw the text where we want it
		DrawText(hdc, nodeTitle.c_str(), nodeTitle.size(), &titleRect, DT_CENTER | DT_SINGLELINE | DT_NOCLIP); //Draw the text. We don't clip because it's faster & we don't need to!
		DeleteObject(hFont);
	}

	if (unlockSize) { //if the node's sizing has been unlocked, show the resize handles and resize!
		int largestList;
		if (forwardsConnectionPointsList.size() > backwardsConnectionPointsList.size()) {
			largestList = forwardsConnectionPointsList.size();
		}
		else {
			largestList = backwardsConnectionPointsList.size();
		}
		std::array <int, 4> resizedPos = resizeNode(hdc, x, y, defaultWidth, defaultHeight, width, height, largestList);
		x = float(resizedPos[0]);
		y = float(resizedPos[1]);
		width = float(resizedPos[2]);
		height = float(resizedPos[3]);
	}

	//and now for the description tooltip
	if (isMouseOverNode(getMouseX(), getMouseY())) {
		if (!tooltipActive) {
			tooltipActive = true;
			DescTooltip = createTooltip(hWnd, DescTooltip, desc); //create the tooltip
		}
	}
	else if (tooltipActive) { //if the mouse is no longer over the node
		DescTooltip = destroyTooltip(DescTooltip); //destroy the tooltip
		tooltipActive = false;
	}

	//Clear up memory
	DeleteObject(hPen);
	DeleteObject(hBrush);
	DeleteObject(hFont);
	return 0;
}

//place the node
bool ExtractorNode::place(int mouseX, int mouseY){
	x = deCorrectX(float(mouseX));
	y = deCorrectY(float(mouseY));
	isPlaced = true;
	return true;
}

bool ExtractorNode::isMouseOverNode(int mouseX, int mouseY){
	if ((!unlockSize && deCorrectX(mouseX) > x && deCorrectX(mouseX) < x + width) || (unlockSize && deCorrectX(mouseX) > x - 10 && deCorrectX(mouseX) < x + width + 10)) { //we are within x bounds
		if ((!unlockSize && deCorrectY(mouseY) > y && deCorrectY(mouseY) < y + height) || (unlockSize && deCorrectY(mouseY) > y - 10 && deCorrectY(mouseY) < y + height + 10)) { //we are within y bounds
			return true;
		}
	}
	return false;
}

//check to see if a connection node has been clicked. Called upon the mouse being released
int ExtractorNode::isBackwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify){
	mouseX = (int)deCorrectX(float(mouseX));
	mouseY = (int)deCorrectY(float(mouseY));
	if (mouseX > x && mouseX < x + 13){//if the mouse is within the x bounds
		for (int i = 0; i < backwardsConnectionPointsList.size(); i++){
			if (mouseY > (y + (height / 2) + (defaultHeight / 2)*(i - float(backwardsConnectionPointsList.size() - 1) / 2) - 6) && mouseY < (y + (height / 2) + (defaultHeight / 2)*(i - float(backwardsConnectionPointsList.size() - 1) / 2) + 6)) { //if the mouse is within the y bounds
				if (modify){ //change, and observe!
					if (backwardsConnectionPointsList[i].isFreeFloating == true){
						backwardsConnectionPointsList[i].isFreeFloating = false;
						return -1;
					}
					else{
						backwardsConnectionPointsList[i].isFreeFloating = true;
						return i;
					}
				}
				else{ //just observe
					return i;
				}
			}
		}
	}
	return -1;
}

//check to see if a connection node has been clicked. Called upon the mouse being released
int ExtractorNode::isForwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify){
	mouseX = (int)deCorrectX(float(mouseX));
	mouseY = (int)deCorrectY(float(mouseY));
	if (mouseX > x + width - 13 && mouseX < x + width){//if the mouse is within the x bounds
		for (int i = 0; i < forwardsConnectionPointsList.size(); i++){
			if (mouseY > (y + (height / 2) + (defaultHeight / 2)*(i - float(forwardsConnectionPointsList.size() - 1) / 2) - 6) && mouseY < (y + (height / 2) + (defaultHeight / 2)*(i - float(forwardsConnectionPointsList.size() - 1) / 2) + 6)) { //if the mouse is within the y bounds
				if (modify){
					if (forwardsConnectionPointsList[i].isFreeFloating == true){
						forwardsConnectionPointsList[i].isFreeFloating = false;
						return -1;
					}
					else{
						forwardsConnectionPointsList[i].isFreeFloating = true;
						return i;
					}
				}
				else{
					return i; //just observe, don't change if false
				}
			}
		}
	}
	return -1;
}

//add a forwards connection at the specified position
int ExtractorNode::addForwardsConnection(int index){
	std::vector<ConnectionPoint>::iterator it = forwardsConnectionPointsList.begin();
	ConnectionPoint newConnectionPoint(index);
	forwardsConnectionPointsList.insert(it + index, newConnectionPoint); //add it!
	//and now update all the other connections!
	for (int i = index + 1; i < forwardsConnectionPointsList.size(); i++){ //iterate through all the other connection nodes after the updated one
		forwardsConnectionPointsList[i].index++; //increment the stored indices
		for (int j = 0; j < forwardsConnectionPointsList[i].connectionsList.size(); j++){
			std::array<int, 8> connectionData = forwardsConnectionPointsList[i].connectionsList[j];
			if (connectionData[2] == 1){ //if startpoint is RHS
				OutputDebugString("Updating extractor node RHS as startpoint\n");
				connectionData[3]++; //increment the connection's index on the resource node

				//Now update the node it is connected to!
				if (connectionData[4] == 1){ //Extractor node. No zero since resource nodes do not have backwards connections
					std::vector<std::array<int, 8>> endPointData = ExtractorNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 2){ //Process node.
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the process node list
					ProcessNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 3){ //Consumer node.
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the consumer node list
					ConsumerNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 4){ //Storage node.
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the storage node list
					StorageNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
			}
			else if (connectionData[6] == 1){ //if endpoint is RHS
				OutputDebugString("Updating extractor node RHS as endpoint\n");
				connectionData[7]++; //increment the endpoint on the resource node!
				//Now update the node(s) it is connected to!
				if (connectionData[0] == 1){ //Extractor node. No zero since resource nodes cannot be daisy-chained
					std::vector<std::array<int, 8>> endPointData = ExtractorNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 2){ //Process node.
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					ProcessNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 3){ //Consumer node.
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					ConsumerNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 4){ //Storage node.
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					StorageNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
			}
			forwardsConnectionPointsList[i].connectionsList[j] = connectionData;
		}
	}
	return 0;
}

//add a backwards connection at the specified position
int ExtractorNode::addBackwardsConnection(int index){
	std::vector<ConnectionPoint>::iterator it = backwardsConnectionPointsList.begin();
	ConnectionPoint newConnectionPoint(index);
	backwardsConnectionPointsList.insert(it + index, newConnectionPoint); //add it!
	//and now update all the other connections! (the hard bit...)
	for (int i = index + 1; i < backwardsConnectionPointsList.size(); i++){ //iterate through all the other connection nodes after the updated one
		backwardsConnectionPointsList[i].index++; //increment the stored indices
		for (int j = 0; j < backwardsConnectionPointsList[i].connectionsList.size(); j++){
			std::array<int, 8> connectionData = backwardsConnectionPointsList[i].connectionsList[j];
			if (connectionData[2] == 0){ //if startpoint is LHS
				OutputDebugString("Updating extractor node LHS as startpoint\n");
				connectionData[3]++; //increment the connection's index on the resource node
				//Now update the node it is connected to!
				if (connectionData[4] == 0){ //Resource node connection
					OutputDebugString("Resource\n");
					std::vector<std::array<int, 8>> endPointData = ResourceNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					ResourceNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 1){ //Extractor node connection
					OutputDebugString("Extractor\n");
					std::vector<std::array<int, 8>> endPointData = ExtractorNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
			}
			else if (connectionData[6] == 0){ //if endpoint is LHS
				OutputDebugString("Updating extractor node LHS as endpoint\n");
				connectionData[7]++; //increment the endpoint on the resource node!
				//Now update the node(s) it is connected to!
				if (connectionData[0] == 0){ //Resource node
					OutputDebugString("Resource\n");
					std::vector<std::array<int, 8>> endPointData = ResourceNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					ResourceNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 1){//extractor node!
					OutputDebugString("Extractor\n");
					std::vector<std::array<int, 8>> endPointData = ExtractorNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
			}
			backwardsConnectionPointsList[i].connectionsList[j] = connectionData; //make sure this node has updated itself also
		}
	}
	return 0;
}

int ExtractorNode::removeForwardsConnection(int index){ //remove a connection from the list
	return 0;
}

int ExtractorNode::removeBackwardsConnection(int index){ //remove a connection from the list
	return 0;
}

int ExtractorNode::resize(int mode, HWND hWnd) {
	SIZE textSize; //structure which we will store details about the string's physical dimensions
	PAINTSTRUCT ps; //create all the stuff we need to to simulate a drawing environment
	HDC thisHDC = BeginPaint(hWnd, &ps);
	HFONT hFont = CreateFont(int(15 * getZoomFactor()), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL); //duplicate the normal font
	SelectObject(thisHDC, hFont);
	GetTextExtentPoint32(thisHDC, name.c_str(), name.size(), &textSize);

	if (mode == 0) { //reset
		width = defaultWidth;
		name.erase(std::remove(name.begin(), name.end(), '\n'), name.end()); //remove all instances of newlines that might be present
		if (forwardsConnectionPointsList.size() > 0) {
			height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
		}
		else { //make sure it doesn't go all squishy
			height = defaultHeight;
		}
	}
	else if (mode == 1) { //reset to single Line
		name.erase(std::remove(name.begin(), name.end(), '\n'), name.end()); //remove all instances of newlines that might be present
		if (textSize.cx + 44 > defaultWidth / 2) { //check we really do want to resize this...
			width = float(textSize.cx + 44); //44. Give ourselves 4 pixels of leeway!
			if (forwardsConnectionPointsList.size() > 0) { //and now deal with the height!
				height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
			}
			else { //make sure it doesn't go all squishy
				height = defaultHeight;
			}
		}
	}
	else if (mode == 2) { //set to multi line
		if (textSize.cx + 30 > defaultWidth / 2) { //check we really do want to resize this...
			name = getResizeMultilineText(thisHDC, name, width, height, defaultHeight);
		}
	}
	DeleteObject(hFont);
	EndPaint(hWnd, &ps); //and remove this artificial environment!
	return 0;
}

/*************************************************************************
*
*	Industrial Process Node Class:
*	Stores all the data for a industrial process node in the resources
*	flowchart.
*
**************************************************************************/

//Constructor
ProcessNode::ProcessNode(float xpos, float ypos, float Width, float Height, std::vector<ConnectionPoint> ForwardsConnections, std::vector<ConnectionPoint> BackwardsConnections){
	x = correctX(xpos);
	y = correctY(ypos);
	defaultWidth = Width;
	defaultHeight = Height;
	width = defaultWidth;
	height = defaultHeight;
	isPlaced = false;
	showTitle = true; //default to displaying the title
	//add a forwards and backwards nodes as requested
	forwardsConnectionPointsList = ForwardsConnections;
	backwardsConnectionPointsList = BackwardsConnections;

	//and now extract all the data!
	char data[32];
	GetWindowText(getNodeNameBox(), data, 32);
	name = data;
	SendMessage(getNodeDescBox(), WM_GETTEXT, sizeof(desc) / sizeof(desc[0]), reinterpret_cast<LPARAM>(desc));
}

ProcessNode::ProcessNode(){
}

//Destructor
ProcessNode::~ProcessNode(){
}

//Draw loop!
int ProcessNode::draw(HDC hdc, HWND hWnd, int mouseX, int mouseY, bool highlight){
	HPEN hPen;
	HBRUSH hBrush;
	HFONT hFont;
	if (highlight){
		hPen = CreatePen(PS_SOLID, 2, RGB(255, 255, 255)); //draw a thin white outline
	}
	else{
		hPen = CreatePen(PS_NULL, 0, NULL); //don't color it!
	}
	SelectObject(hdc, hPen);
	//draw main rectangle
	if (isPlaced){
		hBrush = CreateSolidBrush(RGB(18, 173, 42)); //color it a darker green
		SetBkColor(hdc, RGB(18, 173, 42)); //color the text dark green so it won't show
	}
	else{
		hBrush = CreateSolidBrush(RGB(99, 209, 62)); //color the unplaced rectangle a lighter green
		SetBkColor(hdc, RGB(99, 209, 62)); //color the text dark green so it won't show
		//make it follow the mouse around
		x = deCorrectX(float(mouseX));
		y = deCorrectY(float(mouseY));
	}
	SelectObject(hdc, hBrush);
	//draw surrounding round-cornered rectangle
	if (forwardsConnectionPointsList.size() > backwardsConnectionPointsList.size() && forwardsConnectionPointsList.size() > 0 && height < (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size())) {
		height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
	}
	else if (backwardsConnectionPointsList.size() > 0 && height < (defaultHeight / 2)*(1 + backwardsConnectionPointsList.size())) {
		height = (defaultHeight / 2)*(1 + backwardsConnectionPointsList.size());
	}
	else if (height < defaultHeight) { //make sure it doesn't go all squishy
		height = defaultHeight;
	}
	if (width < defaultWidth / 2) {
		width = defaultWidth / 2;
	}
	RoundRect(hdc, (int)correctX(x), (int)correctY(y), (int)correctX(x + width), (int)correctY(y + height), int(defaultHeight*getZoomFactor()), int(defaultHeight*getZoomFactor())); //draw the surrounding rectangle, and scale it.
	DeleteObject(hBrush);

	//draw the forwards and backwards connection arrows
	isMouseOverArc = -1;
	for (int i = 0; i < forwardsConnectionPointsList.size(); i++) {
		int currentVal = isMouseOverArc;
		isMouseOverArc = forwardsConnectionPointsList[i].draw(hdc, hWnd, true, x, y, width, height, defaultHeight, i, forwardsConnectionPointsList.size()); //draw, and query if the mouse is over any connecting arcs
		if (currentVal != -1) {
			isMouseOverArc = currentVal; //make sure we get the arc the mouse is really over, not just the first arc!
		}
	}
	for (int i = 0; i < backwardsConnectionPointsList.size(); i++) {
		backwardsConnectionPointsList[i].draw(hdc, hWnd, false, x, y, width, height, defaultHeight, i, backwardsConnectionPointsList.size());
	}

	//draw text showing process name
	SetTextColor(hdc, RGB(0, 0, 0)); //set text black
	hFont = CreateFont(int(16 * getZoomFactor()), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
	SelectObject(hdc, hFont);
	RECT textRect{ (LONG)correctX(x + 20), (LONG)correctY(y + (height / 2) - (16 / 2)), (LONG)correctX(x + width - 20), (LONG)correctY(y + (height / 2) + (16 / 2)*int(height / defaultHeight)) };
	DrawText(hdc, name.c_str(), name.size(), &textRect, DT_CENTER | DT_WORD_ELLIPSIS);
	DeleteObject(hFont);

	//draw node type name above the node
	if (showTitle) { //user permitting!
		hFont = CreateFont(int(17 * getZoomFactor()), 0, 0, 0, FW_HEAVY, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		std::string nodeTitle = "Process";
		RECT titleRect = { (LONG)correctX(x), LONG(correctY(y) - 17 * getZoomFactor()), (LONG)correctX(x + width), (LONG)correctY(y) }; //define the rectangle to draw the text where we want it
		DrawText(hdc, nodeTitle.c_str(), nodeTitle.size(), &titleRect, DT_CENTER | DT_SINGLELINE | DT_NOCLIP); //Draw the text. We don't clip because it's faster & we don't need to!
		DeleteObject(hFont);
	}

	if (unlockSize) { //if the node's sizing has been unlocked, show the resize handles and resize!
		int largestList;
		if (forwardsConnectionPointsList.size() > backwardsConnectionPointsList.size()) {
			largestList = forwardsConnectionPointsList.size();
		}
		else {
			largestList = backwardsConnectionPointsList.size();
		}
		std::array <int, 4> resizedPos = resizeNode(hdc, x, y, defaultWidth, defaultHeight, width, height, largestList);
		x = float(resizedPos[0]);
		y = float(resizedPos[1]);
		width = float(resizedPos[2]);
		height = float(resizedPos[3]);
	}

	//and now for the description tooltip
	if (isMouseOverNode(getMouseX(), getMouseY())) {
		if (!tooltipActive) {
			tooltipActive = true;
			DescTooltip = createTooltip(hWnd, DescTooltip, desc); //create the tooltip
		}
	}
	else if (tooltipActive) { //if the mouse is no longer over the node
		DescTooltip = destroyTooltip(DescTooltip); //destroy the tooltip
		tooltipActive = false;
	}

	//Clear up memory
	DeleteObject(hPen);
	DeleteObject(hBrush);
	DeleteObject(hFont);
	return 0;
}

//place the node
bool ProcessNode::place(int mouseX, int mouseY){
	x = deCorrectX(float(mouseX));
	y = deCorrectY(float(mouseY));
	isPlaced = true;
	return true;
}

bool ProcessNode::isMouseOverNode(int mouseX, int mouseY){
	mouseX = (int)deCorrectX(float(mouseX));
	mouseY = (int)deCorrectY(float(mouseY));
	if ((!unlockSize && (mouseX) > x && (mouseX) < x + width) || (unlockSize && (mouseX) > x - 10 && (mouseX) < x + width + 10)) { //we are within x bounds
		if ((!unlockSize && (mouseY) > y && (mouseY) < y + height) || (unlockSize && (mouseY) > y - 10 && (mouseY) < y + height + 10)) { //we are within y bounds
			return true;
		}
	}
	return false;
}

//check to see if a connection node has been clicked. Called upon the mouse being released
int ProcessNode::isBackwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify){ //modify has a default true value
	mouseX = (int)deCorrectX((float)mouseX);
	mouseY = (int)deCorrectY((float)mouseY);
	if (mouseX > x && mouseX < x + 13){//if the mouse is within the x bounds
		for (int i = 0; i < backwardsConnectionPointsList.size(); i++){
			if (mouseY >(y + (height / 2) + (defaultHeight / 2)*(i - float(backwardsConnectionPointsList.size() - 1) / 2) - 6) && mouseY < (y + (height / 2) + (defaultHeight / 2)*(i - float(backwardsConnectionPointsList.size() - 1) / 2) + 6)) { //if the mouse is within the y bounds
				if (modify){ //change, and observe!
					if (backwardsConnectionPointsList[i].isFreeFloating == true){
						backwardsConnectionPointsList[i].isFreeFloating = false;
						return -1;
					}
					else{
						backwardsConnectionPointsList[i].isFreeFloating = true;
						return i;
					}
				}
				else{ //just observe
					return i;
				}
			}
		}
	}
	return -1;
}

//check to see if a connection node has been clicked. Called upon the mouse being released
int ProcessNode::isForwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify){ //modify has a default true value
	mouseX = (int)deCorrectX(float(mouseX));
	mouseY = (int)deCorrectY(float(mouseY));
	if (mouseX > x + width - 13 && mouseX < x + width){//if the mouse is within the x bounds
		for (int i = 0; i < forwardsConnectionPointsList.size(); i++){
			if (mouseY > (y + (height / 2) + (defaultHeight / 2)*(i - float(forwardsConnectionPointsList.size() - 1) / 2) - 6) && mouseY < (y + (height / 2) + (defaultHeight / 2)*(i - float(forwardsConnectionPointsList.size() - 1) / 2) + 6)) { //if the mouse is within the y bounds
				if (modify){ //change, and observe!
					if (forwardsConnectionPointsList[i].isFreeFloating == true){
						forwardsConnectionPointsList[i].isFreeFloating = false;
						return -1;
					}
					else{
						forwardsConnectionPointsList[i].isFreeFloating = true;
						return i;
					}
				}
				else{ //just observe
					return i;
				}
			}
		}
	}
	return -1;
}

//add a forwards connection at the specified position
int ProcessNode::addForwardsConnection(int index){
	std::vector<ConnectionPoint>::iterator it = forwardsConnectionPointsList.begin();
	ConnectionPoint newConnectionPoint(index);
	forwardsConnectionPointsList.insert(it + index, newConnectionPoint); //add it!
	//and now update all the other connections!
	for (int i = index + 1; i < forwardsConnectionPointsList.size(); i++){ //iterate through all the other connection nodes after the updated one
		forwardsConnectionPointsList[i].index++; //increment the stored indices
		for (int j = 0; j < forwardsConnectionPointsList[i].connectionsList.size(); j++){
			std::array<int, 8> connectionData = forwardsConnectionPointsList[i].connectionsList[j];
			if (connectionData[2] == 1){ //if startpoint is RHS
				OutputDebugString("Updating with process node RHS as startpoint\n");
				connectionData[3]++; //increment the connection's index on the process node
				//Now update the node it is connected to!
				if (connectionData[4] == 2){ //Another Process node
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					ProcessNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 3){ //Consumer node
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					ConsumerNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 4){ //Storage node
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					StorageNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
			}
			else if (connectionData[6] == 1){ //if endpoint is RHS
				OutputDebugString("Updating process node with RHS as endpoint\n");
				connectionData[7]++; //increment the endpoint on the resource node!
				//Now update the node(s) it is connected to!
				if (connectionData[0] == 2){ //Another process node
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the process node list
					ProcessNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 3){ //Consumer node.
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the consumer node list
					ConsumerNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 4){ //Storage node.
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the storage node list
					StorageNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
			}
			forwardsConnectionPointsList[i].connectionsList[j] = connectionData;
		}
	}
	return 0;
}

//add a backwards connection at the specified position
int ProcessNode::addBackwardsConnection(int index){
	std::vector<ConnectionPoint>::iterator it = backwardsConnectionPointsList.begin();
	ConnectionPoint newConnectionPoint(index);
	backwardsConnectionPointsList.insert(it + index, newConnectionPoint); //add it!
	//and now update all the other connections! (the hard bit...)
	for (int i = index + 1; i < backwardsConnectionPointsList.size(); i++){ //iterate through all the other connection nodes after the updated one
		backwardsConnectionPointsList[i].index++; //increment the stored indices
		for (int j = 0; j < backwardsConnectionPointsList[i].connectionsList.size(); j++){
			std::array<int, 8> connectionData = backwardsConnectionPointsList[i].connectionsList[j];
			if (connectionData[2] == 0){ //if startpoint is LHS
				OutputDebugString("Updating extractor node LHS as startpoint\n");
				connectionData[3]++; //increment the connection's index on the resource node
				//Now update the node it is connected to!
				if (connectionData[0] == 1){ //Extractor node connection
					OutputDebugString("Extractor\n");
					std::vector<std::array<int, 8>> endPointData = ExtractorNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 2){ //Another process node connection
					OutputDebugString("Process\n");
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					ProcessNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 3){ //consumer node connection
					OutputDebugString("Consumer\n");
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					ConsumerNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 4){ //Storage node connection
					OutputDebugString("Storage\n");
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					StorageNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
			}
			else if (connectionData[6] == 0){ //if endpoint is LHS
				OutputDebugString("Updating extractor node LHS as endpoint\n");
				connectionData[7]++; //increment the endpoint on the resource node!
				//Now update the node(s) it is connected to!
				if (connectionData[0] == 1){ //Extractor node
					OutputDebugString("Extractor\n");
					std::vector<std::array<int, 8>> endPointData = ExtractorNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 2){//Process node!
					OutputDebugString("Process\n");
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					ProcessNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 3){//Consumer node!
					OutputDebugString("Consumer\n");
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					ConsumerNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 4){//Storage node!
					OutputDebugString("Storage\n");
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					StorageNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
			}
			backwardsConnectionPointsList[i].connectionsList[j] = connectionData; //make sure this node has updated itself also
		}
	}
	return 0;
}

int ProcessNode::removeForwardsConnection(int index){ //remove a connection from the list
	return 0;
}

int ProcessNode::removeBackwardsConnection(int index){ //remove a connection from the list
	return 0;
}

int ProcessNode::resize(int mode, HWND hWnd) {
	SIZE textSize; //structure which we will store details about the string's physical dimensions
	PAINTSTRUCT ps; //create all the stuff we need to to simulate a drawing environment
	HDC thisHDC = BeginPaint(hWnd, &ps);
	HFONT hFont = CreateFont(int(15 * getZoomFactor()), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL); //duplicate the normal font
	SelectObject(thisHDC, hFont);
	GetTextExtentPoint32(thisHDC, name.c_str(), name.size(), &textSize);

	if (mode == 0) { //reset
		width = defaultWidth;
		name.erase(std::remove(name.begin(), name.end(), '\n'), name.end()); //remove all instances of newlines that might be present
		if (forwardsConnectionPointsList.size() > 0) {
			height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
		}
		else { //make sure it doesn't go all squishy
			height = defaultHeight;
		}
	}
	else if (mode == 1) { //reset to single Line
		name.erase(std::remove(name.begin(), name.end(), '\n'), name.end()); //remove all instances of newlines that might be present
		if (textSize.cx + 44 > defaultWidth / 2) { //check we really do want to resize this...
			width = float(textSize.cx + 44); //44. Give ourselves 4 pixels of leeway!
			if (forwardsConnectionPointsList.size() > 0) { //and now deal with the height!
				height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
			}
			else { //make sure it doesn't go all squishy
				height = defaultHeight;
			}
		}
	}
	else if (mode == 2) { //set to multi line
		if (textSize.cx + 30 > defaultWidth / 2) { //check we really do want to resize this...
			name = getResizeMultilineText(thisHDC, name, width, height, defaultHeight);
		}
	}
	DeleteObject(hFont);
	EndPaint(hWnd, &ps); //and remove this artificial environment!
	return 0;
}



/*************************************************************************
*
*	Consumer Node Class:
*	Stores all the data for a consumer node in the resources flowchart
*	Normally the end of any flowchart
*
**************************************************************************/

//Constructor
ConsumerNode::ConsumerNode(float xpos, float ypos, float Width, float Height, std::vector<ConnectionPoint> ForwardsConnections, std::vector<ConnectionPoint> BackwardsConnections){
	x = deCorrectX(xpos);
	y = deCorrectY(ypos);
	defaultWidth = Width;
	defaultHeight = Height;
	width = defaultWidth;
	height = defaultHeight;
	isPlaced = false;
	showTitle = true; //default to displaying the title
	//add a default forwards and backwards node
	ConnectionPoint newConnectionPoint(0);
	forwardsConnectionPointsList = ForwardsConnections;
	backwardsConnectionPointsList = BackwardsConnections;

	//and now extract all the data!
	char data[32];
	GetWindowText(getNodeNameBox(), data, 32);
	name = data;
	SendMessage(getNodeDescBox(), WM_GETTEXT, sizeof(desc) / sizeof(desc[0]), reinterpret_cast<LPARAM>(desc));
}

ConsumerNode::ConsumerNode(){
}

//Destructor
ConsumerNode::~ConsumerNode(){
}

//Draw loop!
int ConsumerNode::draw(HDC hdc, HWND hWnd, int mouseX, int mouseY, bool highlight){
	HPEN hPen;
	HBRUSH hBrush;
	HFONT hFont = NULL;
	if (highlight){
		hPen = CreatePen(PS_SOLID, 2, RGB(255, 255, 255)); //draw a thin white outline
	}
	else{
		hPen = CreatePen(PS_NULL, 0, NULL); //don't color it!
	}
	SelectObject(hdc, hPen);
	//draw main rectangle
	if (isPlaced){
		hBrush = CreateSolidBrush(RGB(100, 100, 100)); //color it a darker grey
		SetBkColor(hdc, RGB(100, 100, 100)); //color the text square dark grey so it won't show
	}
	else{
		hBrush = CreateSolidBrush(RGB(150, 150, 150)); //color the unplaced rectangle a lighter blue
		SetBkColor(hdc, RGB(150, 150, 150)); //color the text square dark grey so it won't show
		//make the node follow the mouse around
		x = deCorrectX(float(mouseX));
		y = deCorrectY(float(mouseY));
	}
	SelectObject(hdc, hBrush);
	//Draw the round-cornered rectangle
	if (forwardsConnectionPointsList.size() > backwardsConnectionPointsList.size() && forwardsConnectionPointsList.size() > 0 && height < (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size())) {
		height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
	}
	else if (backwardsConnectionPointsList.size() > 0 && height < (defaultHeight / 2)*(1 + backwardsConnectionPointsList.size())) {
		height = (defaultHeight / 2)*(1 + backwardsConnectionPointsList.size());
	}
	else if (height < defaultHeight) { //make sure it doesn't go all squishy
		height = defaultHeight;
	}
	if (width < defaultWidth / 2) {
		width = defaultWidth / 2;
	}
	RoundRect(hdc, (int)correctX(x), (int)correctY(y), (int)correctX(x + width), (int)correctY(y + height), int(defaultHeight*getZoomFactor()), int(defaultHeight*getZoomFactor())); //draw the surrounding rectangle, and scale it.
	DeleteObject(hBrush);

	//draw the forwards and backwards connection arrows
	isMouseOverArc = -1;
	for (int i = 0; i < forwardsConnectionPointsList.size(); i++) {
		int currentVal = isMouseOverArc;
		isMouseOverArc = forwardsConnectionPointsList[i].draw(hdc, hWnd, true, x, y, width, height, defaultHeight, i, forwardsConnectionPointsList.size()); //draw, and query if the mouse is over any connecting arcs
		if (currentVal != -1) {
			isMouseOverArc = currentVal; //make sure we get the arc the mouse is really over, not just the first arc!
		}
	}
	for (int i = 0; i < backwardsConnectionPointsList.size(); i++) {
		backwardsConnectionPointsList[i].draw(hdc, hWnd, false, x, y, width, height, defaultHeight, i, backwardsConnectionPointsList.size());
	}

	//draw text showing consumer name
	SetTextColor(hdc, RGB(0, 0, 0)); //set text black
	hFont = CreateFont(int(16 * getZoomFactor()), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
	SelectObject(hdc, hFont);
	RECT textRect{ (LONG)correctX(x + 20), (LONG)correctY(y + (height / 2) - (16 / 2)), (LONG)correctX(x + width - 20), (LONG)correctY(y + (height / 2) + (16 / 2)*int(height / defaultHeight)) };
	DrawText(hdc, name.c_str(), name.size(), &textRect, DT_CENTER | DT_WORD_ELLIPSIS);
	DeleteObject(hFont);

	//draw node type name above the node
	if (showTitle) { //user permitting!
		hFont = CreateFont(int(17 * getZoomFactor()), 0, 0, 0, FW_HEAVY, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		std::string nodeTitle = "Consumer";
		RECT titleRect = { correctX(x), correctY(y) - 17 * getZoomFactor(), correctX(x + width), correctY(y) }; //define the rectangle to draw the text where we want it
		DrawText(hdc, nodeTitle.c_str(), nodeTitle.size(), &titleRect, DT_CENTER | DT_SINGLELINE | DT_NOCLIP); //Draw the text. We don't clip because it's faster & we don't need to!
		DeleteObject(hFont);
	}

	if (unlockSize) { //if the node's sizing has been unlocked, show the resize handles and resize!
		int largestList;
		if (forwardsConnectionPointsList.size() > backwardsConnectionPointsList.size()) {
			largestList = forwardsConnectionPointsList.size();
		}
		else {
			largestList = backwardsConnectionPointsList.size();
		}
		std::array <int, 4> resizedPos = resizeNode(hdc, x, y, defaultWidth, defaultHeight, width, height, largestList);
		x = float(resizedPos[0]);
		y = float(resizedPos[1]);
		width = float(resizedPos[2]);
		height = float(resizedPos[3]);
	}

	//and now for the description tooltip
	if (isMouseOverNode(getMouseX(), getMouseY())) {
		if (!tooltipActive) {
			tooltipActive = true;
			DescTooltip = createTooltip(hWnd, DescTooltip, desc); //create the tooltip
		}
	}
	else if (tooltipActive) { //if the mouse is no longer over the node
		DescTooltip = destroyTooltip(DescTooltip); //destroy the tooltip
		tooltipActive = false;
	}

	//Clear up memory
	DeleteObject(hPen);
	DeleteObject(hBrush);
	DeleteObject(hFont);
	return 0;
}

//place the node
bool ConsumerNode::place(int mouseX, int mouseY){
	x = deCorrectX(float(mouseX));
	y = deCorrectY(float(mouseY));
	isPlaced = true;
	return true;
}

bool ConsumerNode::isMouseOverNode(int mouseX, int mouseY){
	mouseX = (int)deCorrectX(float(mouseX));
	mouseY = (int)deCorrectY(float(mouseY));
	if ((!unlockSize && (mouseX) > x && (mouseX) < x + width) || (unlockSize && (mouseX) > x - 10 && (mouseX) < x + width + 10)) { //we are within x bounds
		if ((!unlockSize && (mouseY) > y && (mouseY) < y + height) || (unlockSize && (mouseY) > y - 10 && (mouseY) < y + height + 10)) { //we are within y bounds
			return true;
		}
	}
	return false;
}

//check to see if a connection node has been clicked. Called upon the mouse being released
int ConsumerNode::isBackwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify){ //modify has a default true value
	mouseX = (int)deCorrectX(float(mouseX));
	mouseY = (int)deCorrectY(float(mouseY));
	if (mouseX > x && mouseX < x + 13){//if the mouse is within the x bounds
		for (int i = 0; i < backwardsConnectionPointsList.size(); i++){
			if (mouseY > (y + (height / 2) + (defaultHeight / 2)*(i - float(backwardsConnectionPointsList.size() - 1) / 2) - 6) && mouseY < (y + (height / 2) + (defaultHeight / 2)*(i - float(backwardsConnectionPointsList.size() - 1) / 2) + 6)) { //if the mouse is within the y bounds
				if (modify){ //change, and observe!
					if (backwardsConnectionPointsList[i].isFreeFloating == true){
						backwardsConnectionPointsList[i].isFreeFloating = false;
						return -1;
					}
					else{
						backwardsConnectionPointsList[i].isFreeFloating = true;
						return i;
					}
				}
				else{ //just observe
					return i;
				}
			}
		}
	}
	return -1;
}

//check to see if a connection node has been clicked. Called upon the mouse being released
int ConsumerNode::isForwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify){ //modify has a default true value
	mouseX = (int)deCorrectX(float(mouseX));
	mouseY = (int)deCorrectY(float(mouseY));
	if (mouseX > x + width - 13 && mouseX < x + width){//if the mouse is within the x bounds
		for (int i = 0; i < forwardsConnectionPointsList.size(); i++){
			if (mouseY > (y + (height / 2) + (defaultHeight / 2)*(i - float(forwardsConnectionPointsList.size() - 1) / 2) - 6) && mouseY < (y + (height / 2) + (defaultHeight / 2)*(i - float(forwardsConnectionPointsList.size() - 1) / 2) + 6)) { //if the mouse is within the y bounds
				if (modify){ //change, and observe!
					if (forwardsConnectionPointsList[i].isFreeFloating == true){
						forwardsConnectionPointsList[i].isFreeFloating = false;
						return -1;
					}
					else{
						forwardsConnectionPointsList[i].isFreeFloating = true;
						return i;
					}
				}
				else{ //just observe
					return i;
				}
			}
		}
	}
	return -1;
}

//add a forwards connection at the specified position
int ConsumerNode::addForwardsConnection(int index){
	std::vector<ConnectionPoint>::iterator it = forwardsConnectionPointsList.begin();
	ConnectionPoint newConnectionPoint(index);
	forwardsConnectionPointsList.insert(it + index, newConnectionPoint); //add it!
	//and now update all the other connections!
	for (int i = index + 1; i < forwardsConnectionPointsList.size(); i++){ //iterate through all the other connection nodes after the updated one
		forwardsConnectionPointsList[i].index++; //increment the stored indices
		for (int j = 0; j < forwardsConnectionPointsList[i].connectionsList.size(); j++){
			std::array<int, 8> connectionData = forwardsConnectionPointsList[i].connectionsList[j];
			if (connectionData[2] == 1){ //if startpoint is RHS
				OutputDebugString("Updating with process node RHS as startpoint\n");
				connectionData[3]++; //increment the connection's index on the process node
				//Now update the nodes it is connected to!
				if (connectionData[4] == 2){ //Process node
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the process node list
					ProcessNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 3){ //Consumer node
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the consumer node list
					ConsumerNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 4){ //Storage node
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the storage node list
					StorageNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
			}
			else if (connectionData[6] == 1){ //if endpoint is RHS
				OutputDebugString("Updating process node with RHS as endpoint\n");
				connectionData[7]++; //increment the endpoint on the resource node!
				//Now update the node(s) it is connected to!
				if (connectionData[0] == 2){ //Process node.
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the process node list
					ProcessNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 3){ //Consumer node.
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the consumer node list
					ConsumerNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 4){ //Storage node.
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the consumer node list
					StorageNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
			}
			forwardsConnectionPointsList[i].connectionsList[j] = connectionData;
		}
	}
	return 0;
}

//add a backwards connection at the specified position
int ConsumerNode::addBackwardsConnection(int index){
	std::vector<ConnectionPoint>::iterator it = backwardsConnectionPointsList.begin();
	ConnectionPoint newConnectionPoint(index);
	backwardsConnectionPointsList.insert(it + index, newConnectionPoint); //add it!
	//and now update all the other connections! (the hard bit...)
	for (int i = index + 1; i < backwardsConnectionPointsList.size(); i++){ //iterate through all the other connection nodes after the updated one
		backwardsConnectionPointsList[i].index++; //increment the stored indices
		for (int j = 0; j < backwardsConnectionPointsList[i].connectionsList.size(); j++){
			std::array<int, 8> connectionData = backwardsConnectionPointsList[i].connectionsList[j];
			if (connectionData[2] == 0){ //if startpoint is LHS
				OutputDebugString("Updating extractor node LHS as startpoint\n");
				connectionData[3]++; //increment the connection's index on the resource node
				//Now update the node it is connected to!
				if (connectionData[4] == 1){ //Extractor node connection
					OutputDebugString("Extractor\n");
					std::vector<std::array<int, 8>> endPointData = ExtractorNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 2){ //Process node connection
					OutputDebugString("Process\n");
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the process node list
					ProcessNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 3){ //Consumer node connection
					OutputDebugString("Consumer\n");
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the consumer node list
					ConsumerNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 4){ //Storage node connection
					OutputDebugString("Storage\n");
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					StorageNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
			}
			else if (connectionData[6] == 0){ //if endpoint is LHS
				OutputDebugString("Updating extractor node LHS as endpoint\n");
				connectionData[7]++; //increment the endpoint on the resource node!
				//Now update the node(s) it is connected to!
				if (connectionData[0] == 1){//extractor node!
					OutputDebugString("Extractor\n");
					std::vector<std::array<int, 8>> endPointData = ExtractorNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 2){//process node!
					OutputDebugString("Process\n");
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the process node list
					ProcessNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 3){//consumer node!
					OutputDebugString("Consumer\n");
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the consumer node list
					ConsumerNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 4){//storage node!
					OutputDebugString("Storage\n");
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					StorageNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
			}
			backwardsConnectionPointsList[i].connectionsList[j] = connectionData; //make sure this node has updated itself also
		}
	}
	return 0;
}

int ConsumerNode::removeForwardsConnection(int index){ //remove a connection from the list
	return 0;
}

int ConsumerNode::removeBackwardsConnection(int index){ //remove a connection from the list
	return 0;
}

int ConsumerNode::resize(int mode, HWND hWnd) {
	SIZE textSize; //structure which we will store details about the string's physical dimensions
	PAINTSTRUCT ps; //create all the stuff we need to to simulate a drawing environment
	HDC thisHDC = BeginPaint(hWnd, &ps);
	HFONT hFont = CreateFont(int(15 * getZoomFactor()), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL); //duplicate the normal font
	SelectObject(thisHDC, hFont);
	GetTextExtentPoint32(thisHDC, name.c_str(), name.size(), &textSize);

	if (mode == 0) { //reset
		width = defaultWidth;
		name.erase(std::remove(name.begin(), name.end(), '\n'), name.end()); //remove all instances of newlines that might be present
		if (forwardsConnectionPointsList.size() > 0) {
			height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
		}
		else { //make sure it doesn't go all squishy
			height = defaultHeight;
		}
	}
	else if (mode == 1) { //reset to single Line
		name.erase(std::remove(name.begin(), name.end(), '\n'), name.end()); //remove all instances of newlines that might be present
		if (textSize.cx + 44 > defaultWidth / 2) { //check we really do want to resize this...
			width = textSize.cx + 44; //44. Give ourselves 4 pixels of leeway!
			if (forwardsConnectionPointsList.size() > 0) { //and now deal with the height!
				height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
			}
			else { //make sure it doesn't go all squishy
				height = defaultHeight;
			}
		}
	}
	else if (mode == 2) { //set to multi line
		if (textSize.cx + 30 > defaultWidth / 2) { //check we really do want to resize this...
			name = getResizeMultilineText(thisHDC, name, width, height, defaultHeight);
		}
	}
	DeleteObject(hFont);
	EndPaint(hWnd, &ps); //and remove this artificial environment!
	return 0;
}

/*************************************************************************
*
*	Storage Node Class:
*	Stores any and every extracted resource for future use. In theory,
*	a colony can be run purely from stored resources, but it will,
*	of course, be unsustainable in the long run!
*
**************************************************************************/

//Constructor
StorageNode::StorageNode(float xpos, float ypos, float Width, float Height, std::vector<ConnectionPoint> ForwardsConnections, std::vector<ConnectionPoint> BackwardsConnections){
	x = deCorrectX(xpos);
	y = deCorrectY(ypos);
	defaultWidth = Width;
	defaultHeight = Height;
	width = defaultWidth;
	height = defaultHeight;
	isPlaced = false; //default to free-floating
	showTitle = true; //default to displaying the title
	//add a default forwards and backwards node
	ConnectionPoint newConnectionPoint(0);
	forwardsConnectionPointsList = ForwardsConnections;
	backwardsConnectionPointsList = BackwardsConnections;

	//and now extract all the data!
	char data[32];
	GetWindowText(getNodeNameBox(), data, 32);
	name = data;
	SendMessage(getNodeDescBox(), WM_GETTEXT, sizeof(desc) / sizeof(desc[0]), reinterpret_cast<LPARAM>(desc));
}

StorageNode::StorageNode(){
}

//Destructor
StorageNode::~StorageNode(){
}

//Draw loop!
int StorageNode::draw(HDC hdc, HWND hWnd, int mouseX, int mouseY, bool highlight){
	HPEN hPen;
	HBRUSH hBrush;
	HFONT hFont;
	if (highlight){
		hPen = CreatePen(PS_SOLID, 2, RGB(255, 255, 255)); //draw a thin white outline
	}
	else{
		hPen = CreatePen(PS_NULL, 0, NULL); //don't color it!
	}
	SelectObject(hdc, hPen);
	//draw main rectangle
	if (isPlaced){
		hBrush = CreateSolidBrush(RGB(240, 220, 21)); //color it a darker yellow
		SetBkColor(hdc, RGB(240, 220, 21)); //color the text square dark yellow so it won't show
	}
	else{
		hBrush = CreateSolidBrush(RGB(255, 238, 5)); //color the unplaced rectangle a lighter yellow
		SetBkColor(hdc, RGB(255, 238, 5)); //color the text square yellow so it won't show
		//make the node follow the mouse around
		x = deCorrectX(mouseX);
		y = deCorrectY(mouseY);
	}
	SelectObject(hdc, hBrush); //select the brush and it's now-programmed colour
	if (forwardsConnectionPointsList.size() > backwardsConnectionPointsList.size() && forwardsConnectionPointsList.size() > 0 && height < (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size())) {
		height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
	}
	else if (backwardsConnectionPointsList.size() > 0 && height < (defaultHeight / 2)*(1 + backwardsConnectionPointsList.size())) {
		height = (defaultHeight / 2)*(1 + backwardsConnectionPointsList.size());
	}
	else if (height < defaultHeight) { //make sure it doesn't go all squishy
		height = defaultHeight;
	}
	if (width < defaultWidth / 2) {
		width = defaultWidth / 2;
	}
	RoundRect(hdc, correctX(x), correctY(y), correctX(x + width), correctY(y + height), defaultHeight*getZoomFactor(), defaultHeight*getZoomFactor()); //draw the surrounding rectangle, and scale it.
	DeleteObject(hBrush);

	//draw the forwards and backwards connection arrows
	isMouseOverArc = -1;
	for (int i = 0; i < forwardsConnectionPointsList.size(); i++) {
		int currentVal = isMouseOverArc;
		isMouseOverArc = forwardsConnectionPointsList[i].draw(hdc, hWnd, true, x, y, width, height, defaultHeight, i, forwardsConnectionPointsList.size()); //draw, and query if the mouse is over any connecting arcs
		if (currentVal != -1) {
			isMouseOverArc = currentVal; //make sure we get the arc the mouse is really over, not just the first arc!
		}
	}
	for (int i = 0; i < backwardsConnectionPointsList.size(); i++) {
		backwardsConnectionPointsList[i].draw(hdc, hWnd, false, x, y, width, height, defaultHeight, i, backwardsConnectionPointsList.size());
	}

	//draw text showing storage node name
	SetTextColor(hdc, RGB(0, 0, 0)); //set text black
	hFont = CreateFont(16 * getZoomFactor(), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
	SelectObject(hdc, hFont);
	RECT textRect{ correctX(x + 20), correctY(y + (height / 2) - (16 / 2)), correctX(x + width - 20), correctY(y + (height / 2) + (16 / 2)*int(height / defaultHeight)) };
	DrawText(hdc, name.c_str(), name.size(), &textRect, DT_CENTER | DT_WORD_ELLIPSIS);
	DeleteObject(hFont);

	//draw node type name above the node
	if (showTitle) { //user permitting!
		hFont = CreateFont(17 * getZoomFactor(), 0, 0, 0, FW_HEAVY, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		std::string nodeTitle = "Storage";
		RECT titleRect = { correctX(x), correctY(y) - 17 * getZoomFactor(), correctX(x + width), correctY(y) }; //define the rectangle to draw the text where we want it
		DrawText(hdc, nodeTitle.c_str(), nodeTitle.size(), &titleRect, DT_CENTER | DT_SINGLELINE | DT_NOCLIP); //Draw the text. We don't clip because it's faster & we don't need to!
		DeleteObject(hFont);
	}

	if (unlockSize) { //if the node's sizing has been unlocked, show the resize handles and resize!
		int largestList;
		if (forwardsConnectionPointsList.size() > backwardsConnectionPointsList.size()) {
			largestList = forwardsConnectionPointsList.size();
		}
		else {
			largestList = backwardsConnectionPointsList.size();
		}
		std::array <int, 4> resizedPos = resizeNode(hdc, x, y, defaultWidth, defaultHeight, width, height, largestList);
		x = resizedPos[0];
		y = resizedPos[1];
		width = resizedPos[2];
		height = resizedPos[3];
	}

	//and now for the description tooltip
	if (isMouseOverNode(getMouseX(), getMouseY())) {
		if (!tooltipActive) {
			tooltipActive = true;
			DescTooltip = createTooltip(hWnd, DescTooltip, desc); //create the tooltip
		}
	}
	else if (tooltipActive) { //if the mouse is no longer over the node
		DescTooltip = destroyTooltip(DescTooltip); //destroy the tooltip
		tooltipActive = false;
	}

	//Clear up memory
	DeleteObject(hPen);
	DeleteObject(hBrush);
	DeleteObject(hFont);
	return 0;
}

//place the node
bool StorageNode::place(int mouseX, int mouseY){
	x = deCorrectX(mouseX);
	y = deCorrectY(mouseY);
	isPlaced = true;
	return true;
}

bool StorageNode::isMouseOverNode(int mouseX, int mouseY){
	mouseX = deCorrectX(mouseX);
	mouseY = deCorrectY(mouseY);
	if ((!unlockSize && (mouseX) > x && (mouseX) < x + width) || (unlockSize && (mouseX) > x - 10 && (mouseX) < x + width + 10)) { //we are within x bounds
		if ((!unlockSize && (mouseY) > y && (mouseY) < y + height) || (unlockSize && (mouseY) > y - 10 && (mouseY) < y + height + 10)) { //we are within y bounds
			return true;
		}
	}
	return false;
}

//check to see if a connection node has been clicked. Called upon the mouse being released
int StorageNode::isBackwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify){ //modify has a default true value
	mouseX = deCorrectX(mouseX);
	mouseY = deCorrectY(mouseY);
	if (mouseX > x && mouseX < x + 13){//if the mouse is within the x bounds
		for (int i = 0; i < backwardsConnectionPointsList.size(); i++){
			if (mouseY > (y + (height / 2) + (defaultHeight / 2)*(i - float(backwardsConnectionPointsList.size() - 1) / 2) - 6) && mouseY < (y + (height / 2) + (defaultHeight / 2)*(i - float(backwardsConnectionPointsList.size() - 1) / 2) + 6)) { //if the mouse is within the y bounds
				if (modify){ //change, and observe!
					if (backwardsConnectionPointsList[i].isFreeFloating == true){
						backwardsConnectionPointsList[i].isFreeFloating = false;
						return -1;
					}
					else{
						backwardsConnectionPointsList[i].isFreeFloating = true;
						return i;
					}
				}
				else{ //just observe
					return i;
				}
			}
		}
	}
	return -1;
}

//check to see if a connection node has been clicked. Called upon the mouse being released
int StorageNode::isForwardsConnectionNodeClicked(int mouseX, int mouseY, bool modify){ //modify has a default true value
	mouseX = deCorrectX(mouseX);
	mouseY = deCorrectY(mouseY);
	if (mouseX > x + width - 13 && mouseX < x + width){//if the mouse is within the x bounds
		for (int i = 0; i < forwardsConnectionPointsList.size(); i++){
			if (mouseY >(y + (height / 2) + (defaultHeight / 2)*(i - float(forwardsConnectionPointsList.size() - 1) / 2) - 6) && mouseY < (y + (height / 2) + (defaultHeight / 2)*(i - float(forwardsConnectionPointsList.size() - 1) / 2) + 6)) { //if the mouse is within the y bounds
				if (modify){ //change, and observe!
					if (forwardsConnectionPointsList[i].isFreeFloating == true){
						forwardsConnectionPointsList[i].isFreeFloating = false;
						return -1;
					}
					else{
						forwardsConnectionPointsList[i].isFreeFloating = true;
						return i;
					}
				}
				else{ //just observe
					return i;
				}
			}
		}
	}
	return -1;
}

//add a forwards connection at the specified position
int StorageNode::addForwardsConnection(int index){
	std::vector<ConnectionPoint>::iterator it = forwardsConnectionPointsList.begin();
	ConnectionPoint newConnectionPoint(index);
	forwardsConnectionPointsList.insert(it + index, newConnectionPoint); //add it!
	//and now update all the other connections!
	for (int i = index + 1; i < forwardsConnectionPointsList.size(); i++){ //iterate through all the other connection nodes after the updated one
		forwardsConnectionPointsList[i].index++; //increment the stored indices
		for (int j = 0; j < forwardsConnectionPointsList[i].connectionsList.size(); j++){
			std::array<int, 8> connectionData = forwardsConnectionPointsList[i].connectionsList[j];
			if (connectionData[2] == 1){ //if startpoint is RHS
				OutputDebugString("Updating with storage node RHS as startpoint\n");
				connectionData[3]++; //increment the connection's index on the process node
				//Now update the nodes it is connected to!
				if (connectionData[4] == 2){ //Process node
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the process node list
					ProcessNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 3){ //Consumer node
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the consumer node list
					ConsumerNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 4){ //Storge node
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the storage node list
					StorageNodeList[connectionData[5]].backwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
			}
			else if (connectionData[6] == 1){ //if endpoint is RHS
				OutputDebugString("Updating process node with RHS as endpoint\n");
				connectionData[7]++; //increment the endpoint on the resource node!
				//Now update the node(s) it is connected to!
				if (connectionData[0] == 2){ //Process node.
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the process node list
					ProcessNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 3){ //Consumer node.
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the consumer node list
					ConsumerNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 4){ //Storage node.
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the consumer node list
					StorageNodeList[connectionData[1]].backwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
			}
			forwardsConnectionPointsList[i].connectionsList[j] = connectionData;
		}
	}
	return 0;
}

//add a backwards connection at the specified position
int StorageNode::addBackwardsConnection(int index){
	std::vector<ConnectionPoint>::iterator it = backwardsConnectionPointsList.begin();
	ConnectionPoint newConnectionPoint(index);
	backwardsConnectionPointsList.insert(it + index, newConnectionPoint); //add it!
	//and now update all the other connections! (the hard bit...)
	for (int i = index + 1; i < backwardsConnectionPointsList.size(); i++){ //iterate through all the other connection nodes after the updated one
		backwardsConnectionPointsList[i].index++; //increment the stored indices
		for (int j = 0; j < backwardsConnectionPointsList[i].connectionsList.size(); j++){
			std::array<int, 8> connectionData = backwardsConnectionPointsList[i].connectionsList[j];
			if (connectionData[2] == 0){ //if startpoint is LHS
				OutputDebugString("Updating extractor node LHS as startpoint\n");
				connectionData[3]++; //increment the connection's index on the resource node
				//Now update the node it is connected to!
				if (connectionData[4] == 1){ //Extractor node connection
					OutputDebugString("Extractor\n");
					std::vector<std::array<int, 8>> endPointData = ExtractorNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 2){ //Process node connection
					OutputDebugString("Process\n");
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the process node list
					ProcessNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 3){ //Consumer node connection
					OutputDebugString("Consumer\n");
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the consumer node list
					ConsumerNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
				else if (connectionData[4] == 4){ //Storage node connection
					OutputDebugString("Storage\n");
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][3]++; //and increment!
					}
					//now update the consumer node list
					StorageNodeList[connectionData[5]].forwardsConnectionPointsList[connectionData[7]].connectionsList = endPointData;
				}
			}
			else if (connectionData[6] == 0){ //if endpoint is LHS
				OutputDebugString("Updating storage node LHS as endpoint\n");
				connectionData[7]++; //increment the endpoint on the resource node!
				//Now update the node(s) it is connected to!
				if (connectionData[0] == 1){//extractor node!
					OutputDebugString("Extractor\n");
					std::vector<std::array<int, 8>> endPointData = ExtractorNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					ExtractorNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 2){//process node!
					OutputDebugString("Process\n");
					std::vector<std::array<int, 8>> endPointData = ProcessNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the process node list
					ProcessNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 3){//consumer node!
					OutputDebugString("Consumer\n");
					std::vector<std::array<int, 8>> endPointData = ConsumerNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the consumer node list
					ConsumerNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
				else if (connectionData[0] == 4){//storage node!
					OutputDebugString("Storage\n");
					std::vector<std::array<int, 8>> endPointData = StorageNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList;
					for (int k = 0; k < endPointData.size(); k++){ //iterate through the list of endpoints!
						endPointData[k][7]++; //and increment!
					}
					//now update the extractor node list
					StorageNodeList[connectionData[1]].forwardsConnectionPointsList[connectionData[3]].connectionsList = endPointData;
				}
			}
			backwardsConnectionPointsList[i].connectionsList[j] = connectionData; //make sure this node has updated itself also
		}
	}
	return 0;
}

int StorageNode::removeForwardsConnection(int index){ //remove a connection from the list
	return 0;
}

int StorageNode::removeBackwardsConnection(int index){ //remove a connection from the list
	return 0;
}

int StorageNode::resize(int mode, HWND hWnd) {
	SIZE textSize; //structure which we will store details about the string's physical dimensions
	PAINTSTRUCT ps; //create all the stuff we need to to simulate a drawing environment
	HDC thisHDC = BeginPaint(hWnd, &ps);
	HFONT hFont = CreateFont(15 * getZoomFactor(), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL); //duplicate the normal font
	SelectObject(thisHDC, hFont);
	GetTextExtentPoint32(thisHDC, name.c_str(), name.size(), &textSize);

	if (mode == 0) { //reset
		width = defaultWidth;
		name.erase(std::remove(name.begin(), name.end(), '\n'), name.end()); //remove all instances of newlines that might be present
		if (forwardsConnectionPointsList.size() > 0) {
			height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
		}
		else { //make sure it doesn't go all squishy
			height = defaultHeight;
		}
	}
	else if (mode == 1) { //reset to single Line
		name.erase(std::remove(name.begin(), name.end(), '\n'), name.end()); //remove all instances of newlines that might be present
		if (textSize.cx + 44 > defaultWidth / 2) { //check we really do want to resize this...
			width = textSize.cx + 44; //44. Give ourselves 4 pixels of leeway!
			if (forwardsConnectionPointsList.size() > 0) { //and now deal with the height!
				height = (defaultHeight / 2)*(1 + forwardsConnectionPointsList.size());
			}
			else { //make sure it doesn't go all squishy
				height = defaultHeight;
			}
		}
	}
	else if (mode == 2) { //set to multi line
		if (textSize.cx + 30 > defaultWidth / 2) { //check we really do want to resize this...
			name = getResizeMultilineText(thisHDC, name, width, height, defaultHeight);
		}
	}
	DeleteObject(hFont);
	EndPaint(hWnd, &ps); //and remove this artificial environment!
	return 0;
}


/******************************************************************************************************************************************************************************/


//Returns the xpos, ypos, width and height of the resized node. Also modifies the mouse pointer. Final element is the number of connections present on the largest side
std::array<int, 4> resizeNode(HDC hdc, int x, int y, int defaultWidth, int defaultHeight, int width, int height, int largestConnectionNum) {
	//show adjust handles if the node is in resize mode
	HCURSOR hCursor = LoadCursor(NULL, IDC_ARROW); //set a default
	HPEN hPen = CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
	HBRUSH hBrush = CreateSolidBrush(RGB(255, 255, 255));
	SelectObject(hdc, hPen);
	SelectObject(hdc, hBrush);
	Rectangle(hdc, int(correctX(x) - 5), correctY(y) - 5, correctX(x) + 5, correctY(y) + 5); //Top left
	Rectangle(hdc, int(correctX(x + width) - 5), correctY(y) - 5, correctX(x + width) + 5, correctY(y) + 5); //Top right
	Rectangle(hdc, int(correctX(x) - 5), correctY(y + height) - 5, correctX(x) + 5, correctY(y + height) + 5); //Bottom left
	Rectangle(hdc, int(correctX(x + width) - 5), correctY(y + height) - 5, correctX(x + width) + 5, correctY(y + height) + 5); //Bottom right
	Rectangle(hdc, int(correctX(x) - 5), correctY(y + height / 2) - 5, correctX(x) + 5, correctY(y + height / 2) + 5); //middle left
	Rectangle(hdc, int(correctX(x + width) - 5), correctY(y + height / 2) - 5, correctX(x + width) + 5, correctY(y + height / 2) + 5); //middle right
	Rectangle(hdc, int(correctX(x + width / 2) - 5), correctY(y + height) - 5, correctX(x + width / 2) + 5, correctY(y + height) + 5); //middle bottom
	Rectangle(hdc, int(correctX(x + width / 2) - 5), correctY(y) - 5, correctX(x + width / 2) + 5, correctY(y) + 5); //middle top
	if (getMouseX() > correctX(x) - (10 + abs(getMouseX() - getLastMouseX())) / getZoomFactor() && getMouseX() < correctX(x) + (10 + abs(getMouseX() - getLastMouseX())) / getZoomFactor()) {
		if (getMouseY() > correctY(y) - (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor() && getMouseY() < correctY(y) + (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor()) { //top left. We do chenanigans with abs(mouseX - getLastmouseX()) to expand the collisions area to compensate for mouse movement.
			hCursor = LoadCursor(NULL, IDC_SIZENWSE);
			if (isMousePressedL()) {
				width -= int((getMouseX() - getLastMouseX())*getZoomFactor());
				height -= int((getMouseY() - getLastMouseY())*getZoomFactor());
				if (width > (defaultWidth / 2) - 1) {
					x += int((getMouseX() - getLastMouseX())*getZoomFactor());
				}
				if (height > defaultHeight - 1 && largestConnectionNum > 0 && height + 1 > (defaultHeight / 2)*(1 + largestConnectionNum)) {
					y += int((getMouseY() - getLastMouseY())*getZoomFactor());
				}
			}
		}
		if (getMouseY() > correctY(y + height / 2) - (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor() && getMouseY() < correctY(y + height / 2) + (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor()) { //middle left
			hCursor = LoadCursor(NULL, IDC_SIZEWE);
			if (isMousePressedL()) {
				width -= int((getMouseX() - getLastMouseX())*getZoomFactor());
				if (width > (defaultWidth / 2) - 1) {
					x += int((getMouseX() - getLastMouseX())*getZoomFactor());
				}
			}
		}
		if (getMouseY() > correctY(y + height) - (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor() && getMouseY() < correctY(y + height) + (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor()) { //bottom left
			hCursor = LoadCursor(NULL, IDC_SIZENESW);
			if (isMousePressedL()) {
				width -= int((getMouseX() - getLastMouseX())*getZoomFactor());
				height += int((getMouseY() - getLastMouseY())*getZoomFactor());
				if (width > (defaultWidth / 2) - 1) {
					x += int((getMouseX() - getLastMouseX())*getZoomFactor());
				}
			}
		}
	}
	if (getMouseX() > correctX(width / 2 + x) - (10 + abs(getMouseX() - getLastMouseX())) / getZoomFactor() && getMouseX() < correctX(x + width / 2) + (10 + abs(getMouseX() - getLastMouseX())) / getZoomFactor()) {
		if (getMouseY() > correctY(y) - (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor() && getMouseY() < correctY(y) + (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor()) { //top middle
			hCursor = LoadCursor(NULL, IDC_SIZENS);
			if (isMousePressedL()) {
				height -= int((getMouseY() - getLastMouseY())*getZoomFactor());
				if (height > defaultHeight - 1 && largestConnectionNum > 0 && height + 1 > (defaultHeight / 2)*(1 + largestConnectionNum)) {
					y += int((getMouseY() - getLastMouseY())*getZoomFactor());
				}
			}
		}
		if (getMouseY() > correctY(y + height) - (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor() && getMouseY() < correctY(y + height) + (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor()) { //bottom middle
			hCursor = LoadCursor(NULL, IDC_SIZENS);
			if (isMousePressedL()) {
				height += int((getMouseY() - getLastMouseY())*getZoomFactor());
			}
		}
	}
	if (getMouseX() > correctX(x + width) - (10 + abs(getMouseX() - getLastMouseX())) / getZoomFactor() && getMouseX() < correctX(x + width) + (10 + abs(getMouseX() - getLastMouseX())) / getZoomFactor()) {
		if (getMouseY() > correctY(y) - (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor() && getMouseY() < correctY(y) + (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor()) { //top right
			hCursor = LoadCursor(NULL, IDC_SIZENESW);
			if (isMousePressedL()) {
				width += int((getMouseX() - getLastMouseX())*getZoomFactor());
				height -= int((getMouseY() - getLastMouseY()));
				if (height > defaultHeight - 1 && largestConnectionNum > 0 && height + 1 > (defaultHeight / 2)*(1 + largestConnectionNum)) {
					y += int((getMouseY() - getLastMouseY())*getZoomFactor());
				}
			}
		}
		if (getMouseY() > correctY(y + height / 2) - (10 + abs(getMouseY() - getLastMouseY()) / getZoomFactor()) && getMouseY() < correctY(y + height / 2) + (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor()) { //middle right
			hCursor = LoadCursor(NULL, IDC_SIZEWE);
			if (isMousePressedL()) {
				width += int((getMouseX() - getLastMouseX())*getZoomFactor());
			}
		}
		if (getMouseY() > correctY(y + height) - (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor() && getMouseY() < correctY(y + height) + (10 + abs(getMouseY() - getLastMouseY())) / getZoomFactor()) { //bottom right
			hCursor = LoadCursor(NULL, IDC_SIZENWSE);
			if (isMousePressedL()) {
				width += int((getMouseX() - getLastMouseX())*getZoomFactor());
				height += int((getMouseY() - getLastMouseY())*getZoomFactor());
			}
		}
	}
	SetCursor(hCursor);
	DeleteObject(hCursor);
	DeleteObject(hPen);
	DeleteObject(hBrush);
	return{ x, y, width, height };
}

std::string getResizeMultilineText(HDC thisHDC, std::string name, float &width, float &height, int defaultHeight) { //Algorithm that tries to fit the nodes text within the smallest possible perimeter.
	//first, we want to split the string up at it's spaces...
	std::stringstream ss;
	ss.str(name);
	std::string item;
	std::vector<std::string> words;
	while (std::getline(ss, item, ' ')) {
		words.push_back(item);
	}
	//Now get our mitts on the largest word stored.
	int largestElementIndex = 0;
	int largestElementSize = 0;
	for (int i = 0; i < words.size(); i++) {
		if (words[i].size() > largestElementSize) { //if we have found an even more bigly word...
			largestElementIndex = i; //Note where we found it
			largestElementSize = words[i].size(); //and how big it is
		}
	}
	//and now we reconstruct the string!
	std::string newName = "";
	for (int i = 0; i < words.size(); i++) {
		if (i != 0 && i == largestElementIndex) {
			newName += '\n';
		}
		newName += words[i];
		if (i == largestElementIndex && i < words.size() - 1) {
			newName += '\n';
		}
		else {
			newName += ' ';
		}
	}
	SIZE textSize;
	height = (float)defaultHeight * 2; //work out the minimum height. This will be resized in draw if it's too small...
	GetTextExtentPoint32(thisHDC, words[largestElementIndex].c_str(), words[largestElementIndex].size(), &textSize);
	width = (float)textSize.cx + 50;

	return newName;
}