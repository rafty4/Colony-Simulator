#pragma once

void draw(PAINTSTRUCT ps, HDC hdc, HWND hWnd); //prototype function for drawing stuff in
std::string GetMetricFromCSRCfile(std::vector<std::string> file, std::string metric);