#pragma once

/****************************************************************************************************
*
*	Atom class:
*	Stores all the data about a particular atom. Will be grabbed at the beginning off a stored
*	periodic table, but in the name of making this application ultra-flexible, users can add their
*	own if they so wish... *ahem* unobtanium! *ahem*
*
****************************************************************************************************/

class Atom{
private:
public:
	std::string name;
	std::string symbol;
	std::array<int, 2> periodicTablePos; //x, followed by y pos on the periodic table
	int protonNumber;
	float neutronNumber; //average number fo neutrons in the element in question
	int electronNumber; //should equal proton number, but in the name of flexibility...
	int atomicMass; //integer since different isotopes will be stored separately.
	bool isUnstable; //may determine this from an X-Z plot one day
	double probableDecayMode[4]; //list of probabilities of decaying by alpha emission, beta emission, gamma ray emission, or electron capture respectively. 0 for all if stable. From X-Z plot, one day perhaps?
	float halfLife; //time it will take for half the atom to decay.
	//GUI drawing data. It had to be associated somehow!
	int number; //number of atoms
	RECT BoundingRect;
	Atom();
	~Atom();
	Atom(std::string Name, std::string Symbol, int ProtonNumber, float NeutronNumber, int ElectronNumber, int AtomicMass, std::array<int, 2> TablePosition);
};

/***************************************************************************************************
*
*	Bond class:
*	Class for storing data about chemical bonds. The common ones will be loaded directly off a .txt
*	file
*
****************************************************************************************************/

class Bond{
private:
	std::string name; //name of the bond in question
	std::string desciption; //a technical (or otherwise) desciption of the bond
	int number; //single, double, triple, quadruple (?!), whatever
	float bondEnthalpy; //the energy stored in the bond. In J/mol. NOT NOT NOT kJ/mol!!!
	Atom atom1; //the first atom the bond is connecting
	Atom atom2; //the other bond it is connecting to. Even I know a bond can only connect 2 atoms!
public:
	Bond();
	~Bond();
};

/****************************************************************************************************
*
*	Molecular Component class:
*	Stores all the data about a chemical component, as part of the molecule shown in the chemistry
*	window. Also stores information about physical position etc. MOre of a GUI data class than a
*	chemistry data class.
*
*****************************************************************************************************/

class MolecularComponent {
private:
	RECT boundingRect;
public:
	std::string textFormula;
	std::vector<Atom> atomList;
	int xpos;
	int ypos;
	int netCharge;
	int atomicMass;
	bool isMovable;
	bool drawBoundingRect; //controls whether the formula is boxed in. Default true.

	MolecularComponent();
	~MolecularComponent();
	MolecularComponent(std::string TextFormula, std::vector<Atom>AtomList, int NetCharge);
	int draw(HDC hdc);
	bool isMouseOverComponent(int mouseX, int mouseY);
};


/****************************************************************************************************
*
*	Chemical Components class:
*	My chance to get revenge on chemistry by simplifying it horrifically! Yay! >:)
*	It is through this class that all chemical reactions take place
*	Stores all the meta about a chemical, with lists of all the chemical bonds and atoms etc.
*	Most common ones are stored in a .txt file, and will be added to over time!
*
*****************************************************************************************************/

class ChemicalComponent{
private:
public:
	std::string chemicalName; //Call it whatever you like. It'll make precious little difference!
	std::string IUPACname; //makes the chemists among us happy. Also allows them to feel better about extracting unobtanium.
	std::vector <Atom> atomicComponents; //note that if this is CO2, it will this list will consist of 2x Carbon and an oxygen, not just O2 and Carbon.
	float atomicMass; //the total atomic mass of the molecule
	std::vector <Bond> bondsList; //list of all the chemical bonds, and the energy required to extract them
	double numberOfMolecules; //the number of this type of molecule present. Normally unlikely to be below 10^22
	float numberOfMoles; //a much more sensible way of defining the number!
	bool isRadioactive; //if any form of nucleic nonsense will occur.
	float halfLife; //the time it would take for half the substance to decay. Infinate if !isRadioactive.
	std::string isomerID; //Unique ID for the isomer in question. User can set this, as can application. Needed as some isomers are useless.
	ChemicalComponent();
	~ChemicalComponent();
};



/****************************************************************************************************
*
*	Resource Component class:
*	Stores all the data about a component of a resource, since all resources are mixtures.
*
*****************************************************************************************************/


class ResourceComponent{
private:
public:
	std::string componentName;
	std::string componentDesc;
	std::vector<ChemicalComponent> ComponentMolecules; //Each chemical component is a constituent molecule of this resource component!
	__int64 uniqueID; //This identifies the component uniquely, using the exact millisecond of creation (losing the first couple of sigfigs), plus a random 3-digit suffix.
	float solidDensity; //Solid density of the component
	std::string solidDensityUnits; //units defined for the solid density measure
	float liquidDensity; //Liquid density of the component
	std::string liquidDensityUnits;
	float meltingPoint; //Melting point of the component
	std::string meltingPointUnits;
	float boilingPoint; //Boiling point of the component
	std::string boilingPointUnits;
	float percentAbundance; //percentage of abundance within it's parent StoredResource
	std::string percentAbundanceUnits;
	float massStored; //mass stored
	std::string massStoredUnits;
	float volumeStored; //volume stored
	std::string volumeStoredUnits;
	float temperature; //temperature of stored component. Obviously this will eventually be the same as it's parent, but this could take a while!
	std::string temperatureUnits;
	float heatCapacity; //heat capacity of the component
	std::string heatCapacityUnits;
	int state; //it's current state, since stored "mixtures" could consist of multiple states
	bool isDissolved; //whether the resource is dissolved in it's parent
	bool isMixable; //whether or not the component can happily mix with it's parent, or if they insist on separating
	bool isRadioactive; //will it decay?

	ResourceComponent();
	~ResourceComponent();
	__int64 createUniqueID();
};

/*****************************************************************************************************
*
*	Stored Resource class:
*	Basic class that stores data about a particular resource when stored, attempting to be as flexible as possible
*
******************************************************************************************************/

class StoredResource{
private:
	std::string resourceName; //name of the resource in question
	float density; //it's density
	float volumeAvailable; //it's volume
	float massAvailable; //it's mass
	int state; //it's current state: liquid, solid, gas as 0-2 inclusive
	float heatCapacity; //the heat capacity of the material
	float coefficientOfExpansion; //the amount the resource will expand with temperature
	float temperature; //it's current temperature
	float viscosity; //it's viscocity. Close to infinate for a solid, and more reasonable (and meaningful!) for liquids and gases.
	std::vector <ResourceComponent> components;
	bool isRadioactive; //will it decay?

public:
	StoredResource();
	~StoredResource();
};

/**************************************************************************************************
*
*	Extractable Resource class:
*	Stores data about an unmined resource, existing on or within Mars itself.
*	Often contains multiple components
*
**************************************************************************************************/

class ExtractableResource{
	std::string name;
	float abundanceByMass;
	float abundanceByVolume;
	int state; //solid, liquid, or gaseous. 0-2 inclusive, respectively. The state which it exists in the ground/air/whatever.
	std::vector <ResourceComponent> components; //a list containing all the components of this resource.
	bool isRadioactive; //leave outside the hab if true... or warm your bathwater!
public:
	ExtractableResource();
	~ExtractableResource();
};

/*************************************************************************************************
*	UpdateGlobalResourceComponentList()
*	Adds a new resource component to the global list. Also updates the GUI comboboxes etc etc
**************************************************************************************************/
int UpdateGlobalResourceComponentList(ResourceComponent NewComponent);