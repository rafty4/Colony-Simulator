#pragma once


/*****************************************************************************
*
*	Extraction Process class:
*	This class stores all the data about an extraction process. An
*	extraction process takes raw materials from the environment
*	(ExtractableResource), and turns them into StoredResources, potentially
*	consuming other StoredResources in the process.
*
******************************************************************************/

class ExtractionProcess{
private:
public:
	ExtractionProcess();
	~ExtractionProcess();
};

/******************************************************************************
*
*	Separation Process class:
*	Used to store data about a process that takes in a StoredResource, and
*	mechanically (this is a chemistry free zone!) separates them into two or
*	more different storedResources, that were origionally contained within.
*
*******************************************************************************/

class SeparationProcess{
private:
public:
	SeparationProcess();
	~SeparationProcess();
};

/******************************************************************************
*
*	Chemical Reaction Process class:
*	Used to store data about a chemical reaction. This process takes in a
*	StoredResource, and then applies the specified reaction to it, normally
*	via the other chemistry-orientated classes (although in the name of
*	flexibility, the user can choose to flout all sorts of fundamental
*	physics!), to produce a different StoredResource.
*
******************************************************************************/

class ChemicalProcess{
private:
	float efficiency; //a fudge factor applied by the user that bleeds resources into a black hole. 0 <= e <= 1.
public:
	ChemicalProcess();
	~ChemicalProcess();
};

/*****************************************************************************
*
*	Removal Process class:
*	A specialised version of the consumption class that casts StoredResources
*	into digital oblivion, potentially consuming other StoredResources in the
*	process, and producing biproducts.
*
******************************************************************************/

class RemovalProcess{
private:
public:
	RemovalProcess();
	~RemovalProcess();
};