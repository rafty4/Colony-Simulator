/*********************************************************************
*
*	Draw function!
*
**********************************************************************/
#include "stdafx.h"

void draw(PAINTSTRUCT ps, HDC hdc, HWND hWnd) {
	RECT clientRect;
	SelectObject(hdc, NULL); //reset it
	SetBkMode(hdc, TRANSPARENT); //make sure text doesn't create squares behind it
	//deal with mouseX and mouseY
	GetCursorPos(&cursorPos);
	ScreenToClient(FlowchartWindowHandle, &cursorPos);
	lastMouseX = (int)mouseX;
	lastMouseY = (int)mouseY;
	mouseX = (int)cursorPos.x;
	mouseY = (int)cursorPos.y;

	// Fill the client area with a brush
	HRGN bgRgn;
	HBRUSH hBrush;
	HFONT hFont;
	GetClientRect(hWnd, &clientRect);
	win_width = clientRect.right - clientRect.left;
	win_height = clientRect.bottom - clientRect.top;
	bgRgn = CreateRectRgnIndirect(&clientRect);
	if (backgroundMode == 0) {
		hBrush = CreateSolidBrush(RGB(255, 255, 255)); //colour it plain white
	}
	else {
		hBrush = CreateSolidBrush(RGB(70, 130, 170)); //colour it a nice blue
	}
	FillRgn(hdc, bgRgn, hBrush);
	//clean up memory
	DeleteObject(hBrush);
	DeleteObject(bgRgn);

	//now draw vertical gridlines with 10 pixel spacing
	HPEN thisPen = NULL;
	thisPen = CreatePen(PS_SOLID, 1, RGB(90, 140, 180)); //draw them a darker blue
	SelectObject(hdc, thisPen);
	if (backgroundMode == 1) {
		for (int i = 0; i < win_width; i += 10) {
			MoveToEx(hdc, i, 0, NULL);
			LineTo(hdc, i, win_height);
		}
		//and the horizontal ones!
		for (int i = 0; i < win_height; i += 10) {
			MoveToEx(hdc, 0, i, NULL);
			LineTo(hdc, win_width, i);
		}
	}
	else if (backgroundMode == 2) {
		for (float i = float(int(viewX / 10)*10.0); i < viewX + (win_width / zoomFactor); i += 10) { //we round i to the nearest 50 so the grid will appear to scroll, while still not drawing very far outside the window
			MoveToEx(hdc, int((i - viewX)*zoomFactor), 0, NULL);
			LineTo(hdc, int((i - viewX)*zoomFactor), win_height);
		}
		//and the horizontal ones!
		for (float i = float(int(viewY / 10)*10.0); i < viewY + (win_height / zoomFactor); i += 10) {
			MoveToEx(hdc, 0, int((i - viewY)*zoomFactor), NULL);
			LineTo(hdc, win_width, int((i - viewY)*zoomFactor));
		}
	}
	DeleteObject(thisPen);

	//now draw vertical gridlines with 50 pixel spacing
	thisPen = CreatePen(PS_SOLID, 1, RGB(100, 150, 200)); //draw them a slightly lighter blue
	SelectObject(hdc, thisPen);
	if (backgroundMode == 1) {
		for (int i = 0; i < viewX + win_width; i += 50) {
			MoveToEx(hdc, i, 0, NULL);
			LineTo(hdc, i, win_height);
		}
		//and the horizontal ones!
		for (int i = 0; i < viewY + win_height; i += 50) {
			MoveToEx(hdc, 0, i, NULL);
			LineTo(hdc, win_width, i);
		}
	}
	else if (backgroundMode == 2) {
		for (float i = float(int(viewX / 50)*50.0); i < viewX + (win_width / zoomFactor); i += 50) {
			MoveToEx(hdc, int((i - viewX)*zoomFactor), 0, NULL);
			LineTo(hdc, int((i - viewX)*zoomFactor), win_height);
		}
		//and the horizontal ones!
		for (float i = float(int(viewY / 50)*50.0); i < viewY + (win_height / zoomFactor); i += 50) {
			MoveToEx(hdc, 0, int((i - viewY)*zoomFactor), NULL);
			LineTo(hdc, win_width, int((i - viewY)*zoomFactor));
		}
	}
	DeleteObject(thisPen); //clean up after ourselves!
	SelectObject(hdc, NULL); //reset it

	/***********************************************************************************
	*	Draw nodes!
	************************************************************************************/

	// draw resource nodes
	for (int i = 0; i < ResourceNodeList.size(); i++) {
		ResourceNodeList[i].draw(hdc, hWnd, mouseX, mouseY, (i == resourceNodeSelected));
	}
	// draw extractor nodes
	for (int i = 0; i < ExtractorNodeList.size(); i++) {
		ExtractorNodeList[i].draw(hdc, hWnd, mouseX, mouseY, (i == extractorNodeSelected));
	}
	// draw industrial process nodes
	for (int i = 0; i < ProcessNodeList.size(); i++) {
		ProcessNodeList[i].draw(hdc, hWnd, mouseX, mouseY, (i == processNodeSelected));
	}
	// draw consumer nodes
	for (int i = 0; i < ConsumerNodeList.size(); i++) {
		ConsumerNodeList[i].draw(hdc, hWnd, mouseX, mouseY, (i == consumerNodeSelected));
	}
	// draw storage nodes
	for (int i = 0; i < StorageNodeList.size(); i++) {
		StorageNodeList[i].draw(hdc, hWnd, mouseX, mouseY, (i == storageNodeSelected));
	}
	//draw comments
	for (int i = 0; i < CommentsList.size(); i++) {
		CommentsList[i].draw(hdc);
	}

	/***********************************************************************************/

	//draw mouseX/mouseY to the bottom corner of the display
	SetBkMode(hdc, TRANSPARENT);
	SetTextColor(hdc, RGB(0, 255, 255)); //set it to turquoise
	std::string zoomString = std::to_string(zoomFactor);
	zoomString = zoomString.erase(zoomString.find('.') + 3, zoomString.size()); //only go up to the second d.p.
	std::string mousePos = "x:" + std::to_string(int(deCorrectX(float(mouseX)))) + ", y:" + std::to_string(int(deCorrectY(float(mouseY)))) + ", z: x" + zoomString;
	hFont = CreateFont(16, 0, 0, 0, FW_LIGHT, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
	SelectObject(hdc, hFont);
	SIZE textSize; //structure which we will store details about the string's physical dimensions
	GetTextExtentPoint32(hdc, mousePos.c_str(), mousePos.size(), &textSize);
	TextOut(hdc, win_width - textSize.cx - 10, win_height - 20, mousePos.c_str(), mousePos.size());
	DeleteObject(hFont);

	//title the flowchart window
	SetTextColor(hdc, RGB(0, 0, 0));
	hFont = CreateFont(16, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
	SelectObject(hdc, hFont);
	TCHAR flowchartTitle[] = _T("Resource Consumption Flowchart:");
	TextOut(hdc, 10, 5, flowchartTitle, _tcslen(flowchartTitle));
	DeleteObject(hFont);

	//keep flowchart window the correct size
	GetClientRect(mainWindowHWND, &clientRect);
	if (clientRect.right - clientRect.left != win_width + 29 || clientRect.bottom - clientRect.top != win_height + 79) {
		SetWindowPos(hWnd, HWND_TOP, 10, 60, (clientRect.right - clientRect.left) - 10, (clientRect.bottom - clientRect.top) - 60, SWP_NOMOVE);
	}
	//Keep the zoom buttons in the right place
	RECT zoomInButtonRect;
	RECT zoomOutButtonRect;
	GetWindowRect(FlowchartZoomInButton, &zoomInButtonRect);
	GetWindowRect(FlowchartZoomOutButton, &zoomOutButtonRect);
	ScreenToClient(hWnd, reinterpret_cast<POINT*>(&zoomInButtonRect.left));
	ScreenToClient(hWnd, reinterpret_cast<POINT*>(&zoomOutButtonRect.left));
	if (zoomInButtonRect.left != win_width - 30 || zoomOutButtonRect.left != win_width - 30) {
		SetWindowPos(FlowchartZoomInButton, NULL, win_width - 30, 10, 20, 20, NULL);
		SetWindowPos(FlowchartZoomOutButton, NULL, win_width - 30, 32, 20, 20, NULL);
		SendMessage(FlowchartZoomInButton, WM_PAINT, 0, 0);
		SendMessage(FlowchartZoomOutButton, WM_PAINT, 0, 0);
	}
	//Housekeeping
	frameCount++;
	mouseLDblClk = false;
}

