#include "stdafx.h"

/****************************************************************************************************
*
*	Atom class:
*	Stores all the data about a particular atom. Will be grabbed at the beginning off a stored
*	periodic table, but in the name of making this application ultra-flexible, users can add their
*	own if they so wish... *ahem* unobtanium! *ahem*
*
****************************************************************************************************/

//standard constructor
Atom::Atom() {
}
//standard destructor
Atom::~Atom() {
}

Atom::Atom(std::string Name, std::string Symbol, int ProtonNumber, float NeutronNumber, int ElectronNumber, int AtomicMass, std::array<int, 2> TablePosition) {
	name = Name;
	symbol = Symbol;
	protonNumber = ProtonNumber;
	neutronNumber = NeutronNumber;
	electronNumber = ElectronNumber;
	atomicMass = AtomicMass;
	periodicTablePos = TablePosition;
}


/***************************************************************************************************
*
*	Bond class:
*	Class for storing data about chemical bonds. The common ones will be loaded directly off a .txt
*	file
*
****************************************************************************************************/

Bond::Bond() {

}

Bond::~Bond() {

}

/****************************************************************************************************
*
*	Molecular Component class:
*	Stores all the data about a chemical component, as part of the molecule shown in the chemistry
*	window. Also stores information about physical position etc. MOre of a GUI data class than a
*	chemistry data class.
*
*****************************************************************************************************/

MolecularComponent::MolecularComponent() {

}
MolecularComponent::~MolecularComponent() {

}
MolecularComponent::MolecularComponent(std::string TextFormula, std::vector<Atom>AtomList, int NetCharge) {
	textFormula = TextFormula;
	atomList = AtomList;
	netCharge = NetCharge;
	drawBoundingRect = true;
	isMovable = false;
	xpos = 15;
	ypos = 15;
}

bool MolecularComponent::isMouseOverComponent(int mouseX, int mouseY) {
	if (mouseX > boundingRect.left && mouseX < boundingRect.right) {
		if (mouseY > boundingRect.top && mouseY < boundingRect.bottom) {
			return true;
		}
	}
	return false;
}

int MolecularComponent::draw(HDC hdc) {
	HFONT mainFont = CreateFont(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
	HFONT subscriptFont = CreateFont(10, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
	RECT textRect;
	//Start with drawing the symbols
	SelectObject(hdc, mainFont);
	std::string symbolString;
	std::vector<std::string> subscriptList;
	for (int i = 0; i < atomList.size(); i++) {
		symbolString += atomList[i].symbol;
		if (atomList[i].number > 1) { //leave a gap!
			subscriptList.push_back(std::to_string(atomList[i].number)); //add that index to the list!
			for (int j = 0; j < std::to_string(atomList[i].number).size(); j++) { //add a space for each digit of the subscript
				symbolString += "  ";
			}
		}
	}
	//Now add charge brackets and the charge itself if required (while sticking to all those chemistry symbol conventions...)
	if (netCharge != 0) {
		symbolString = "[" + symbolString + "]";
		if (abs(netCharge) > 1) {
			symbolString += std::to_string(netCharge);
		}
		if (netCharge > 0) {
			symbolString += "+";
		}
		else if (netCharge < 0) {
			symbolString += "-";
		}
	}

	textRect = { xpos, ypos, xpos + 5, ypos + 5 };
	SIZE textSize;
	GetTextExtentPoint32(hdc, symbolString.c_str(), symbolString.size(), &textSize);
	textRect.bottom = textRect.top + textSize.cy;
	textRect.right = textRect.left + textSize.cx;
	boundingRect = { textRect.left - 5, textRect.top - 5, textRect.right + 5, textRect.bottom + 5 };
	//Draw our background rectangle if required
	if (drawBoundingRect) {
		HBRUSH hBrush = CreateSolidBrush(RGB(230, 230, 230));
		HPEN hPen = CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
		SelectObject(hdc, hBrush);
		SelectObject(hdc, hPen);
		Rectangle(hdc, int(textRect.left - 5), int(textRect.top - 5), int(textRect.right + 5), int(textRect.bottom + 5));
		DeleteObject(hBrush);
		DeleteObject(hPen);
	}
	DrawText(hdc, symbolString.c_str(), symbolString.size(), &textRect, DT_LEFT | DT_NOCLIP);
	int currentSubscript = 0;
	int currentSymbolPos = 0;
	SIZE charSize;
	RECT textRect2 = { textRect.left - 2, textRect.top + 8, 0,0 };
	for (int i = 0; i < symbolString.size(); i++) {
		GetTextExtentPoint32(hdc, &symbolString[i], 1, &charSize);
		textRect2.left += charSize.cx;
		if (symbolString[i] == ' ') { //if we hit the first space in a gap...
			SelectObject(hdc, subscriptFont);
			DrawText(hdc, subscriptList[currentSubscript].c_str(), subscriptList[currentSubscript].size(), &textRect2, DT_LEFT | DT_NOCLIP);
			SelectObject(hdc, mainFont);
			currentSubscript++;
			//and now make sure we clear the spaces fully!
			while (symbolString[i] == ' ' && i < symbolString.size()) {
				i++;
				GetTextExtentPoint32(hdc, &symbolString[i], 1, &charSize);
				textRect2.left += charSize.cx;
			}
		}
	}
	DeleteObject(mainFont);
	DeleteObject(subscriptFont);
	return 0;
}

/****************************************************************************************************
*
*	Chemical Components class:
*	My chance to get revenge on chemistry by simplifying it horrifically! Yay! >:)
*	It is through this class that all chemical reactions take place
*	Stores all the meta about a chemical, with lists of all the chemical bonds and atoms etc.
*	Most common ones are stored in a .txt file, and will be added to over time!
*
*****************************************************************************************************/

ChemicalComponent::ChemicalComponent() {

}
ChemicalComponent::~ChemicalComponent() {

}

/****************************************************************************************************
*
*	Resource Component class:
*	Stores all the data about a component of a resource, since all resources are mixtures.
*
*****************************************************************************************************/

ResourceComponent::ResourceComponent(){
}
ResourceComponent::~ResourceComponent(){
}

__int64 ResourceComponent::createUniqueID() {
	/* initialize random seed: */
	srand(time(NULL)+mouseX*mouseY);
	int extra = rand() % 10; //random extra number from 0 -> 9!
	__int64 now = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
	std::string modifiedNow = std::to_string(now) + std::to_string(extra);
	uniqueID = atoll(modifiedNow.c_str());
	return uniqueID;
}

/*****************************************************************************************************
*
*	Stored Resource class:
*	Basic class that stores data about a particular resource when stored, attempting to be as flexible as possible
*
******************************************************************************************************/

StoredResource::StoredResource(){
}
StoredResource::~StoredResource(){
}

/**************************************************************************************************
*
*	Extractable Resource class:
*	Stores data about an unmined resource, existing on or within Mars itself.
*	Often contains multiple components
*
**************************************************************************************************/
ExtractableResource::ExtractableResource() {

}
ExtractableResource::~ExtractableResource() {

}

/*************************************************************************************************
*
*	UpdateGlobalResourceComponentList()
*	Adds a new resource component to the global list. Also updates the GUI comboboxes etc etc
*
**************************************************************************************************/

int UpdateGlobalResourceComponentList(ResourceComponent NewComponent) {
	//First, check to see if a component with this ID already exists...
	for (u_int i = 0; i < GlobalResourceComponentList.size(); i++) {
		if (GlobalResourceComponentList[i].uniqueID == NewComponent.uniqueID) {
			GlobalResourceComponentList[i] = NewComponent;
			return 2; //and leave! Our work is done!
		}
	}
	//otherwise, if we find this is a unique component...
	GlobalResourceComponentList.push_back(NewComponent); //The deed is done! Now to update everything!
	//Resource editor comboboxes
	for (u_int i = 0; i < NewExtractableResourceComponentsList.size(); i++) {
		HWND ResourceComponentCombobox = NewResourceComponentsWindowsControls[i][0];
		int currentCursorPos = SendMessage(ResourceComponentCombobox, CB_GETCURSEL, 0, 0);
		//SendMessage(ResourceComponentCombobox, DELE); //Clear out this list...
		//And re-add everything!
		for (u_int j = 0; j < GlobalResourceComponentList.size(); j++) {
			SendMessage(ResourceComponentCombobox, CB_ADDSTRING, 0, LPARAM(NewComponent.componentName.c_str()));
		}
		SendMessage(ResourceComponentCombobox, CB_SETCURSEL, currentCursorPos, 0); //Make sure we keep the currently selected component
	}
	return 1;
}