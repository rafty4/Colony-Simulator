
/*******************************************************************************************
*
*	Genral and windows setup!
*
********************************************************************************************/

#include "stdafx.h"

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nShowCmd){
	//The very first thing we do is get the application location...
	char path[FILENAME_MAX];

	if (GetModuleFileName(NULL, path, sizeof(path))) {
		applicationDirectory = path;
		applicationDirectory = applicationDirectory.substr(0, applicationDirectory.find_last_of("\\") + 1);
		OutputDebugString(applicationDirectory.c_str());
		OutputDebugString("\n");

		HANDLE hFind;
		WIN32_FIND_DATA data;

		hFind = FindFirstFile((applicationDirectory+"Resource Components\\*.*").c_str(), &data);
		if (hFind != INVALID_HANDLE_VALUE) {
			do {
				std::string file = data.cFileName;
				if (file.size() > 2) {
					file = applicationDirectory + "Resource Components\\" + file;
					std::ifstream inputFile;
					OutputDebugString("Found: ");
					OutputDebugString(data.cFileName);
					OutputDebugString("\n");
					inputFile.open(file.c_str(), std::ios::in); //Open for input only
					if (inputFile.is_open()) { //And if it has been successfully opened...
						std::string line;
						std::vector<std::string> fileLines;
						while (std::getline(inputFile, line)) {
							fileLines.push_back(line);
						}
						//Load all the parameters
						ResourceComponent ThisComponent = LoadResourceComponentFromFile(fileLines);
						inputFile.close();
						UpdateGlobalResourceComponentList(ThisComponent); //And add it to the relevant list and GUIs (not that any GUIs should need updating at this stage)
					}
					else {
						//Complain. Loudly.
						MessageBox(NULL, "Unable to open specified file! Is it open in another program?", "Could not open file", MB_ICONERROR);
						OutputDebugString("Error: Could not open file to save resource component in!\n");
					}
				}
			} while (FindNextFile(hFind, &data));
			FindClose(hFind);
		}
	}
	else {
		OutputDebugString("ERROR: Could not determine application file path!\n");
		MessageBox(NULL, "Could not determine application file path and parent directory!\nAutomatic loading of assets will not now take place.", "ERROR - Could not determine location!", MB_ICONERROR);
	}

	/***************************************************************
	*	General setup - load external data, files, etc
	****************************************************************/

	//First, load the periodic table!
	std::ifstream periodicTableFile("Periodic table proton numbers.txt");
	OutputDebugString("Loading 'Periodic table proton numbers.txt'...\n");
	if (periodicTableFile.is_open()) {
		std::string thisLine;
		int lineNum = 0;
		while (std::getline(periodicTableFile, thisLine)) {
			lineNum++;
			std::string newElementNum = "";
			int colNum = 0;
			for (int i = 0; i < thisLine.size(); i++) { //iterate through all the line characters
				if (thisLine[i] != ' ') { //add each character to the string, junking white space until we hit a ','
					if (thisLine[i] != ',') {
						newElementNum += thisLine[i];
					}
					if (thisLine[i] == ',' || i == thisLine.size() - 1) { //now we must be about to reach the next element!
						colNum++;
						if (newElementNum != "" && int(newElementNum.c_str()) != 0) { //if we do not have an empty string, and it is non-zero
							std::array <int, 2> pos = { colNum, lineNum };
							Atom newAtom = Atom("", "", atoi(newElementNum.c_str()), 0, atoi(newElementNum.c_str()), 0, pos);
							PeriodicTable.push_back(newAtom);
						}
						newElementNum = "";
					}
				}
			}
		}
		periodicTableFile.close(); //and now we're done, close it!
		if (lineNum > 0) {
			OutputDebugString("Successfully assimilated 'Periodic table proton numbers.txt'! It's technological distinctiveness has been added to our own!\n");
		}
		else {
			MessageBox(NULL, "Could not extract any data from 'Periodic table proton numbers.txt'!\nTry re-installing Colony Simulator to fix the issue.\nIf that doesn't work, contact the developers.\r\n", "Useless file!", MB_ICONERROR);
		}
		//now load all the accompanying data!
		std::ifstream periodicTableDataFile("Periodic table data.txt");
		OutputDebugString("Loading 'Periodic table data.txt'...\n");
		if (periodicTableDataFile.is_open()) {
			std::string thisLine;
			int lineNum = 0;
			//iterate through each line
			while (std::getline(periodicTableDataFile, thisLine)) {
				if (lineNum > 0) { //skip the headings on the first line
								   //now break up each line at the commas
					std::vector<std::string> elements;
					std::string element = "";
					for (int i = 0; i < thisLine.size(); i++) { //iterate through all the line characters
						if (thisLine[i] != ' ') { //add each character to the string, junking white space until we hit a ','
							if (thisLine[i] != ',') {
								element += thisLine[i];
							}
							else {
								elements.push_back(element);
								element = "";
							}
						}
					}
					PeriodicTable[lineNum - 1].name = elements[2];
					PeriodicTable[lineNum - 1].symbol = elements[1];
				}
				lineNum++;
			}
			periodicTableDataFile.close();
			OutputDebugString("Successfully loaded 'Periodic table data.txt'!\n");
		}
		else {
			MessageBox(NULL, "Could not find the file 'Periodic table data.txt'!\nThe file should be located in the main folder.\nEither find it, or try re-installing Colony Simulator to fix the issue.\r\n", "File not found!", MB_ICONERROR);
			OutputDebugString("Could not find file 'Periodic table data.txt'!\n");
		}
	}
	else {
		MessageBox(NULL, "Could not find the file 'Periodic table proton numbers.txt'!\nThe file should be located in the main folder.\nEither find it, or try re-installing Colony Simulator to fix the issue.\r\n", "File not found!", MB_ICONERROR);
		OutputDebugString("Could not find file 'Periodic table proton numbers.txt'!\n");
	}


	/***************************************************************
	*	Windows setup
	****************************************************************/
	WNDCLASSEX wClass;
	ZeroMemory(&wClass, sizeof(WNDCLASSEX));
	wClass.cbClsExtra = NULL;
	wClass.cbSize = sizeof(WNDCLASSEX);
	wClass.cbWndExtra = NULL;
	wClass.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1); //assign initial background color
	wClass.hCursor = LoadCursor(NULL, IDC_ARROW); //asign default mouse
	wClass.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_WIN32PROJECT1)); //asign icon images
	wClass.hIconSm = LoadIcon(wClass.hInstance, MAKEINTRESOURCE(IDI_SMALL)); //assign icon images
	wClass.hInstance = hInst;
	wClass.lpfnWndProc = (WNDPROC)WinProc;
	wClass.lpszClassName = "Window Class";
	wClass.lpszMenuName = MAKEINTRESOURCE(IDC_WIN32PROJECT1); //create menu
	wClass.style = CS_HREDRAW | CS_VREDRAW;


	if (!RegisterClassEx(&wClass))
	{
		int nResult = GetLastError();
		MessageBox(NULL, "Window class creation failed\r\n", "Window Class Failed", MB_ICONERROR);
	}

	mainWindowHWND = CreateWindowEx(NULL, "Window Class", "Colony Simulator v0.4.0", WS_OVERLAPPEDWINDOW, 20, 20, 1400, 800, NULL, NULL, hInst, NULL);

	if (!mainWindowHWND)
	{
		int nResult = GetLastError();
		MessageBox(NULL, "Window creation failed\r\n", "Window Creation Failed", MB_ICONERROR);
	}

	ShowWindow(mainWindowHWND, nShowCmd);
	UpdateWindow(mainWindowHWND);

	/**************************************************************************************************************************************************************************
	*
	*	Setup window to draw flowchart in!
	*
	**************************************************************************************************************************************************************************/

	//setup initial values for the window
	WNDCLASS FlowchartWindow;
	static TCHAR FlowchartWindowName[] = TEXT("Flowchart Window");

	FlowchartWindow.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
	FlowchartWindow.lpfnWndProc = FlowchartWindowProc; //the LRESULT CALLBACK function
	FlowchartWindow.cbClsExtra = 0;
	FlowchartWindow.cbWndExtra = sizeof(long);
	FlowchartWindow.hInstance = hInst;
	FlowchartWindow.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	FlowchartWindow.hCursor = LoadCursor(NULL, IDC_ARROW);
	FlowchartWindow.hbrBackground = NULL;// (HBRUSH)GetStockObject(WHITE_BRUSH);
	FlowchartWindow.lpszMenuName = NULL;
	FlowchartWindow.lpszClassName = FlowchartWindowName;

	mainHinst = hInst;

	if (!RegisterClass(&FlowchartWindow))
	{
		MessageBox(NULL, TEXT("Error creating flowchart window"), FlowchartWindowName, MB_ICONERROR);
		OutputDebugString("Error: could not create flowchart window\n");
		return 0;
	}

	FlowchartWindowHandle = CreateWindow(FlowchartWindowName, "Resource Flowchart", WS_CHILD | WS_VISIBLE | WS_BORDER | WS_CLIPCHILDREN, 10, 60, win_width - 10, win_height - 60, mainWindowHWND, NULL, hInst, NULL);

	ShowWindow(FlowchartWindowHandle, SW_SHOW); //show it
	UpdateWindow(FlowchartWindowHandle); //and update it!

	SCROLLINFO si = { sizeof(si) };

	si.fMask = SIF_POS | SIF_PAGE | SIF_RANGE;
	si.nPos = 0;         // scrollbar thumb position
	si.nPage = win_height;        // number of lines in a page (i.e. rows of text in window)
	si.nMin = 0;
	si.nMax = win_height + 10;      // total number of lines in file (i.e. total scroll range)

	SetScrollInfo(FlowchartWindowHandle, SB_VERT, &si, FALSE);

	si.fMask = SIF_POS | SIF_PAGE | SIF_RANGE;
	si.nPos = 0;         // scrollbar thumb position
	si.nPage = win_width;        // number of lines in a page (i.e. rows of text in window)
	si.nMin = 0;
	si.nMax = win_width + 10;      // total number of lines in file (i.e. total scroll range)

	SetScrollInfo(FlowchartWindowHandle, SB_HORZ, &si, FALSE);


	/*************************************************************************************************************************************************************************/


	/******************************************************************************************************************************
	*
	*	Setup "create new node" window!
	*
	******************************************************************************************************************************/

	//setup initial values for the window
	WNDCLASS NodeCreateWindow;
	static TCHAR NodeCreateWindowName[] = TEXT("Create new node");

	NodeCreateWindow.style = CS_HREDRAW | CS_VREDRAW;
	NodeCreateWindow.lpfnWndProc = NodeCreationWindowProc; //the LRESULT CALLBACK function
	NodeCreateWindow.cbClsExtra = 0;
	NodeCreateWindow.cbWndExtra = sizeof(long);
	NodeCreateWindow.hInstance = hInst;
	NodeCreateWindow.hIcon = LoadIcon(wClass.hInstance, MAKEINTRESOURCE(IDI_SMALL)); //give this window the same icon as the main application
	NodeCreateWindow.hCursor = LoadCursor(NULL, IDC_ARROW);
	NodeCreateWindow.hbrBackground = NULL;// (HBRUSH)GetStockObject(WHITE_BRUSH);
	NodeCreateWindow.lpszMenuName = NULL;
	NodeCreateWindow.lpszClassName = NodeCreateWindowName;

	if (!RegisterClass(&NodeCreateWindow))
	{
		MessageBox(NULL, TEXT("Error creating node creation window"), NodeCreateWindowName, MB_ICONERROR);
		OutputDebugString("Error: could not create node creation window\n");
		return 0;
	}

	NodeCreateWindowHandle = CreateWindow(NodeCreateWindowName, "Create new node", WS_CAPTION | WS_POPUP | WS_BORDER | WS_TILED | WS_SYSMENU | WS_EX_CONTEXTHELP, 10, 40, 300, 300, mainWindowHWND, NULL, hInst, NULL);

	ShowWindow(NodeCreateWindowHandle, SW_HIDE); //hide it
	UpdateWindow(NodeCreateWindowHandle); //and update it!

	/************************************************************************************************************************************************************************/

	/**********************************************************************************************************************
	*
	*	Setup node connection points window
	*
	***********************************************************************************************************************/

	//setup initial values for the window
	WNDCLASS NodeConnEditWindow;
	static TCHAR NodeConnEditWindowName[] = TEXT("Connection Point Editor");

	NodeConnEditWindow.style = CS_HREDRAW | CS_VREDRAW;
	NodeConnEditWindow.lpfnWndProc = NodeConnEditWindowProc; //the LRESULT CALLBACK function
	NodeConnEditWindow.cbClsExtra = 0;
	NodeConnEditWindow.cbWndExtra = sizeof(long);
	NodeConnEditWindow.hInstance = hInst;
	NodeConnEditWindow.hIcon = LoadIcon(wClass.hInstance, MAKEINTRESOURCE(IDI_SMALL));
	NodeConnEditWindow.hCursor = LoadCursor(NULL, IDC_ARROW);
	NodeConnEditWindow.hbrBackground = NULL; // (HBRUSH)GetStockObject(WHITE_BRUSH);
	NodeConnEditWindow.lpszMenuName = NULL;
	NodeConnEditWindow.lpszClassName = NodeConnEditWindowName;

	if (!RegisterClass(&NodeConnEditWindow))
	{
		MessageBox(NULL, TEXT("Error creating connection edit window"), NodeConnEditWindowName, MB_ICONERROR);
		OutputDebugString("Error: could not create connection edit window\n");
		return 0;
	}

	NodeConnEditWindowHandle = CreateWindow(NodeConnEditWindowName, "Connection Point Editor", WS_CAPTION | WS_POPUP | WS_BORDER | WS_TILED | WS_SYSMENU | WS_EX_CONTEXTHELP, 320, 100, 375, 470, NodeCreateWindowHandle, NULL, hInst, NULL);

	ShowWindow(NodeConnEditWindowHandle, SW_HIDE); //hide it
	UpdateWindow(NodeConnEditWindowHandle); //and update it!

	/************************************************************************************************************************************************************************/

	/**********************************************************************************************************************
	*
	*	Set up the Extractable Resource Creation/Editing Window
	*
	***********************************************************************************************************************/

	//setup initial values for the window
	WNDCLASS ExtractableResourceCreationWindow;
	static TCHAR ExtractableResourceCreationWindowName[] = TEXT("Extractable Resource Editor");

	ExtractableResourceCreationWindow.style = CS_HREDRAW | CS_VREDRAW;
	ExtractableResourceCreationWindow.lpfnWndProc = ExtractableResourceCreationWindowProc; //the LRESULT CALLBACK function
	ExtractableResourceCreationWindow.cbClsExtra = 0;
	ExtractableResourceCreationWindow.cbWndExtra = sizeof(long);
	ExtractableResourceCreationWindow.hInstance = hInst;
	ExtractableResourceCreationWindow.hIcon = LoadIcon(wClass.hInstance, MAKEINTRESOURCE(IDI_SMALL));
	ExtractableResourceCreationWindow.hCursor = LoadCursor(NULL, IDC_ARROW);
	ExtractableResourceCreationWindow.hbrBackground = NULL; // (HBRUSH)GetStockObject(WHITE_BRUSH);
	ExtractableResourceCreationWindow.lpszMenuName = NULL;
	ExtractableResourceCreationWindow.lpszClassName = ExtractableResourceCreationWindowName;

	if (!RegisterClass(&ExtractableResourceCreationWindow))
	{
		MessageBox(NULL, TEXT("Error creating Extractable Resource edit window"), ExtractableResourceCreationWindowName, MB_ICONERROR);
		OutputDebugString("Error: could not create Extractable Resource Edit window\n");
		return 0;
	}

	ExtractableResourceCreationWindowHandle = CreateWindow(ExtractableResourceCreationWindowName, "Resource Editor", WS_CAPTION | WS_POPUP | WS_BORDER | WS_TILED | WS_SYSMENU | WS_EX_CONTEXTHELP, 820, 150, 375, 490, mainWindowHWND, NULL, hInst, NULL);

	ShowWindow(ExtractableResourceCreationWindowHandle, SW_HIDE); //hide it
	UpdateWindow(ExtractableResourceCreationWindowHandle); //and update it!

	/**********************************************************************************************************************
	*
	*	Set up the Resource Component Creation/Editing Window
	*
	***********************************************************************************************************************/

	//setup initial values for the window
	WNDCLASS ResourceComponentCreationWindow;
	static TCHAR ResourceComponentCreationWindowName[] = TEXT("Resource Component Editor");

	ResourceComponentCreationWindow.style = CS_HREDRAW | CS_VREDRAW;
	ResourceComponentCreationWindow.lpfnWndProc = ResourceComponentCreationWindowProc; //the LRESULT CALLBACK function
	ResourceComponentCreationWindow.cbClsExtra = 0;
	ResourceComponentCreationWindow.cbWndExtra = sizeof(long);
	ResourceComponentCreationWindow.hInstance = hInst;
	ResourceComponentCreationWindow.hIcon = LoadIcon(wClass.hInstance, MAKEINTRESOURCE(IDI_SMALL));
	ResourceComponentCreationWindow.hCursor = LoadCursor(NULL, IDC_ARROW);
	ResourceComponentCreationWindow.hbrBackground = NULL; // (HBRUSH)GetStockObject(WHITE_BRUSH);
	ResourceComponentCreationWindow.lpszMenuName = NULL;
	ResourceComponentCreationWindow.lpszClassName = ResourceComponentCreationWindowName;

	if (!RegisterClass(&ResourceComponentCreationWindow))
	{
		MessageBox(NULL, TEXT("Error creating Resource Component Edit window"), ResourceComponentCreationWindowName, MB_ICONERROR);
		OutputDebugString("Error: could not create Resource Component Edit window\n");
		return 0;
	}

	ResourceComponentCreationWindowHandle = CreateWindow(ResourceComponentCreationWindowName, "Resource Component Editor", WS_CAPTION | WS_POPUP | WS_BORDER | WS_TILED | WS_SYSMENU | WS_EX_CONTEXTHELP, 1150, 30, 380, 790, ExtractableResourceCreationWindowHandle, NULL, hInst, NULL);

	ShowWindow(ResourceComponentCreationWindowHandle, SW_HIDE); //hide it
	UpdateWindow(ResourceComponentCreationWindowHandle); //and update it!

	/************************************************************************************************************************************************************************/

	/**********************************************************************************************************************
	*
	*	Set up the Chemical formula window!
	*
	***********************************************************************************************************************/

	//setup initial values for the window
	WNDCLASS ChemicalFormulaCreationWindow;
	static TCHAR ChemicalFormulaCreationWindowName[] = TEXT("Chemistry creation window");

	ChemicalFormulaCreationWindow.style = CS_HREDRAW | CS_VREDRAW;
	ChemicalFormulaCreationWindow.lpfnWndProc = ChemicalFormulaCreationWindowProc; //the LRESULT CALLBACK function
	ChemicalFormulaCreationWindow.cbClsExtra = 0;
	ChemicalFormulaCreationWindow.cbWndExtra = sizeof(long);
	ChemicalFormulaCreationWindow.hInstance = hInst;
	ChemicalFormulaCreationWindow.hIcon = LoadIcon(wClass.hInstance, MAKEINTRESOURCE(IDI_SMALL));
	ChemicalFormulaCreationWindow.hCursor = LoadCursor(NULL, IDC_ARROW);
	ChemicalFormulaCreationWindow.hbrBackground = NULL; // (HBRUSH)GetStockObject(WHITE_BRUSH);
	ChemicalFormulaCreationWindow.lpszMenuName = NULL;
	ChemicalFormulaCreationWindow.lpszClassName = ChemicalFormulaCreationWindowName;

	if (!RegisterClass(&ChemicalFormulaCreationWindow))
	{
		MessageBox(NULL, TEXT("Error creating Structural Chemistry Edit window"), ChemicalFormulaCreationWindowName, MB_ICONERROR);
		OutputDebugString("Error: could not create Structural Chemistry Edit window\n");
		return 0;
	}

	ChemicalFormulaCreationWindowHandle = CreateWindow(ChemicalFormulaCreationWindowName, "Chemical Structure Editor", WS_CAPTION | WS_POPUP | WS_BORDER | WS_TILED | WS_SYSMENU | WS_EX_CONTEXTHELP, 1000, 50, 400, 300, ResourceComponentCreationWindowHandle, NULL, hInst, NULL);

	ShowWindow(ChemicalFormulaCreationWindowHandle, SW_HIDE); //hide it
	UpdateWindow(ChemicalFormulaCreationWindowHandle); //and update it!

	/**************************************************************************************************************************************************************************
	*
	*	Setup the child window that actually shows the chemical structure
	*
	**************************************************************************************************************************************************************************/

	//setup initial values for the window
	WNDCLASS ChemicalStructureWindow;
	static TCHAR ChemicalStructureWindowName[] = TEXT("Chemical Structure");

	ChemicalStructureWindow.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
	ChemicalStructureWindow.lpfnWndProc = ChemicalStructureWindowProc; //the LRESULT CALLBACK function
	ChemicalStructureWindow.cbClsExtra = 0;
	ChemicalStructureWindow.cbWndExtra = sizeof(long);
	ChemicalStructureWindow.hInstance = hInst;
	ChemicalStructureWindow.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	ChemicalStructureWindow.hCursor = LoadCursor(NULL, IDC_ARROW);
	ChemicalStructureWindow.hbrBackground = NULL;// (HBRUSH)GetStockObject(WHITE_BRUSH);
	ChemicalStructureWindow.lpszMenuName = NULL;
	ChemicalStructureWindow.lpszClassName = ChemicalStructureWindowName;

	if (!RegisterClass(&ChemicalStructureWindow))
	{
		MessageBox(NULL, TEXT("Error creating Chemical Structure window"), ChemicalStructureWindowName, MB_ICONERROR);
		OutputDebugString("Error: could not create chemical structure window\n");
		return 0;
	}

	ChemicalStructureWindowHandle = CreateWindow(ChemicalStructureWindowName, "Structure", WS_CHILD | WS_VISIBLE | WS_BORDER | WS_CLIPCHILDREN, 10, 0, 365, 195, ChemicalFormulaCreationWindowHandle, NULL, hInst, NULL);

	ShowWindow(ChemicalStructureWindowHandle, SW_SHOW); //show it
	UpdateWindow(ChemicalStructureWindowHandle); //and update it!

	/**********************************************************************************************************************
	*
	*	Set up the Periodic table window!
	*
	***********************************************************************************************************************/

	//setup initial values for the window
	WNDCLASS PeriodicTableWindow;
	static TCHAR PeriodicTableWindowName[] = TEXT("Periodic Table");

	PeriodicTableWindow.style = CS_HREDRAW | CS_VREDRAW;
	PeriodicTableWindow.lpfnWndProc = PeriodicTableWindowProc; //the LRESULT CALLBACK function
	PeriodicTableWindow.cbClsExtra = 0;
	PeriodicTableWindow.cbWndExtra = sizeof(long);
	PeriodicTableWindow.hInstance = hInst;
	PeriodicTableWindow.hIcon = LoadIcon(wClass.hInstance, MAKEINTRESOURCE(IDI_SMALL));
	PeriodicTableWindow.hCursor = LoadCursor(NULL, IDC_ARROW);
	PeriodicTableWindow.hbrBackground = NULL; // (HBRUSH)GetStockObject(WHITE_BRUSH);
	PeriodicTableWindow.lpszMenuName = NULL;
	PeriodicTableWindow.lpszClassName = PeriodicTableWindowName;

	if (!RegisterClass(&PeriodicTableWindow))
	{
		MessageBox(NULL, TEXT("Error creating Periodic Table window"), PeriodicTableWindowName, MB_ICONERROR);
		OutputDebugString("Error: could not create Periodic Table window\n");
		return 0;
	}

	PeriodicTableWindowHandle = CreateWindow(PeriodicTableWindowName, "Periodic Table", WS_CAPTION | WS_POPUP | WS_BORDER | WS_TILED | WS_SYSMENU | WS_EX_CONTEXTHELP, 500, 350, 1040, 410, ChemicalFormulaCreationWindowHandle, NULL, hInst, NULL);

	ShowWindow(PeriodicTableWindowHandle, SW_HIDE); //hide it
	UpdateWindow(PeriodicTableWindowHandle); //and update it!


	/************************************************************************************************************************************************************************/


	MSG msg;
	ZeroMemory(&msg, sizeof(MSG));

	/******************************************************************/

	HWND hwndTT = NULL;
	//hwndTT = createTooltip(FlowchartWindowHandle, hwndTT);

	//Main loop!
	while (GetMessage(&msg, NULL, 0, 0)) {
		//deal with scrollbars
		SCROLLINFO si = { sizeof(si), SIF_TRACKPOS };
		GetScrollInfo(FlowchartWindowHandle, SB_VERT, &si);
		viewY = (float)si.nTrackPos;
		GetScrollInfo(FlowchartWindowHandle, SB_HORZ, &si);
		viewX = (float)si.nTrackPos;

		RedrawWindow(FlowchartWindowHandle, NULL, NULL, RDW_INVALIDATE); //and refresh!
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return 0;
}
