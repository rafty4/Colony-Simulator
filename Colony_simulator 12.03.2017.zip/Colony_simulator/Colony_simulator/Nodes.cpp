
/******************************************************************************************************
*
*	Node creation window processes!
*
*******************************************************************************************************/

#include "stdafx.h"

LRESULT CALLBACK NodeCreationWindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	PAINTSTRUCT ps;
	HDC hdc;
	HGDIOBJ hfDefault = GetStockObject(DEFAULT_GUI_FONT);

	switch (msg)
	{
	case WM_CREATE:
	{
		RECT windowRect;
		GetWindowRect(hWnd, &windowRect);

		// Create node name edit box
		nodeNameBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "Name:", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 55, 10, 150, 20, hWnd, (HMENU)IDC_NODE_CREATE_NAME, GetModuleHandle(NULL), NULL);
		nodeDescBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "Desc:", WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL, 55, 35, 220, 80, hWnd, (HMENU)IDC_NODE_CREATE_DESC, GetModuleHandle(NULL), NULL);
		//Despatch the relevant messages to set up fonts etc.
		SendMessage(nodeNameBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(nodeDescBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

		//Create the buttons!
		HWND CreateButton = CreateWindowEx(NULL, "BUTTON", "Create", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 75, (windowRect.bottom - windowRect.top) - 70, 100, 25, hWnd, (HMENU)IDW_APPROVE_NODE_CREATION, GetModuleHandle(NULL), NULL);
		HWND CancelButton = CreateWindowEx(NULL, "BUTTON", "Cancel", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 180, (windowRect.bottom - windowRect.top) - 70, 100, 25, hWnd, (HMENU)IDW_CANCEL_NODE_CREATION, GetModuleHandle(NULL), NULL);
		HWND EditConnectionsButton = CreateWindowEx(NULL, "BUTTON", "Node Editor", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 160, 90, 22, hWnd, (HMENU)IDW_EDIT_CONNECTIONS, GetModuleHandle(NULL), NULL);
		HWND ImportNodeButton = CreateWindowEx(NULL, "BUTTON", "Import Node", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 190, 90, 22, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		//Despatch the relevant messages for each button
		SendMessage(CreateButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(CancelButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(EditConnectionsButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(ImportNodeButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
	}
	break;
	case IDC_REQ_NEW_NODE: //A new node has been requested!
	{
		//First clear out the current connections
		ForwardsConnectionsToAdd.clear();
		BackwardsConnectionsToAdd.clear();
		//add a forwards connection node
		ConnectionPoint newConnectionPoint(0);
		ForwardsConnectionsToAdd.push_back(newConnectionPoint);
		BackwardsConnectionsToAdd.push_back(newConnectionPoint);

		switch (LOWORD(lParam)) { //get the low-level word
		case IDC_REQ_RESOURCE: //if it's a resource requested...
		{
			nodeEditWindowMode = 0;
			BackwardsConnectionsToAdd.clear(); //remove all backwards connections
			SendMessage(nodeNameBox, WM_SETTEXT, NULL, (LPARAM)"New Resource"); //set the text in the naming box appropriately
			SendMessage(nodeDescBox, WM_SETTEXT, NULL, (LPARAM)"[Default] The starting node of a resource graph, representing either infinate or finite raw resources found in the environment. Connect to an extractor node to create useful resources which can be processed and consumed. In theory a colony can be run without resource nodes, but it will not be sustainable."); //set up a default description
			nodeCreationType = 0;
			ShowWindow(NodeCreateWindowHandle, SW_SHOW); //show it
			UpdateWindow(NodeCreateWindowHandle); //and update it!
												  //SendMessage(hWnd, WM_PAINT, 0, 0); //tell the window it needs to refresh
		}
		break;
		case IDC_REQ_EXTRACTOR: //if it's an extractor requested...
		{
			nodeEditWindowMode = 1;
			SendMessage(nodeNameBox, WM_SETTEXT, NULL, (LPARAM)"New Extractor");
			SendMessage(nodeDescBox, WM_SETTEXT, NULL, (LPARAM)"[Default] Extracts the resource outputted from a single Resource Node's connection, and turns them into user-defined 'useful' resources. These can then be processed or consumed by industrial process and consumer nodes respectively. Can take inputs from both resource and other extractor nodes, and can output to extractor, process, and consumer nodes."); //set up a default description
			nodeCreationType = 1;
			ShowWindow(NodeCreateWindowHandle, SW_SHOW); //show it
			UpdateWindow(NodeCreateWindowHandle); //and update it!
		}
		break;
		case IDC_REQ_INDUSTRIAL: //if it's a process requested...
		{
			nodeEditWindowMode = 2;
			SendMessage(nodeNameBox, WM_SETTEXT, NULL, (LPARAM)"New Process");
			SendMessage(nodeDescBox, WM_SETTEXT, NULL, (LPARAM)"[Default] Changes one extracted resource into another, potentially using up other resources in the process. Can take inputs from all nodes apart from resource nodes, and can send outputs to other process, storage, and consumer nodes."); //set up a default description
			nodeCreationType = 2;
			ShowWindow(NodeCreateWindowHandle, SW_SHOW); //show it
			UpdateWindow(NodeCreateWindowHandle); //and update it!
		}
		break;
		case IDC_REQ_CONSUMER: //if it's a consumer requested...
		{
			nodeEditWindowMode = 3;
			SendMessage(nodeNameBox, WM_SETTEXT, NULL, (LPARAM)"New Consumer");
			SendMessage(nodeDescBox, WM_SETTEXT, NULL, (LPARAM)"[Default] Consumes resources provided to it, and produces other resources. Very similar to a process node. Can take inputs from extractor, process, other consumers and storage nodes, and can send outputs to process, consumer, and storage nodes."); //set up a default description
			nodeCreationType = 3;
			ShowWindow(NodeCreateWindowHandle, SW_SHOW); //show it
			UpdateWindow(NodeCreateWindowHandle); //and update it!
		}
		break;
		case IDC_REQ_STORAGE: //if it's a storage node requested...
		{
			nodeEditWindowMode = 4;
			SendMessage(nodeNameBox, WM_SETTEXT, NULL, (LPARAM)"New Storage");
			SendMessage(nodeDescBox, WM_SETTEXT, NULL, (LPARAM)"[Default] Stores resources provided to it, up to a set amount, and can release them upon request or at will at user-defined flow rates. Can take inputs from extractor, process, consumer and other storage nodes, and can send outputs to all nodes except resource nodes."); //set up a default description
			nodeCreationType = 4;
			ShowWindow(NodeCreateWindowHandle, SW_SHOW); //show window
			UpdateWindow(NodeCreateWindowHandle); //and update it!
		}
		break;
		}
	}
	break;
	case WM_COMMAND:
	{
		switch (LOWORD(wParam)) {
		case IDW_APPROVE_NODE_CREATION:
		{
			SendMessage(hWnd, WM_CLOSE, NULL, NULL); //and close!
			ShowWindow(NodeConnEditWindowHandle, SW_HIDE); //hide the node edit window
			if (nodeCreationType == 0) { //resource node
				SendMessage(mainWindowHWND, WM_COMMAND, IDC_ADD_RESOURCE, 0); //notify the main window it needs to create a new node!
																			  //nodeCreationType = -1; //reset the node type being created
			}
			else if (nodeCreationType == 1) { //extractor node
				SendMessage(mainWindowHWND, WM_COMMAND, IDC_ADD_EXTRACTOR, 0); //notify the main window it needs to create a new node!
																			   //nodeCreationType = -1;
			}
			else if (nodeCreationType == 2) { //process node
				SendMessage(mainWindowHWND, WM_COMMAND, IDC_ADD_INDUSTRIAL, 0); //notify the main window it needs to create a new node!
																				//nodeCreationType = -1;
			}
			else if (nodeCreationType == 3) { //consumer node
				SendMessage(mainWindowHWND, WM_COMMAND, IDC_ADD_CONSUMER, 0); //notify the main window it needs to create a new node!
																			  //nodeCreationType = -1;
			}
			else if (nodeCreationType == 4) { //storage node
				SendMessage(mainWindowHWND, WM_COMMAND, IDC_ADD_STORAGE, 0); //notify the main window it needs to create a new node!
																			 //nodeCreationType = -1;
			}
			break;
		}
		case IDW_CANCEL_NODE_CREATION:
			SendMessage(hWnd, WM_CLOSE, NULL, NULL); //Send a message to itself to goto the close routine. Also, it's talking to itself! How CUTE!
			ShowWindow(NodeConnEditWindowHandle, SW_HIDE); //hide the other window
														   //nodeCreationType = -1; //reset the node type being created
			break;
		case IDW_EDIT_CONNECTIONS:
			UpdateWindow(NodeCreateWindowHandle); //update this window
			SendMessage(NodeConnEditWindowHandle, WM_COMMAND, IDCE_EDIT_CONNECTIONS, 0); //inform the connection edit window we want it open. NOW!
			break;
		}
	}
	break;
	/******************************************************************************
	*	Drawing happens here!
	*******************************************************************************/
	case WM_PAINT:
	{
		hdc = BeginPaint(hWnd, &ps);

		RECT clientRect;
		HRGN bgRgn;
		HBRUSH hBrush;
		GetClientRect(hWnd, &clientRect);
		win_width = clientRect.right - clientRect.left;
		win_height = clientRect.bottom - clientRect.top;
		bgRgn = CreateRectRgnIndirect(&clientRect);
		hBrush = CreateSolidBrush(RGB(255, 255, 255)); //colour it white
		FillRgn(hdc, bgRgn, hBrush); //draw to offscreen buffer

		TCHAR buff[20];

		//add text GUI labels
		TextOut(hdc, 10, 10, "Name:", _tcslen("Name:"));
		TextOut(hdc, 10, 35, "Desc:", _tcslen("Desc:"));
		TextOut(hdc, 10, 120, "Forwards Connections:", _tcslen("Forwards Connections:"));
		if (nodeCreationType == 0) { //if it's a resource node
			SetTextColor(hdc, RGB(127, 127, 127)); //grey out the backwards-facing nodes
		}
		TextOut(hdc, 10, 140, "Backwards Connections:", _tcslen("Backwards Connections:"));
		//add numbers...
		TextOut(hdc, 180, 140, buff, wsprintf(buff, TEXT("%d"), BackwardsConnectionsToAdd.size()));
		SetTextColor(hdc, RGB(0, 0, 0)); //back to black.
		TextOut(hdc, 180, 120, buff, wsprintf(buff, TEXT("%d"), ForwardsConnectionsToAdd.size()));

		EndPaint(hWnd, &ps);
		break;
	}
	/******************************************************************************/
	case WM_CLOSE: //when the user requests the window to be closed...
		ShowWindow(hWnd, SW_HIDE); //We don't. We hide the window instead! Mwahahaha!
		ShowWindow(NodeConnEditWindowHandle, SW_HIDE); //hide the other window too!
		break;
	case WM_DESTROY: //but if they insist...
		nodeCreationType = -1; //reset that
		ShowWindow(NodeConnEditWindowHandle, SW_HIDE); //hide the other window
		//PostQuitMessage(0);
		return 1;
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
		break;
	}
	DeleteObject(hfDefault); //delete the default GUI text object to plug memory leaks
	return 0;
}

/********************************************************************************************************
*
*	Connection Point Editor Window main process!
*
*********************************************************************************************************/

LRESULT CALLBACK NodeConnEditWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	HDC hdc;
	PAINTSTRUCT ps;
	HGDIOBJ hfDefault = GetStockObject(DEFAULT_GUI_FONT);

	/******************************************************************************************
	*	Dealing with the dynamically created window per-output buttons!
	*******************************************************************************************/
	if (message == WM_COMMAND && LOWORD(wParam) >= 620 && LOWORD(wParam) < 700) { //if the value is in the range for the dynamically created buttons
		if (LOWORD(wParam) >= 620 && LOWORD(wParam) < 640) { //the 'import new resource' button

		}
		else if (LOWORD(wParam) >= 640 && LOWORD(wParam) < 660) { //The 'create new resource' button
			SendMessage(ExtractableResourceCreationWindowHandle, WM_COMMAND, ERCW_CREATE_NEW, 0);
		}
		else if (LOWORD(wParam) >= 660 && LOWORD(wParam) < 680) { //The 'remove' button
			int outputVal = LOWORD(wParam) - 660;
			//update all the connections to reflect the control's values
			if (nodeEditWindowMode == 0) {
				for (int i = 0; i < NewForwardsConnectionsToAdd.size(); i++) {
					//get the edit box text for the flow rate
					char data[32];
					GetWindowText(NodeOutputTypeList[i][1], data, 32);
					NewForwardsConnectionsToAdd[i].maxFlowRate = (float)atof(data); //explicit conversion to float because atof() should really be called atod()...
					NewForwardsConnectionsToAdd[i].maxFlowRateUnits = FlowRateUnitsList[SendMessage(NodeOutputTypeList[i][2], CB_GETCURSEL, 0, 0)]; //get the combobox's current text, and assign use it to update the connection
				}
				NewForwardsConnectionsToAdd.erase(NewForwardsConnectionsToAdd.begin() + outputVal); //remove this particular output
				SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_CONTROLS, NULL); //And refresh the buttons!
			}
			else if (nodeEditWindowMode == 1) { //Extractor node
				if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 0) { //if we are on the 'inputs' tab...
					SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_BACKWARDS, 0);
					NewBackwardsConnectionsToAdd.erase(NewBackwardsConnectionsToAdd.begin() + outputVal); //remove this particular output
					SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_CONTROLS, NULL); //And refresh the windows controls!
				}
				else if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 1) { //We are on the 'processes' tab

				}
				else if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 2) { //We are on the 'outputs' tab
					SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_FORWARDS, 0);
					NewForwardsConnectionsToAdd.erase(NewForwardsConnectionsToAdd.begin() + outputVal); //remove this particular output
					SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_CONTROLS, NULL); //And refresh the buttons!
				}
			}
		}
		else if (LOWORD(wParam) >= 680 && LOWORD(wParam) < 700) { //The 'delimit' checkbox or flow rate mode combobox
			int outputVal = LOWORD(wParam) - 680;
			if (nodeEditWindowMode == 0) {
				if (SendMessage(NodeOutputTypeList[outputVal][6], BM_GETCHECK, 0, 0) == BST_CHECKED) { //if the checkbox has been checked, disable the flow controls
					EnableWindow(NodeOutputTypeList[outputVal][1], FALSE);
					EnableWindow(NodeOutputTypeList[outputVal][2], FALSE);
					NewForwardsConnectionsToAdd[outputVal].isMaxFlowRateDelimited = true; //inform the connection that it has been delimited
				}
				else {//enable the flow controls
					EnableWindow(NodeOutputTypeList[outputVal][1], TRUE);
					EnableWindow(NodeOutputTypeList[outputVal][2], TRUE);
					NewForwardsConnectionsToAdd[outputVal].isMaxFlowRateDelimited = false; //inform the connection it is now bound by the laws of physics
				}
			}
			else if (nodeEditWindowMode == 1) {
				if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 0) { //if we are on the 'inputs' tab, so we gotta deal with the flow rate mode combobox!
				}
				else if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 2) { //We are on the 'outputs tab'
					if (SendMessage(NodeOutputTypeList[outputVal][6], BM_GETCHECK, 0, 0) == BST_CHECKED) { //if the checkbox has been checked, disable the flow controls
						EnableWindow(NodeOutputTypeList[outputVal][1], FALSE);
						EnableWindow(NodeOutputTypeList[outputVal][2], FALSE);
						NewForwardsConnectionsToAdd[outputVal].isMaxFlowRateDelimited = true; //inform the connection that it has been delimited
					}
					else {//enable the flow controls
						EnableWindow(NodeOutputTypeList[outputVal][1], TRUE);
						EnableWindow(NodeOutputTypeList[outputVal][2], TRUE);
						NewForwardsConnectionsToAdd[outputVal].isMaxFlowRateDelimited = false; //inform the connection it is now bound by the laws of physics
					}
				}
			}
		}
	}

	/******************************************************************************************
	*	The usual switch-case statements
	*******************************************************************************************/
	switch (message)
	{
	case WM_CREATE:
	{
		NodeEditApplyButton = CreateWindowEx(NULL, "BUTTON", "Apply", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 400, 100, 25, hWnd, (HMENU)IDCE_APPLY_EDIT, GetModuleHandle(NULL), NULL);
		NodeEditOkButton = CreateWindowEx(NULL, "BUTTON", "Ok", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 120, 400, 100, 25, hWnd, (HMENU)IDCE_FINISH_EDIT, GetModuleHandle(NULL), NULL);
		NodeEditCancelButton = CreateWindowEx(NULL, "BUTTON", "Cancel", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 230, 400, 100, 25, hWnd, (HMENU)IDCE_CANCEL_EDIT, GetModuleHandle(NULL), NULL);
		NodeEditTabControl = CreateWindowEx(NULL, WC_TABCONTROL, "TAB", WS_VISIBLE | WS_CHILD | TCS_BUTTONS, 0, 25, 500, 20/*410*/, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);

		SendMessage(NodeEditApplyButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(NodeEditCancelButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(NodeEditOkButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(NodeEditTabControl, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
	}
	break;
	case WM_NOTIFY: //Messages from the tabs!
	{
		switch (((LPNMHDR)lParam)->code) {
		case TCN_SELCHANGING: //if we are about to chnage tabs, but haven't quite yet
		{
			if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 0) { //save the inputs
				SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_BACKWARDS, 0);
			}
			else if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 1) { //save the processes
				SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_PROCESSES, 0);
			}
			else if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 2) { //save the inputs
				SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_FORWARDS, 0);
			}
		}
		break;
		case TCN_SELCHANGE: //if we actually have now changed tabs
		{
			SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_CONTROLS, 0);
			RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE);
		}
		break;
		}
	}
	break;
	case WM_COMMAND:
	{
		switch (HIWORD(wParam)) {
		case CBN_SELCHANGE: //If a combobox has changed value
		{
			if (nodeEditWindowMode == 1) {
				if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 0) { //If we are on the 'inputs' tab...
					if (LOWORD(wParam) >= 680 && LOWORD(wParam) < 700) {
						int outputVal = LOWORD(wParam) - 680; //get the combobox ID
						if (SendMessage(NodeInputTypeList[outputVal][6], CB_GETCURSEL, 0, 0) != 0) {
							EnableWindow(NodeInputTypeList[outputVal][1], FALSE); //Disable relevant windows
							EnableWindow(NodeInputTypeList[outputVal][2], FALSE);
						}
						else { //Enable them!
							EnableWindow(NodeInputTypeList[outputVal][1], TRUE);
							EnableWindow(NodeInputTypeList[outputVal][2], TRUE);
						}
					}
				}
			}
		}
		break;
		}
		switch (LOWORD(wParam)) {
		case IDCE_UPDATE_CONTROLS: //This is fired off whenever we are instructed to update the window!
		{
			int currentTab = SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0);
			if (currentTab < 0 || currentTab >= 3) { //prevent a defunct value being returned (mainly -1, but why not take some extra precuations?);
				currentTab = 0;
			}
			//Wipe out all the current windows controls
			DestroyWindow(NodeEditAddNewOutputButton);
			DestroyWindow(NodeEditAddNewInputButton);
			SendMessage(NodeEditTabControl, TCM_DELETEALLITEMS, 0, 0); //NUKE!
			for (int i = 0; i < NodeOutputTypeList.size(); i++) {
				for (int j = 0; j < NodeOutputTypeList[i].size(); j++) {
					DestroyWindow(NodeOutputTypeList[i][j]);
				}
			}
			for (int i = 0; i < NodeInputTypeList.size(); i++) {
				for (int j = 0; j < NodeInputTypeList[i].size(); j++) {
					DestroyWindow(NodeInputTypeList[i][j]);
				}
			}
			NodeOutputTypeList.clear(); //wipe the lists now we have cleared everything
			NodeInputTypeList.clear();
			//Resource node:
			if (nodeEditWindowMode == 0) {
				SetWindowPos(hWnd, NULL, 350, 100, 375, 470, SWP_NOMOVE); //Set the window to the required size (and ignore the specified position)
																		  //Insert the relevant tab controls
				TCITEM tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Outputs";
				tci.cchTextMax = 7;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 0, LPARAM(&tci));

				NodeEditAddNewOutputButton = CreateWindowEx(NULL, "BUTTON", "Add Output", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 130 + (NewForwardsConnectionsToAdd.size() - 1) * 60, 90, 22, hWnd, (HMENU)IDCE_ADD_OUTPUT, GetModuleHandle(NULL), NULL); //This button adds a new output row to the menu
				SendMessage(NodeEditAddNewOutputButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
				for (int i = 0; i < NewForwardsConnectionsToAdd.size(); i++) {
					HWND newOutputTypeSelector = CreateWindow("COMBOBOX", "Output", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 10, 70 + i * 60, 172, 100, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
					SendMessage(newOutputTypeSelector, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
					SendMessage(newOutputTypeSelector, CB_ADDSTRING, 0, (LPARAM)"NULL");
					SendMessage(newOutputTypeSelector, CB_SETCURSEL, 0, 0); //select element '0' (the NULL-resource)

					HWND MaxFlowRateBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", std::to_string(NewForwardsConnectionsToAdd[i].maxFlowRate).c_str(), WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 185, 70 + i * 60, 75, 21, hWnd, (HMENU)IDC_NODE_CREATE_NAME, GetModuleHandle(NULL), NULL);
					SendMessage(MaxFlowRateBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
					HWND FlowUnits = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 265, 70 + i * 60, 60, 220, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
					//Add the list of acceptable flow rate units into the units box
					for (int j = 0; j < FlowRateUnitsList.size(); j++) {
						SendMessage(FlowUnits, CB_ADDSTRING, 0, (LPARAM)FlowRateUnitsList[j].c_str());
					}
					//Now locate what units have been requested for this connection
					for (int j = 0; j < FlowRateUnitsList.size(); j++) {
						if (FlowRateUnitsList[j] == NewForwardsConnectionsToAdd[i].maxFlowRateUnits) { //if they match...
							SendMessage(FlowUnits, CB_SETCURSEL, j, 0); //default to that value!
							break; //don't bother continuing
						}
					}
					SendMessage(FlowUnits, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

					HWND ImportResourceButton = CreateWindowEx(NULL, "BUTTON", "Import Resource", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 95 + i * 60, 90, 22, hWnd, (HMENU)(620 + i), GetModuleHandle(NULL), NULL);
					HWND CreateResourceButton = CreateWindowEx(NULL, "BUTTON", "Create New", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 105, 95 + i * 60, 90, 22, hWnd, (HMENU)(640 + i), GetModuleHandle(NULL), NULL);
					HWND RemoveOutputButton = CreateWindowEx(NULL, "BUTTON", "Remove", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 200, 95 + i * 60, 90, 22, hWnd, (HMENU)(660 + i), GetModuleHandle(NULL), NULL);
					HWND DelimitMaxOutput = CreateWindowEx(NULL, "BUTTON", "Delim.", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 295, 96 + i * 60, 50, 20, hWnd, (HMENU)(680 + i), GetModuleHandle(NULL), NULL);
					SendMessage(DelimitMaxOutput, BM_SETCHECK, BOOL(NewForwardsConnectionsToAdd[i].isMaxFlowRateDelimited), 0); //Make sure the button defaults to whatever this connection has specified
					EnableWindow(MaxFlowRateBox, BOOL(!NewForwardsConnectionsToAdd[i].isMaxFlowRateDelimited)); //Disable (or enable) the relevant windows
					EnableWindow(FlowUnits, BOOL(!NewForwardsConnectionsToAdd[i].isMaxFlowRateDelimited));
					SendMessage(ImportResourceButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
					SendMessage(CreateResourceButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
					SendMessage(RemoveOutputButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
					SendMessage(DelimitMaxOutput, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

					std::array<HWND, 7> Win32ControlsArr = { newOutputTypeSelector, MaxFlowRateBox, FlowUnits, ImportResourceButton, CreateResourceButton, RemoveOutputButton, DelimitMaxOutput };
					NodeOutputTypeList.push_back(Win32ControlsArr);
				}
			}
			else if (nodeEditWindowMode == 1) { //Extractor node
				SetWindowPos(hWnd, NULL, 350, 100, 490, 470, SWP_NOMOVE); //Set the window to the required size
				//Insert the relevant tab controls
				TCITEM tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Inputs";
				tci.cchTextMax = 6;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 0, LPARAM(&tci));
				tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Extraction";
				tci.cchTextMax = 10;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 1, LPARAM(&tci));
				tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Outputs";
				tci.cchTextMax = 7;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 2, LPARAM(&tci));
				SendMessage(NodeEditTabControl, TCM_SETCURSEL, currentTab, 0);
				//Now deal with the tab-specific windows controls...
				if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 0) { //if we are on the "inputs" tab...
					NodeEditAddNewInputButton = CreateWindowEx(NULL, "BUTTON", "Add Input", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 130 + (NewBackwardsConnectionsToAdd.size() - 1) * 60, 90, 22, hWnd, (HMENU)IDCE_ADD_INPUT, GetModuleHandle(NULL), NULL); //This button adds a new output row to the menu
					SendMessage(NodeEditAddNewInputButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
					for (int i = 0; i < NewBackwardsConnectionsToAdd.size(); i++) {
						HWND newOutputTypeSelector = CreateWindow("COMBOBOX", "Input", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 30, 70 + i * 60, 172, 100, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
						SendMessage(newOutputTypeSelector, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
						SendMessage(newOutputTypeSelector, CB_ADDSTRING, 0, (LPARAM)"NULL");
						SendMessage(newOutputTypeSelector, CB_SETCURSEL, 0, 0); //select element '0' (the NULL-resource)

																				//Combobox to decide how the flow rate through this connection is defined
						HWND InputFlowMode = CreateWindow("COMBOBOX", "Flow mode", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 205, 70 + i * 60, 105, 220, hWnd, (HMENU)(680 + i), GetModuleHandle(NULL), NULL);
						SendMessage(InputFlowMode, CB_ADDSTRING, 0, (LPARAM)"Input Defined"); //mode 0
						SendMessage(InputFlowMode, CB_ADDSTRING, 1, (LPARAM)"Output Defined");
						SendMessage(InputFlowMode, CB_ADDSTRING, 2, (LPARAM)"Extract. Defined");
						SendMessage(InputFlowMode, CB_ADDSTRING, 3, (LPARAM)"Delimited"); //mode 3
						SendMessage(InputFlowMode, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
						SendMessage(InputFlowMode, CB_SETCURSEL, NewBackwardsConnectionsToAdd[i].flowRateMode, 0); //set to whatever the node has specified (defaults to 'output defined')

						HWND MaxFlowRateBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", std::to_string(NewBackwardsConnectionsToAdd[i].maxFlowRate).c_str(), WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 315, 70 + i * 60, 75, 21, hWnd, (HMENU)IDC_NODE_CREATE_NAME, GetModuleHandle(NULL), NULL);
						SendMessage(MaxFlowRateBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
						HWND FlowUnits = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 395, 70 + i * 60, 60, 220, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
						//Add the list of acceptable flow rate units into the units box
						for (int j = 0; j < FlowRateUnitsList.size(); j++) {
							SendMessage(FlowUnits, CB_ADDSTRING, 0, (LPARAM)FlowRateUnitsList[j].c_str());
						}
						//Now locate what units have been requested for this connection
						for (int j = 0; j < FlowRateUnitsList.size(); j++) {
							if (FlowRateUnitsList[j] == NewBackwardsConnectionsToAdd[i].maxFlowRateUnits) { //if they match...
								SendMessage(FlowUnits, CB_SETCURSEL, j, 0); //default to that value!
								break; //don't bother continuing
							}
						}
						SendMessage(FlowUnits, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

						//And now, if we are anything other than input defined, disable user editing of the flow rate boxes!
						if (SendMessage(InputFlowMode, CB_GETCURSEL, 0, 0) != 0) {
							EnableWindow(MaxFlowRateBox, FALSE); //Disable relevant windows
							EnableWindow(FlowUnits, FALSE);
						}
						else { //Enable them!
							EnableWindow(MaxFlowRateBox, TRUE);
							EnableWindow(FlowUnits, TRUE);
						}

						HWND ImportResourceButton = CreateWindowEx(NULL, "BUTTON", "Import Resource", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 30, 95 + i * 60, 90, 22, hWnd, (HMENU)(620 + i), GetModuleHandle(NULL), NULL);
						HWND CreateResourceButton = CreateWindowEx(NULL, "BUTTON", "Create New", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 125, 95 + i * 60, 90, 22, hWnd, (HMENU)(640 + i), GetModuleHandle(NULL), NULL);
						HWND RemoveInputButton = CreateWindowEx(NULL, "BUTTON", "Remove", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 220, 95 + i * 60, 90, 22, hWnd, (HMENU)(660 + i), GetModuleHandle(NULL), NULL);
						SendMessage(ImportResourceButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
						SendMessage(CreateResourceButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
						SendMessage(RemoveInputButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

						std::array<HWND, 7> Win32ControlsArr = { newOutputTypeSelector, MaxFlowRateBox, FlowUnits, ImportResourceButton, CreateResourceButton, RemoveInputButton, InputFlowMode };
						NodeInputTypeList.push_back(Win32ControlsArr);
					}
				}
				else if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 2) { //if we are on the "outputs" tab...
					NodeEditAddNewOutputButton = CreateWindowEx(NULL, "BUTTON", "Add Output", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 130 + (NewForwardsConnectionsToAdd.size() - 1) * 60, 90, 22, hWnd, (HMENU)IDCE_ADD_OUTPUT, GetModuleHandle(NULL), NULL); //This button adds a new output row to the menu
					SendMessage(NodeEditAddNewOutputButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
					for (int i = 0; i < NewForwardsConnectionsToAdd.size(); i++) {
						HWND newOutputTypeSelector = CreateWindow("COMBOBOX", "Output", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 10, 70 + i * 60, 172, 100, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
						SendMessage(newOutputTypeSelector, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
						SendMessage(newOutputTypeSelector, CB_ADDSTRING, 0, (LPARAM)"NULL");
						SendMessage(newOutputTypeSelector, CB_SETCURSEL, 0, 0); //select element '0' (the NULL-resource)

						HWND MaxFlowRateBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", std::to_string(NewForwardsConnectionsToAdd[i].maxFlowRate).c_str(), WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 185, 70 + i * 60, 75, 21, hWnd, (HMENU)IDC_NODE_CREATE_NAME, GetModuleHandle(NULL), NULL);
						SendMessage(MaxFlowRateBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
						HWND FlowUnits = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 265, 70 + i * 60, 60, 220, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
						//Add the list of acceptable flow rate units into the units box
						for (int j = 0; j < FlowRateUnitsList.size(); j++) {
							SendMessage(FlowUnits, CB_ADDSTRING, 0, (LPARAM)FlowRateUnitsList[j].c_str());
						}
						//Now locate what units have been requested for this connection
						for (int j = 0; j < FlowRateUnitsList.size(); j++) {
							if (FlowRateUnitsList[j] == NewForwardsConnectionsToAdd[i].maxFlowRateUnits) { //if they match...
								SendMessage(FlowUnits, CB_SETCURSEL, j, 0); //default to that value!
								break; //don't bother continuing
							}
						}
						SendMessage(FlowUnits, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

						HWND ImportResourceButton = CreateWindowEx(NULL, "BUTTON", "Import Resource", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 95 + i * 60, 90, 22, hWnd, (HMENU)(620 + i), GetModuleHandle(NULL), NULL);
						HWND CreateResourceButton = CreateWindowEx(NULL, "BUTTON", "Create New", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 105, 95 + i * 60, 90, 22, hWnd, (HMENU)(640 + i), GetModuleHandle(NULL), NULL);
						HWND RemoveOutputButton = CreateWindowEx(NULL, "BUTTON", "Remove", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 200, 95 + i * 60, 90, 22, hWnd, (HMENU)(660 + i), GetModuleHandle(NULL), NULL);
						HWND DelimitMaxOutput = CreateWindowEx(NULL, "BUTTON", "Delim.", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 295, 96 + i * 60, 50, 20, hWnd, (HMENU)(680 + i), GetModuleHandle(NULL), NULL);
						SendMessage(DelimitMaxOutput, BM_SETCHECK, BOOL(NewForwardsConnectionsToAdd[i].isMaxFlowRateDelimited), 0); //Make sure the button defaults to whatever this connection has specified
						EnableWindow(MaxFlowRateBox, BOOL(!NewForwardsConnectionsToAdd[i].isMaxFlowRateDelimited)); //Disable (or enable) the relevant windows
						EnableWindow(FlowUnits, BOOL(!NewForwardsConnectionsToAdd[i].isMaxFlowRateDelimited));
						SendMessage(ImportResourceButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
						SendMessage(CreateResourceButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
						SendMessage(RemoveOutputButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
						SendMessage(DelimitMaxOutput, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

						std::array<HWND, 7> Win32ControlsArr = { newOutputTypeSelector, MaxFlowRateBox, FlowUnits, ImportResourceButton, CreateResourceButton, RemoveOutputButton, DelimitMaxOutput };
						NodeOutputTypeList.push_back(Win32ControlsArr);
					}
				}
			}
			else if (nodeEditWindowMode == 2) { //Process node
												//Insert the relevant tab controls
				TCITEM tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Inputs";
				tci.cchTextMax = 6;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 0, LPARAM(&tci));
				tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Processes";
				tci.cchTextMax = 9;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 1, LPARAM(&tci));
				tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Outputs";
				tci.cchTextMax = 7;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 2, LPARAM(&tci));
			}
			else if (nodeEditWindowMode == 3) { //Consumer node
												//Insert the relevant tab controls
				TCITEM tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Inputs";
				tci.cchTextMax = 6;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 0, LPARAM(&tci));
				tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Consumers";
				tci.cchTextMax = 9;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 1, LPARAM(&tci));
				tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Waste";
				tci.cchTextMax = 5;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 2, LPARAM(&tci));
			}
			else if (nodeEditWindowMode == 4) { //Storage node
				HGDIOBJ hfDefault = GetStockObject(DEFAULT_GUI_FONT);
				//Insert the relevant tab controls
				TCITEM tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Inputs";
				tci.cchTextMax = 6;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 0, LPARAM(&tci));
				tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Storage";
				tci.cchTextMax = 7;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 1, LPARAM(&tci));
				tci = { 0 };
				tci.mask = TCIF_TEXT;
				tci.pszText = "Outputs";
				tci.cchTextMax = 7;
				SendMessage(NodeEditTabControl, TCM_INSERTITEM, 2, LPARAM(&tci));
			}
			RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE); //and refresh the window!
		}
		break;
		case IDCE_EDIT_CONNECTIONS: //Fired off whenever we want this window to be shown!
		{
			//How we want to reconfigure the window upon it being shown
			NewForwardsConnectionsToAdd.clear();
			NewBackwardsConnectionsToAdd.clear();
			//Copy across the current settings...
			NewForwardsConnectionsToAdd = ForwardsConnectionsToAdd;
			NewBackwardsConnectionsToAdd = BackwardsConnectionsToAdd;
			SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_CONTROLS, NULL); //Now update the window's controls!
			ShowWindow(hWnd, SW_SHOW); //and finally show the window!
		}
		break;
		/******************************************************************************************
		*	Messages for common operations we want to carry out
		*******************************************************************************************/
		case IDCE_UPDATE_BACKWARDS: //Apply the values in the windows controls to the array of backwards conections
		{
			if (nodeEditWindowMode == 0) {
				OutputDebugString("ERROR: Cannot update backwards connection win32 controls on a resource node!\n");
			}
			if (nodeEditWindowMode == 1) {
				if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 0) {
					for (int i = 0; i < NewBackwardsConnectionsToAdd.size(); i++) {
						//get the edit box text for the flow rate
						char data[32];
						GetWindowText(NodeInputTypeList[i][1], data, 32);
						NewBackwardsConnectionsToAdd[i].maxFlowRate = (float)atof(data);
						NewBackwardsConnectionsToAdd[i].maxFlowRateUnits = FlowRateUnitsList[SendMessage(NodeInputTypeList[i][2], CB_GETCURSEL, 0, 0)]; //get the combobox's current text, and assign use it to update the connection
						NewBackwardsConnectionsToAdd[i].flowRateMode = SendMessage(NodeInputTypeList[i][6], CB_GETCURSEL, 0, 0); //get the current index of the flow rate mode combobox.
					}
				}
			}
		}
		break;
		case IDCE_UPDATE_PROCESSES: //Apply the values in the windows controls to the array of processes
		{

		}
		break;
		case IDCE_UPDATE_FORWARDS: //Apply the values in the windows controls
		{
			if (nodeEditWindowMode == 0) {
				for (int i = 0; i < NewForwardsConnectionsToAdd.size(); i++) {
					//get the edit box text for the flow rate
					char data[32];
					GetWindowText(NodeOutputTypeList[i][1], data, 32);
					NewForwardsConnectionsToAdd[i].maxFlowRate = (float)atof(data);
					NewForwardsConnectionsToAdd[i].maxFlowRateUnits = FlowRateUnitsList[SendMessage(NodeOutputTypeList[i][2], CB_GETCURSEL, 0, 0)]; //get the combobox's current text, and assign use it to update the connection
				}
			}
			else if (nodeEditWindowMode == 1 && SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 2) {
				for (int i = 0; i < NewForwardsConnectionsToAdd.size(); i++) {
					//get the edit box text for the flow rate
					char data[32];
					GetWindowText(NodeOutputTypeList[i][1], data, 32);
					NewForwardsConnectionsToAdd[i].maxFlowRate = (float)atof(data);
					NewForwardsConnectionsToAdd[i].maxFlowRateUnits = FlowRateUnitsList[SendMessage(NodeOutputTypeList[i][2], CB_GETCURSEL, 0, 0)]; //get the combobox's current text, and assign use it to update the connection
				}
			}
		}
		break;
		/******************************************************************************************
		*	Dealing with the permanent buttons!
		*******************************************************************************************/
		case IDCE_ADD_OUTPUT:
		{
			if (nodeEditWindowMode == 0) { //Resource node
				if (NewForwardsConnectionsToAdd.size() < 20) { //If we haven't butted up against the (self-imposed) limit of connections we can add
															   //update all the connections to reflect the control's values
					SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_FORWARDS, 0);
					ConnectionPoint newConnectionPoint(0);
					NewForwardsConnectionsToAdd.push_back(newConnectionPoint);
					RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE); //and refresh window!
					SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_CONTROLS, NULL); //Now update the windows controls shown!
					RedrawWindow(NodeCreateWindowHandle, NULL, NULL, RDW_INVALIDATE); //and refresh the node creation window!
				}
				else {
					MessageBox(hWnd, "Cannot have more than 20 outputs in one node!", "Maximum connectivity reached!", MB_ICONERROR); //complain, loudly.
				}
			}
			else if (nodeEditWindowMode == 1) { //Extractor node
				if (NewForwardsConnectionsToAdd.size() < 20) { //If we haven't butted up against the (self-imposed) limit of connections we can add
															   //update all the connections to reflect the control's values
					SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_FORWARDS, 0);
					ConnectionPoint newConnectionPoint(0);
					NewForwardsConnectionsToAdd.push_back(newConnectionPoint);
					RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE); //and refresh window!
					SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_CONTROLS, NULL); //Now update the windows controls shown!
					RedrawWindow(NodeCreateWindowHandle, NULL, NULL, RDW_INVALIDATE); //and refresh the node creation window!
				}
				else {
					MessageBox(hWnd, "Cannot have more than 20 outputs in one node!", "Maximum connectivity reached!", MB_ICONERROR); //complain, loudly.
				}
			}
		}
		break;
		case IDCE_ADD_INPUT:
		{
			if (nodeEditWindowMode == 1) { //Extractor node. Resource nodes don't have inputs in case you haven't noticed yet... ;)
				if (NewBackwardsConnectionsToAdd.size() < 20) { //If we haven't butted up against the (self-imposed) limit of backwards connections we can add
																//update all the connections to reflect the control's values
					SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_BACKWARDS, 0);
					ConnectionPoint newConnectionPoint(0);
					NewBackwardsConnectionsToAdd.push_back(newConnectionPoint);
					RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE); //and refresh window!
					SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_CONTROLS, NULL); //Now update the windows controls shown!
					RedrawWindow(NodeCreateWindowHandle, NULL, NULL, RDW_INVALIDATE); //and refresh the node creation window!
				}
				else {
					MessageBox(hWnd, "Cannot have more than 20 outputs in one node!", "Maximum connectivity reached!", MB_ICONERROR); //complain, loudly.
				}
			}
		}
		break;
		case IDCE_APPLY_EDIT:
		{
			if (nodeEditWindowMode == 0) {
				//update all the connections to reflect the control's values
				SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_FORWARDS, 0);
			}
			else if (nodeEditWindowMode == 1) {
				//update all the connections to reflect the control's values
				SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_FORWARDS, 0);
				SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_BACKWARDS, 0);
			}
			//Copy across the new lists of connections
			ForwardsConnectionsToAdd = NewForwardsConnectionsToAdd;
			BackwardsConnectionsToAdd = NewBackwardsConnectionsToAdd;
			SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_CONTROLS, NULL); //Make doubly sure everything is updated as it should be
			RedrawWindow(NodeCreateWindowHandle, NULL, NULL, RDW_INVALIDATE); //and refresh the node creation window!
		}
		break;
		case IDCE_CANCEL_EDIT:
		{
			ShowWindow(hWnd, SW_HIDE);
			NewForwardsConnectionsToAdd.clear();
			NewBackwardsConnectionsToAdd.clear();
			RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE); //and refresh window!
			RedrawWindow(NodeCreateWindowHandle, NULL, NULL, RDW_INVALIDATE); //and refresh the node creation window!
		}
		break;
		case IDCE_FINISH_EDIT:
		{
			if (nodeEditWindowMode == 0) { //Resource node editing mode
										   //update all the connections to reflect the control's values
				SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_FORWARDS, 0);
			}
			else if (nodeEditWindowMode == 1) { //Extractor node editing mode
												//update all the connections to reflect the control's valuesz
				SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_FORWARDS, 0);
				SendMessage(hWnd, WM_COMMAND, IDCE_UPDATE_BACKWARDS, 0);
			}
			ShowWindow(hWnd, SW_HIDE);
			ForwardsConnectionsToAdd = NewForwardsConnectionsToAdd;
			BackwardsConnectionsToAdd = NewBackwardsConnectionsToAdd;
			RedrawWindow(NodeCreateWindowHandle, NULL, NULL, RDW_INVALIDATE); //and refresh the node creation window!
			RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE); //and refresh window!
			NewForwardsConnectionsToAdd.clear();
			NewBackwardsConnectionsToAdd.clear();
		}
		break;
		}
	}
	break;
	/******************************************************************************
	*	Drawing happens here!
	*******************************************************************************/
	case WM_PAINT:
	{
		hdc = BeginPaint(hWnd, &ps);
		HFONT hFont;
		HPEN hPen;
		HBRUSH hBrush;
		SetBkColor(hdc, RGB(255, 255, 255));
		RECT clientRect;
		HRGN bgRgn;
		GetClientRect(hWnd, &clientRect);
		win_width = clientRect.right - clientRect.left;
		win_height = clientRect.bottom - clientRect.top;
		bgRgn = CreateRectRgnIndirect(&clientRect);
		hBrush = CreateSolidBrush(RGB(255, 255, 255)); //colour it white
		FillRgn(hdc, bgRgn, hBrush); //draw to buffer
		if (nodeEditWindowMode == 0) { //If we have been instructed to edit resource nodes
									   //Title the box
			hFont = CreateFont(18, 0, 0, 0, FW_MEDIUM, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
			SelectObject(hdc, hFont);
			RECT textRect{ 0, 5, 360, 10 };
			DrawText(hdc, "Resource Node Editor", 20, &textRect, DT_CENTER | DT_NOCLIP);
			DeleteObject(hFont);

			//Now title each column
			hFont = CreateFont(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
			SelectObject(hdc, hFont);
			textRect = { 10, 52, 172, 65 };
			DrawText(hdc, "Output Resource", 15, &textRect, DT_LEFT | DT_NOCLIP);
			textRect = { 185, 52, 350, 65 };
			DrawText(hdc, "Max Output Rate", 20, &textRect, DT_LEFT | DT_NOCLIP);
			DeleteObject(hFont);

			for (int i = 0; i < NewForwardsConnectionsToAdd.size(); i++) { //draw forwards-facing arrows
				POINT pt[3];
				pt[0].x = (LONG)correctX(float(345));
				pt[0].y = (LONG)correctY(float(80 + i * 60));
				pt[1].x = (LONG)correctX(float(345 - 11));
				pt[1].y = (LONG)correctY(float(80 + i * 60 - 5));
				pt[2].x = (LONG)correctX(float(345 - 11));
				pt[2].y = (LONG)correctY(float(80 + i * 60 + 5));
				hPen = CreatePen(PS_SOLID, 1, RGB(0, 0, 0)); //give it a black outline
				hBrush = (HBRUSH)GetStockObject(HOLLOW_BRUSH); ///SelectObject(hdc, NULL);
															   //select the pen and brush
				SelectObject(hdc, hBrush);
				SelectObject(hdc, hPen);
				Polygon(hdc, pt, 3); //draw it!
									 //Now draw horizontal lines to rule off for the next output
				MoveToEx(hdc, 0, 122 + 60 * i, NULL);
				LineTo(hdc, 375, 122 + 60 * i);

				DeleteObject(hBrush);
				DeleteObject(hPen);
			}
			SetWindowPos(NodeEditAddNewOutputButton, NULL, 10, 130 + (NewForwardsConnectionsToAdd.size() - 1) * 60, 0, 0, SWP_NOSIZE); //Keep the "New output" button in the right place
		}
		else if (nodeEditWindowMode == 1) { //Extractor nodes
											//Title the window!
			hFont = CreateFont(18, 0, 0, 0, FW_MEDIUM, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
			SelectObject(hdc, hFont);
			RECT textRect{ 0, 5, 480, 10 };
			DrawText(hdc, "Extractor Node Editor", 21, &textRect, DT_CENTER | DT_NOCLIP);
			DeleteObject(hFont);

			if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 0) { //Backwards connections!
																			 //Now title each column
				hFont = CreateFont(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
				SelectObject(hdc, hFont);
				textRect = { 30, 52, 172, 65 };
				DrawText(hdc, "Input Resource", 14, &textRect, DT_LEFT | DT_NOCLIP);
				textRect = { 205, 52, 350, 65 };
				DrawText(hdc, "Flow mode", 9, &textRect, DT_LEFT | DT_NOCLIP);
				textRect = { 315, 52, 350, 65 };
				DrawText(hdc, "Required Input Rate", 19, &textRect, DT_LEFT | DT_NOCLIP);
				DeleteObject(hFont);

				for (int i = 0; i < NewBackwardsConnectionsToAdd.size(); i++) { //draw backwards-facing arrows
					POINT pt[3];
					pt[0].x = (LONG)correctX(float(8));
					pt[0].y = (LONG)correctY(float(80 + i * 60));
					pt[1].x = (LONG)correctX(float(8 + 11));
					pt[1].y = (LONG)correctY(float(80 + i * 60 - 5));
					pt[2].x = (LONG)correctX(float(8 + 11));
					pt[2].y = (LONG)correctY(float(80 + i * 60 + 5));
					hPen = CreatePen(PS_SOLID, 1, RGB(0, 0, 0)); //give it a black outline
					hBrush = (HBRUSH)GetStockObject(HOLLOW_BRUSH); //and no fill
																   //select the pen and brush
					SelectObject(hdc, hBrush);
					SelectObject(hdc, hPen);
					Polygon(hdc, pt, 3); //draw it!
										 //Now draw horizontal lines to rule off for the next output
					MoveToEx(hdc, 0, 122 + 60 * i, NULL);
					LineTo(hdc, 500, 122 + 60 * i);

					DeleteObject(hBrush);
					DeleteObject(hPen);
				}
				SetWindowPos(NodeEditAddNewOutputButton, NULL, 10, 130 + (NewForwardsConnectionsToAdd.size() - 1) * 60, 0, 0, SWP_NOSIZE); //Keep the "New output" button in the right place
			}
			else if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 1) { //"processes" tab

			}
			else if (SendMessage(NodeEditTabControl, TCM_GETCURSEL, 0, 0) == 2) { //"outputs" tab
																				  //Now title each column
				hFont = CreateFont(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
				SelectObject(hdc, hFont);
				textRect = { 10, 52, 172, 65 };
				DrawText(hdc, "Output Resource", 15, &textRect, DT_LEFT | DT_NOCLIP);
				textRect = { 185, 52, 350, 65 };
				DrawText(hdc, "Max Output Rate", 20, &textRect, DT_LEFT | DT_NOCLIP);
				DeleteObject(hFont);

				for (int i = 0; i < NewForwardsConnectionsToAdd.size(); i++) { //draw forwards-facing arrows
					POINT pt[3];
					pt[0].x = (LONG)correctX(float(345));
					pt[0].y = (LONG)correctY(float(80 + i * 60));
					pt[1].x = (LONG)correctX(float(345 - 11));
					pt[1].y = (LONG)correctY(float(80 + i * 60 - 5));
					pt[2].x = (LONG)correctX(float(345 - 11));
					pt[2].y = (LONG)correctY(float(80 + i * 60 + 5));
					hPen = CreatePen(PS_SOLID, 1, RGB(0, 0, 0)); //give it a black outline
					hBrush = (HBRUSH)GetStockObject(HOLLOW_BRUSH); ///SelectObject(hdc, NULL);
																   //select the pen and brush
					SelectObject(hdc, hBrush);
					SelectObject(hdc, hPen);
					Polygon(hdc, pt, 3); //draw it!
										 //Now draw horizontal lines to rule off for the next output
					MoveToEx(hdc, 0, 122 + 60 * i, NULL);
					LineTo(hdc, 400, 122 + 60 * i);

					DeleteObject(hBrush);
					DeleteObject(hPen);
				}
				SetWindowPos(NodeEditAddNewOutputButton, NULL, 10, 130 + (NewForwardsConnectionsToAdd.size() - 1) * 60, 0, 0, SWP_NOSIZE); //Keep the "New output" button in the right place
			}
		}
		else if (nodeEditWindowMode == 2) { //Process nodes
			//Title the window!
			hFont = CreateFont(18, 0, 0, 0, FW_MEDIUM, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
			SelectObject(hdc, hFont);
			RECT textRect{ 0, 5, 360, 10 };
			DrawText(hdc, "Process Node Editor", 19, &textRect, DT_CENTER | DT_NOCLIP);
			DeleteObject(hFont);
		}
		else if (nodeEditWindowMode == 3) { //Consumer nodes
			//Title the window!
			hFont = CreateFont(18, 0, 0, 0, FW_MEDIUM, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
			SelectObject(hdc, hFont);
			RECT textRect{ 0, 5, 360, 10 };
			DrawText(hdc, "Consumer Node Editor", 20, &textRect, DT_CENTER | DT_NOCLIP);
			DeleteObject(hFont);
		}
		else if (nodeEditWindowMode == 4) { //Storage nodes
			//Title the window!
			hFont = CreateFont(18, 0, 0, 0, FW_MEDIUM, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
			SelectObject(hdc, hFont);
			RECT textRect{ 0, 5, 360, 10 };
			DrawText(hdc, "Storage Node Editor", 19, &textRect, DT_CENTER | DT_NOCLIP);
			DeleteObject(hFont);
		}
		EndPaint(hWnd, &ps);
	}
	break;
	/******************************************************************************/
	case WM_CLOSE: //when the user requests the window to be closed...
		ShowWindow(hWnd, SW_HIDE); //We hide the window instead
		return 1;
	case WM_DESTROY: //but if they insist...
		//PostQuitMessage(0);
		return 1;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}
