/*********************************************************************************
*
*	Window main Process for the Resource Editor!
*
**********************************************************************************/

#include "stdafx.h"

LRESULT CALLBACK ResourceComponentCreationWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	HDC hdc;
	PAINTSTRUCT ps;
	HGDIOBJ hfDefault = GetStockObject(DEFAULT_GUI_FONT);
	switch (message) {
	case WM_CREATE:
	{
		//Text boxes
		// Create component name and description edit boxes
		ResourceComponentNameBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "New Component", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 55, 40, 295, 20, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		ResourceComponentDescBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "[Default]", WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL, 55, 65, 295, 50, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		HWND EditResourceChemistryButton = CreateWindowEx(NULL, "BUTTON", "Edit Chemistry", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 261, 300, 90, 22, hWnd, (HMENU)RCCW_EDIT_CHEMISTRY, GetModuleHandle(NULL), NULL); //This button adds a new output row to the menu
		SendMessage(ResourceComponentNameBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(ResourceComponentDescBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(EditResourceChemistryButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

		//Metadata boxes
		//Solid Density
		HWND DefSolidDensityCheckBox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 335, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(DefSolidDensityCheckBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		ResourceComponentSolidDensityBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "10.0", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 140, 330, 75, 21, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(ResourceComponentSolidDensityBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SolidDensityUnitsBox = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 220, 330, 70, 450, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(SolidDensityUnitsBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		//Add the list of acceptable flow rate units into the units box
		for (int j = 0; j < DensityUnitsList.size(); j++) {
			SendMessage(SolidDensityUnitsBox, CB_ADDSTRING, 0, (LPARAM)DensityUnitsList[j].c_str());
		}
		SendMessage(SolidDensityUnitsBox, CB_SETCURSEL, 6, 0); //select element '6' (g/cm3)

		//Liquid Density
		HWND DefLiquidDensityCheckBox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 365, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(DefLiquidDensityCheckBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		ResourceComponentLiquidDensityBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "10.0", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 140, 360, 75, 21, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(ResourceComponentLiquidDensityBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		LiquidDensityUnitsBox = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 220, 360, 70, 450, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(LiquidDensityUnitsBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		//Add the list of acceptable flow rate units into the units box
		for (int j = 0; j < DensityUnitsList.size(); j++) {
			SendMessage(LiquidDensityUnitsBox, CB_ADDSTRING, 0, (LPARAM)DensityUnitsList[j].c_str());
		}
		SendMessage(LiquidDensityUnitsBox, CB_SETCURSEL, 6, 0); //select element '6' (g/cm3)

		//Melting Point
		HWND DefMeltingPointCheckBox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 395, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(DefMeltingPointCheckBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		ResourceComponentMeltingPointBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "273.0", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 140, 390, 75, 21, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(ResourceComponentMeltingPointBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		MeltingPointUnitsBox = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 220, 390, 70, 450, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(MeltingPointUnitsBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		//Add the list of acceptable temperature units into the units box
		for (int j = 0; j < TemperatureUnitsList.size(); j++) {
			SendMessage(MeltingPointUnitsBox, CB_ADDSTRING, 0, (LPARAM)TemperatureUnitsList[j].c_str());
		}
		SendMessage(MeltingPointUnitsBox, CB_SETCURSEL, 0, 0); //select element '0' (Degrees Kelvin)

		//Boiling Point at 100kpa
		HWND DefBoilingPointCheckBox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 425, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(DefBoilingPointCheckBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		ResourceComponentBoilingPointBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "373.0", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 140, 420, 75, 21, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(ResourceComponentBoilingPointBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		BoilingPointUnitsBox = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 220, 420, 70, 450, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(BoilingPointUnitsBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		//Add the list of acceptable temperature units into the units box. (Faranheit is not acceptable, so choose it on pain of death)
		for (int j = 0; j < TemperatureUnitsList.size(); j++) {
			SendMessage(BoilingPointUnitsBox, CB_ADDSTRING, 0, (LPARAM)TemperatureUnitsList[j].c_str());
		}
		SendMessage(BoilingPointUnitsBox, CB_SETCURSEL, 0, 0); //select element '0' (Degrees Kelvin)

		//Percentage Abundance
		HWND DefPercentAbundanceCheckbox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 455, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(DefPercentAbundanceCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		ResourceComponentPercentAbundanceBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "0", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 140, 450, 75, 21, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(ResourceComponentPercentAbundanceBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		PercentAbundanceUnitsBox = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 220, 450, 70, 450, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(PercentAbundanceUnitsBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		//Add '%' as the only acceptable unit!
		SendMessage(PercentAbundanceUnitsBox, CB_ADDSTRING, 0, (LPARAM)"%");
		SendMessage(PercentAbundanceUnitsBox, CB_SETCURSEL, 0, 0); //select element '0' (%. It's the only option!)

		//Mass stored
		HWND DefMassStoredCheckbox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 485, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(DefMassStoredCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		ResourceComponentMassStoredBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "0", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 140, 480, 75, 21, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(ResourceComponentMassStoredBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		MassStoredUnitsBox = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 220, 480, 70, 450, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(MassStoredUnitsBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		//Add the list of acceptable mass units into the units box.
		for (int j = 0; j < MassUnitsList.size(); j++) {
			SendMessage(MassStoredUnitsBox, CB_ADDSTRING, 0, (LPARAM)MassUnitsList[j].c_str());
		}
		SendMessage(MassStoredUnitsBox, CB_SETCURSEL, 1, 0); //select element '1' (kg)

		//Volume stored
		HWND DefVolStoredCheckbox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 515, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(DefVolStoredCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		ResourceComponentVolStoredBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "0", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 140, 510, 75, 21, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(ResourceComponentVolStoredBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		VolStoredUnitsBox = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 220, 510, 70, 450, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(VolStoredUnitsBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		//Add the list of acceptable volume units into the units box.
		for (int j = 0; j < VolumeUnitsList.size(); j++) {
			SendMessage(VolStoredUnitsBox, CB_ADDSTRING, 0, (LPARAM)VolumeUnitsList[j].c_str());
		}
		SendMessage(VolStoredUnitsBox, CB_SETCURSEL, 1, 0); //select element '1' (m^3)

		//Temperature
		HWND DefTempCheckbox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 545, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(DefTempCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		ResourceComponentTempBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "0", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 140, 540, 75, 21, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(ResourceComponentTempBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		TemperatureUnitsBox = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 220, 540, 70, 450, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(TemperatureUnitsBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		//Add the list of acceptable temp units into the units box. (Degrees F is not acceptable)
		for (int j = 0; j < TemperatureUnitsList.size(); j++) {
			SendMessage(TemperatureUnitsBox, CB_ADDSTRING, 0, (LPARAM)TemperatureUnitsList[j].c_str());
		}
		SendMessage(TemperatureUnitsBox, CB_SETCURSEL, 0, 0); //select element '0' (Kelvin)

		//Thermal capacity
		HWND DefHeatCapacityCheckbox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 575, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(DefHeatCapacityCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		ResourceComponentHeatCapacityBox = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "0", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 140, 570, 75, 21, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(ResourceComponentHeatCapacityBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		HeatCapacityUnitsBox = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 220, 570, 70, 450, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
		SendMessage(HeatCapacityUnitsBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		//Add the list of acceptable temp units into the units box. (Degrees F is not acceptable)
		for (int j = 0; j < HeatCapacityUnitsList.size(); j++) {
			SendMessage(HeatCapacityUnitsBox, CB_ADDSTRING, 0, (LPARAM)HeatCapacityUnitsList[j].c_str());
		}
SendMessage(HeatCapacityUnitsBox, CB_SETCURSEL, 0, 0); //select element '0' (J/kg/K)

//state
HWND DefCurrentStateCheckbox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 605, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
SendMessage(DefCurrentStateCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
CurrentStateCombobox = CreateWindow("COMBOBOX", "Units", WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | CBS_HASSTRINGS, 140, 600, 70, 450, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
SendMessage(CurrentStateCombobox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
//add list of possible states
SendMessage(CurrentStateCombobox, CB_ADDSTRING, 0, (LPARAM)"Solid");
SendMessage(CurrentStateCombobox, CB_ADDSTRING, 1, (LPARAM)"Liquid");
SendMessage(CurrentStateCombobox, CB_ADDSTRING, 2, (LPARAM)"Gas");
SendMessage(CurrentStateCombobox, CB_SETCURSEL, 0, 0); //select element '0' (Solid)

//Dissolved?
HWND DefisDissolvedCheckbox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 635, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
SendMessage(DefisDissolvedCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
isDissolvedCheckbox = CreateWindowEx(NULL, "BUTTON", "Dissolved?", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 140, 635, 90, 14, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
SendMessage(isDissolvedCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

//Miscible?
HWND DefisMiscibleCheckbox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 665, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
SendMessage(DefisMiscibleCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
isMiscibleCheckbox = CreateWindowEx(NULL, "BUTTON", "Miscible?", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 140, 665, 90, 14, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
SendMessage(isMiscibleCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

//Radioactivity
HWND DefisRadioactiveCheckbox = CreateWindowEx(NULL, "BUTTON", "", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 100, 695, 12, 12, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
SendMessage(DefisRadioactiveCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
isRadioactiveCheckbox = CreateWindowEx(NULL, "BUTTON", "Radioactive?", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 140, 695, 90, 14, hWnd, (HMENU)NULL, GetModuleHandle(NULL), NULL);
SendMessage(isRadioactiveCheckbox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

NewComponentImportButton = CreateWindowEx(NULL, "BUTTON", "Import", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 5, 722, 85, 25, hWnd, (HMENU)RCCW_IMPORT_NEW_RESOURCE, GetModuleHandle(NULL), NULL);
NewComponentCreateButton = CreateWindowEx(NULL, "BUTTON", "Apply Changes", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 95, 722, 85, 25, hWnd, (HMENU)RCCW_APPLY_RESOURCE_CHANGES, GetModuleHandle(NULL), NULL);
NewComponentExportButton = CreateWindowEx(NULL, "BUTTON", "Export As New", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 185, 722, 85, 25, hWnd, (HMENU)RCCW_EXPORT_NEW_RESOURCE, GetModuleHandle(NULL), NULL);
NewComponentCancelButton = CreateWindowEx(NULL, "BUTTON", "Cancel", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 275, 722, 85, 25, hWnd, (HMENU)RCCW_CANCEL_NEW_RESOURCE, GetModuleHandle(NULL), NULL);

SendMessage(NewComponentImportButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
SendMessage(NewComponentCreateButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
SendMessage(NewComponentCancelButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
SendMessage(NewComponentExportButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
	}
	break;
	case WM_COMMAND:
	{
		switch (LOWORD(wParam)) {
		case RCCW_CREATE_NEW:
		{
			ShowWindow(hWnd, SW_SHOW);
		}
		break;
		//Button commands!
		case RCCW_EDIT_CHEMISTRY:
		{
			SendMessage(ChemicalFormulaCreationWindowHandle, WM_COMMAND, CSW_START_EDIT, 0);
		}
		break;
		case RCCW_IMPORT_NEW_RESOURCE:
		{
			//open a file dialog
			OPENFILENAME ofn;
			char szFileName[MAX_PATH] = "";

			ZeroMemory(&ofn, sizeof(ofn));

			ofn.lStructSize = sizeof(ofn);
			ofn.hwndOwner = hWnd;
			ofn.lpstrFilter = "Colony Simulator Resource Component (*.CSRC)\0*.CSRC*\0";
			ofn.lpstrFile = szFileName;
			ofn.nMaxFile = MAX_PATH;
			ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
			ofn.lpstrDefExt = "CSRC";

			if (GetOpenFileName(&ofn)) {
				std::ifstream inputFile;
				inputFile.open(szFileName, std::ios::in); //Open for input only
				if (inputFile.is_open()) { //And if it has been successfully opened...
					std::string line;
					std::vector<std::string> fileLines;
					while (std::getline(inputFile, line)) {
						fileLines.push_back(line);
					}
					//Load all the parameters
					ResourceComponent ThisComponent = LoadResourceComponentFromFile(fileLines);
					CurrentResourceComponentUniqueID = ThisComponent.uniqueID;
					inputFile.close();
					UpdateResourceComponentCreationWindowTextFields(ThisComponent);
				}
				else {
					//Complain. Loudly.
					MessageBox(hWnd, "Unable to open specified file! Is it open in another program?", "Could not open file", MB_ICONERROR);
					OutputDebugString("Error: Could not open file to save resource component in!\n");
				}
			}
		}
		break;
		case RCCW_APPLY_RESOURCE_CHANGES:
		{
			ResourceComponent ThisComponent = GetResourceComponentData();
			if (UpdateGlobalResourceComponentList(ThisComponent) == 1) {
				char* fileName[MAX_PATH];
				std::string file = applicationDirectory + "\\Resource Components\\Custom_" + ThisComponent.componentName + "_" + std::to_string(ThisComponent.uniqueID);
				*fileName = _strdup(file.c_str());
				if (SaveResourceComponent(*fileName)) {
					MessageBox(hWnd, "Resource Component has been added to the project, since it did not previously exist, and a new .CSRC file has been created!", "New Resource Component created", MB_ICONINFORMATION);
				}
				else {
					MessageBox(hWnd, "Resource Component has been added to the project, since it did not previously exist.\nHowever, due to an unkown error, no .CSRC file could be generated.", "New Resource Component created! But...", MB_ICONEXCLAMATION);
				}
			}
			ShowWindow(hWnd, SW_HIDE);
		}
		break;
		case RCCW_CANCEL_NEW_RESOURCE:
		{
			ShowWindow(hWnd, SW_HIDE);
		}
		break;
		case RCCW_EXPORT_NEW_RESOURCE:
		{
			//open a file dialog to determine where we're going to save this!
			OPENFILENAME ofn;
			char szFileName[MAX_PATH] = "";

			ZeroMemory(&ofn, sizeof(ofn));

			ofn.lStructSize = sizeof(ofn);
			ofn.hwndOwner = hWnd;
			ofn.lpstrFilter = "Colony Simulator Resource Component (*.CSRC)\0*.CSRC*\0";
			ofn.lpstrFile = szFileName;
			ofn.nMaxFile = MAX_PATH;
			ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
			ofn.lpstrDefExt = "CSRC";

			if (GetSaveFileName(&ofn)) {
				SaveResourceComponent(szFileName);
			}
		}
		break;
		}
	}
	break;
	case WM_PAINT:
	{
		hdc = BeginPaint(hWnd, &ps);
		HFONT hFont;
		HBRUSH hBrush;
		SetBkColor(hdc, RGB(255, 255, 255));
		RECT clientRect;
		HRGN bgRgn;
		GetClientRect(hWnd, &clientRect);
		win_width = clientRect.right - clientRect.left;
		win_height = clientRect.bottom - clientRect.top;
		bgRgn = CreateRectRgnIndirect(&clientRect);
		hBrush = CreateSolidBrush(RGB(255, 255, 255)); //colour it white
		FillRgn(hdc, bgRgn, hBrush); //draw to buffer

									 //add text GUI labels
		TextOut(hdc, 10, 40, "Name:", _tcslen("Name:"));
		TextOut(hdc, 10, 65, "Desc:", _tcslen("Desc:"));

		//Title the window
		hFont = CreateFont(18, 0, 0, 0, FW_MEDIUM, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		RECT textRect{ 0, 5, 360, 10 };
		DrawText(hdc, "Resource Component Editor", 25, &textRect, DT_CENTER | DT_NOCLIP);
		DeleteObject(hFont);

		//Title the chemical formula box
		hFont = CreateFont(16, 0, 0, 0, FW_MEDIUM, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		textRect = { 10, 115, 360, 10 };
		DrawText(hdc, "Chemistry:", 10, &textRect, DT_LEFT | DT_NOCLIP);
		DeleteObject(hFont);

		//Now title each column
		hFont = CreateFont(16, 0, 0, 0, FW_MEDIUM, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		textRect = { 5, 310, 20, 200 };
		DrawText(hdc, "Metric", 6, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 93, 310, 100, 200 };
		DrawText(hdc, "Def.?", 5, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 140, 310, 160, 220 };
		DrawText(hdc, "Value", 8, &textRect, DT_LEFT | DT_NOCLIP);
		DeleteObject(hFont);

		//Title each row
		hFont = CreateFont(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		textRect = { 5, 332, 60, 210 };
		DrawText(hdc, "Solid Density", 13, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 362, 60, 240 };
		DrawText(hdc, "Liquid Density", 14, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 392, 60, 270 };
		DrawText(hdc, "Melting Point", 13, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 422, 60, 300 };
		DrawText(hdc, "Boiling Point", 13, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 452, 60, 330 };
		DrawText(hdc, "% Abundance", 11, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 482, 60, 360 };
		DrawText(hdc, "Mass Stored", 11, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 512, 60, 390 };
		DrawText(hdc, "Vol Stored", 10, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 542, 60, 320 };
		DrawText(hdc, "Temperature", 11, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 572, 60, 350 };
		DrawText(hdc, "Heat Capacity", 13, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 602, 60, 350 };
		DrawText(hdc, "Current State", 13, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 632, 60, 350 };
		DrawText(hdc, "Dissolved?", 11, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 662, 60, 350 };
		DrawText(hdc, "Miscibility", 11, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 5, 692, 60, 350 };
		DrawText(hdc, "Radioactivity", 13, &textRect, DT_LEFT | DT_NOCLIP);
		DeleteObject(hFont);

		//Draw chemical structure
		hBrush = CreateSolidBrush(RGB(255, 255, 255));
		HPEN hPen = CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
		SelectObject(hdc, hBrush);
		SelectObject(hdc, hPen);
		Rectangle(hdc, 10, 135, 351, 296);
		DeleteObject(hBrush);
		DeleteObject(hPen);
		//Draw the render of the chemical structure!
		BitBlt(hdc, 10, 135, 340, 160, ChemicalStructureRender, 0, 0, SRCCOPY);

		EndPaint(hWnd, &ps);
	}
	break;
	case WM_CLOSE:
	{
		ShowWindow(hWnd, SW_HIDE);
		return 1;
	}
	break;
	case WM_DESTROY:
	{
		PostQuitMessage(0);
		return 1;
	}
	break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

/******************************************************************************
*	GetMetricFromCSRCfile()
*	Takes a string determining the metric(s) to look for. The string should
*	be of the form "Section::Section_n::metric.
*	e.g. Chemical_Components::Molecular_component_#3::IUPAC_Name will get the
*	parameter "IUPAC_name" from chemical component "Molecular_component_#3".
*	This will do wonders for back-compatability of files.
*******************************************************************************/
std::string GetMetricFromCSRCfile(std::vector<std::string> file, std::string metric) {
	std::string returnMetric = "";
	if (file.size() > 0 && metric != "") {
		std::vector<std::string> categories = splitString(metric, "::"); //Get the various categories specified
		for (u_int i = 0; i < file.size(); i++) {
			if (file[i] != "" && file[i].find(categories[0]) != std::string::npos) { //iterate until we find the parent category
				while (i < file.size()) { //and now search for the first open curly brace
					if (file[i] != "" && file[i].find_first_of('{') != std::string::npos) {
						break;
					}
					if (file[i] != "" && file[i].find_first_of('}') != std::string::npos) {
						OutputDebugString("ERROR: unexpected '}' character. Terminating search.\n");
						return "";
					}
					i++;
				}
				if (file[i] != "" && i < file.size()) {
					if (categories.size()-1 > 1) { //we have more than one layer to get through before we find the desired structure
						u_int layers = 0;
						while (i < file.size()) {
							if (file[i] != "" && file[i].find_first_of('{') != std::string::npos) {
								layers++;
								if (layers == categories.size() - 1 && file[i - 1].find(categories[layers-1]) != std::string::npos) { //if we have found the correct layer, and the right category exists...
									break;
								}
							}
							if (file[i] != "" && file[i].find_first_of('}') != std::string::npos) {
								layers--;
							}
							i++;
						}
						while (i < file.size()) { //Now lets try and find the right metric!
							if (i >= file.size()-1 && file[i] != "" && (file[i].find_first_of('{') != std::string::npos || file[i].find_first_of('}') != std::string::npos)) {
								OutputDebugString("ERROR: Could not locate requested metric! Aborting search.\n");
								return "";
							}
							else if (file[i].find(categories[categories.size() - 1]) != std::string::npos) {
								returnMetric = trimString(file[i]);
								break;
							}
							i++;
						}

					}
					else { //if only the one layer exists
						while (i < file.size() && file[i].find(categories[1]) == std::string::npos) {
							i++;
						}
						if (i < file.size() && file[i].find(categories[1]) != std::string::npos) { //we found it!
							returnMetric = trimString(file[i]);
						}
						else {
							OutputDebugString("ERROR: Specified index does not match requested metric! Terminating search for '");
							OutputDebugString(metric.c_str());
							OutputDebugString("'\n");
							return "";
						}
					}
				}
				else { //we have obviously failed to find anything...
					OutputDebugString("ERROR: Search index out of bounds, indicating item not found. Terminating search.\n");
					return "";
				}
				break;
			}
		}
	}
	else {
		OutputDebugString("ERROR: Parameters sent to function 'GetMetricFromCRSCfile' were empty and therefore invalid!\n");
	}
	return trimString(returnMetric);
}

int UpdateResourceComponentCreationWindowTextFields(ResourceComponent ThisComponent) {
	SetWindowText(ResourceComponentNameBox, ThisComponent.componentName.c_str());
	SetWindowText(ResourceComponentDescBox, ThisComponent.componentDesc.c_str());
	SetWindowText(ResourceComponentSolidDensityBox, std::to_string(ThisComponent.solidDensity).c_str());
	SetWindowText(ResourceComponentLiquidDensityBox, std::to_string(ThisComponent.liquidDensity).c_str());
	SetWindowText(ResourceComponentMeltingPointBox, std::to_string(ThisComponent.meltingPoint).c_str());
	SetWindowText(ResourceComponentBoilingPointBox, std::to_string(ThisComponent.boilingPoint).c_str());
	SetWindowText(ResourceComponentPercentAbundanceBox, std::to_string(ThisComponent.percentAbundance).c_str());
	SetWindowText(ResourceComponentMassStoredBox, std::to_string(ThisComponent.massStored).c_str());
	SetWindowText(ResourceComponentVolStoredBox, std::to_string(ThisComponent.volumeStored).c_str());
	SetWindowText(ResourceComponentTempBox, std::to_string(ThisComponent.temperature).c_str());
	SetWindowText(ResourceComponentHeatCapacityBox, std::to_string(ThisComponent.heatCapacity).c_str());
	return 0;
}

ResourceComponent LoadResourceComponentFromFile(std::vector<std::string> fileLines) {
	ResourceComponent ThisComponent;
	std::string metric = GetMetricFromCSRCfile(fileLines, "General::Name");
	if (metric != "") { //Check that it was actually found, and an empty string wasn't returned
		ThisComponent.componentName = trimString(metric.substr(metric.find("=") + 1, metric.size()));
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Description");
	if (metric != "") {
		ThisComponent.componentDesc = trimString(metric.substr(metric.find("=") + 1, metric.size()));
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Unique_ID");
	if (metric != "") {
		ThisComponent.uniqueID = atoll(trimString(metric.substr(metric.find("=") + 1, metric.size())).c_str());
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Solid_density ");
	if (metric != "") {
		metric = trimString(metric.substr(metric.find("=") + 1, metric.size()));
		ThisComponent.solidDensity = (float)atof(trimString(metric.substr(0, metric.find_last_of(" "))).c_str());
		ThisComponent.solidDensityUnits = trimString(metric.substr(metric.find_last_of(" "), metric.size()-1));
		int unitsIndex = SendMessage(SolidDensityUnitsBox, CB_FINDSTRINGEXACT, -1, (LPARAM)ThisComponent.solidDensityUnits.c_str());
		if (unitsIndex != CB_ERR) {
			SendMessage(SolidDensityUnitsBox, CB_SETCURSEL, unitsIndex, 0);
		}
		else {
			OutputDebugString("ERROR: Could not identify unit type in Resource Component Combobox.\n");
		}
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Liquid_density");
	if (metric != "") {
		ThisComponent.liquidDensity = (float)atof(trimString(metric.substr(metric.find("=") + 1, metric.size())).c_str());
		ThisComponent.liquidDensityUnits = trimString(metric.substr(metric.find_last_of(" "), metric.size() - 1));
		int unitsIndex = SendMessage(LiquidDensityUnitsBox, CB_FINDSTRINGEXACT, -1, (LPARAM)ThisComponent.liquidDensityUnits.c_str());
		if (unitsIndex != CB_ERR) {
			SendMessage(LiquidDensityUnitsBox, CB_SETCURSEL, unitsIndex, 0);
		}
		else {
			OutputDebugString("ERROR: Could not identify unit type in Resource Component Combobox.\n");
		}
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Melting_point");
	if (metric != "") {
		ThisComponent.meltingPoint = (float)atof(trimString(metric.substr(metric.find("=") + 1, metric.size())).c_str());
		ThisComponent.meltingPointUnits = trimString(metric.substr(metric.find_last_of(" "), metric.size() - 1));
		int unitsIndex = SendMessage(MeltingPointUnitsBox, CB_FINDSTRINGEXACT, -1, (LPARAM)ThisComponent.meltingPointUnits.c_str());
		if (unitsIndex != CB_ERR) {
			SendMessage(MeltingPointUnitsBox, CB_SETCURSEL, unitsIndex, 0);
		}
		else {
			OutputDebugString("ERROR: Could not identify unit type in Resource Component Combobox.\n");
		}
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Boiling_point");
	if (metric != "") {
		ThisComponent.boilingPoint = (float)atof(trimString(metric.substr(metric.find("=") + 1, metric.size())).c_str());
		ThisComponent.boilingPointUnits = trimString(metric.substr(metric.find_last_of(" "), metric.size() - 1));
		int unitsIndex = SendMessage(BoilingPointUnitsBox, CB_FINDSTRINGEXACT, -1, (LPARAM)ThisComponent.boilingPointUnits.c_str());
		if (unitsIndex != CB_ERR) {
			SendMessage(BoilingPointUnitsBox, CB_SETCURSEL, unitsIndex, 0);
		}
		else {
			OutputDebugString("ERROR: Could not identify unit type in Resource Component Combobox.\n");
		}
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Percent_abundance");
	if (metric != "") {
		ThisComponent.percentAbundance = (float)stof(trimString(metric.substr(metric.find("=") + 1, metric.size())));
		ThisComponent.percentAbundanceUnits = trimString(metric.substr(metric.find_last_of(" "), metric.size() - 1));
		int unitsIndex = SendMessage(PercentAbundanceUnitsBox, CB_FINDSTRINGEXACT, -1, (LPARAM)ThisComponent.percentAbundanceUnits.c_str()); //should always just be %, but hey!
		if (unitsIndex != CB_ERR) {
			SendMessage(PercentAbundanceUnitsBox, CB_SETCURSEL, unitsIndex, 0);
		}
		else {
			OutputDebugString("ERROR: Could not identify unit type in Resource Component Combobox.\n");
		}
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Mass_stored");
	if (metric != "") {
		ThisComponent.massStored = (float)stof(trimString(metric.substr(metric.find("=") + 1, metric.size())));
		ThisComponent.massStoredUnits = trimString(metric.substr(metric.find_last_of(" "), metric.size() - 1));
		int unitsIndex = SendMessage(MassStoredUnitsBox, CB_FINDSTRINGEXACT, -1, (LPARAM)ThisComponent.massStoredUnits.c_str());
		if (unitsIndex != CB_ERR) {
			SendMessage(MassStoredUnitsBox, CB_SETCURSEL, unitsIndex, 0);
		}
		else {
			OutputDebugString("ERROR: Could not identify unit type in Resource Component Combobox.\n");
		}
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Volume_stored");
	if (metric != "") {
		ThisComponent.volumeStored = (float)stof(trimString(metric.substr(metric.find("=") + 1, metric.size())));
		ThisComponent.volumeStoredUnits = trimString(metric.substr(metric.find_last_of(" "), metric.size() - 1));
		int unitsIndex = SendMessage(VolStoredUnitsBox, CB_FINDSTRINGEXACT, -1, (LPARAM)ThisComponent.volumeStoredUnits.c_str());
		if (unitsIndex != CB_ERR) {
			SendMessage(VolStoredUnitsBox, CB_SETCURSEL, unitsIndex, 0);
		}
		else {
			OutputDebugString("ERROR: Could not identify unit type in Resource Component Combobox.\n");
		}
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Temperature");
	if (metric != "") {
		ThisComponent.temperature = (float)stof(trimString(metric.substr(metric.find("=") + 1, metric.size())));
		ThisComponent.temperatureUnits = trimString(metric.substr(metric.find_last_of(" "), metric.size() - 1));
		int unitsIndex = SendMessage(TemperatureUnitsBox, CB_FINDSTRINGEXACT, -1, (LPARAM)ThisComponent.temperatureUnits.c_str());
		if (unitsIndex != CB_ERR) {
			SendMessage(TemperatureUnitsBox, CB_SETCURSEL, unitsIndex, 0);
		}
		else {
			OutputDebugString("ERROR: Could not identify unit type in Resource Component Combobox.\n");
		}
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Heat_capacity");
	if (metric != "") {
		ThisComponent.heatCapacity = (float)stof(trimString(metric.substr(metric.find("=") + 1, metric.size())));
		ThisComponent.heatCapacityUnits = trimString(metric.substr(metric.find_last_of(" "), metric.size() - 1));
		int unitsIndex = SendMessage(HeatCapacityUnitsBox, CB_FINDSTRINGEXACT, -1, (LPARAM)ThisComponent.heatCapacityUnits.c_str());
		if (unitsIndex != CB_ERR) {
			SendMessage(HeatCapacityUnitsBox, CB_SETCURSEL, unitsIndex, 0);
		}
		else {
			OutputDebugString("ERROR: Could not identify unit type in Resource Component Combobox.\n");
		}
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::State");
	if (metric != "") {
		ThisComponent.state = stoi(trimString(metric.substr(metric.find("=") + 1, metric.size())));
		SendMessage(CurrentStateCombobox, CB_SETCURSEL, (WPARAM)ThisComponent.state, 0);
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Mixable");
	if (metric != "") {
		ThisComponent.isMixable = stoi(trimString(metric.substr(metric.find("=") + 1, metric.size())));
		SendMessage(isMiscibleCheckbox, BM_SETCHECK, (WPARAM)ThisComponent.isMixable, 0);
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Dissolved");
	if (metric != "") {
		ThisComponent.isDissolved = stoi(trimString(metric.substr(metric.find("=") + 1, metric.size())));
		SendMessage(isDissolvedCheckbox, BM_SETCHECK, (WPARAM)ThisComponent.isDissolved, 0);
	}
	metric = GetMetricFromCSRCfile(fileLines, "General::Radioactivity");
	if (metric != "") {
		ThisComponent.isRadioactive = stoi(trimString(metric.substr(metric.find("=") + 1, metric.size())));
		SendMessage(isRadioactiveCheckbox, BM_SETCHECK, (WPARAM)ThisComponent.isRadioactive, 0);
	}
	return ThisComponent;
}

int SaveResourceComponent(char* szFileName) {
	std::ofstream outputFile;
	std::string checkName = szFileName;
	OutputDebugString(szFileName);
	OutputDebugString("\n");
	if (checkName.substr(0, checkName.find_last_of(".")-1).find(".CSRC") == std::string::npos) {
		checkName += ".CSRC";
		szFileName = _strdup(checkName.c_str());
		OutputDebugString("Added .CSRC file extension!\n");
		OutputDebugString(szFileName);
		OutputDebugString("\n");
	}
	outputFile.open(szFileName, std::ios::out);
	if (outputFile.is_open()) {
		ResourceComponent thisComponent = GetResourceComponentData(); //We shall store all our data in this
		thisComponent.createUniqueID();

		// current date/time based on current system
		time_t currentTime = time(NULL);
		struct tm *ltm = new tm;
		gmtime_s(ltm, &currentTime);
		std::string day = std::to_string(ltm->tm_mday);
		if (atoi(day.c_str()) < 10) {
			day = "0" + day;
		}
		std::string month = std::to_string(1 + ltm->tm_mon);
		if (atoi(month.c_str()) < 10) {
			month = "0" + month;
		}
		int year = 1900 + ltm->tm_year;
		std::string hours = std::to_string(ltm->tm_hour);
		if (atoi(hours.c_str()) < 10) {
			hours = "0" + hours;
		}
		std::string mins = std::to_string(ltm->tm_min);
		if (atoi(mins.c_str()) < 10) {
			mins = "0" + mins;
		}

		outputFile << "/*********************************************************************" << "\n";
		outputFile << "*" << "\n";
		outputFile << "*	Colony Simulator Resource Component File" << "\n";
		outputFile << "*	Name: " << thisComponent.componentName.c_str() << "\n";
		outputFile << "*	Author: " << "\n";
		outputFile << "*	Created: " << day << "/" << month << "/" << year << " at " << hours << ":" << mins << "UTC" << "\n";
		outputFile << "*	Last Modified: " << day << "/" << month << "/" << year << " at " << hours << ":" << mins << "UTC" << "\n";
		outputFile << "*" << "\n";
		outputFile << "**********************************************************************/" << "\n";
		outputFile << "\n";
		outputFile << "General\n";
		outputFile << "{\n";
		outputFile << "	Name = " << thisComponent.componentName << "\n";
		outputFile << "	Description = " << thisComponent.componentDesc << "\n";
		outputFile << "	Unique_ID = " << thisComponent.uniqueID << "\n";
		outputFile << "	Solid_density = " << thisComponent.solidDensity << " " << thisComponent.solidDensityUnits << "\n";
		outputFile << "	Liquid_density = " << thisComponent.liquidDensity << " " << thisComponent.liquidDensityUnits << "\n";
		outputFile << "	Melting_point = " << thisComponent.meltingPoint << " " << thisComponent.meltingPointUnits << "\n";
		outputFile << "	Boiling_point = " << thisComponent.boilingPoint << " " << thisComponent.boilingPointUnits << "\n";
		outputFile << "	Heat_capacity = " << thisComponent.heatCapacity << " " << thisComponent.heatCapacityUnits << "\n";
		outputFile << "	Percent_abundance = " << thisComponent.percentAbundance << " " << thisComponent.percentAbundanceUnits << "\n";
		outputFile << "	Mass_stored = " << thisComponent.massStored << " " << thisComponent.massStoredUnits << "\n";
		outputFile << "	Volume_stored = " << thisComponent.volumeStored << " " << thisComponent.volumeStoredUnits << "\n";
		outputFile << "	Temperature = " << thisComponent.temperature << " " << thisComponent.temperatureUnits << "\n";
		outputFile << "	State = " << thisComponent.state << "\n";
		outputFile << "	Mixable = " << thisComponent.isMixable << "\n";
		outputFile << "	Dissolved = " << thisComponent.isDissolved << "\n";
		outputFile << "	Radioactivity = " << thisComponent.isRadioactive << "\n";
		outputFile << "}\n";
		outputFile << "\n";
		outputFile << "Chemical_components\n";
		outputFile << "{\n";
		outputFile << "	Molecular_components = " << thisComponent.ComponentMolecules.size() << "\n";
		for (u_int i = 0; i < thisComponent.ComponentMolecules.size(); i++) {
			outputFile << "	Molecular_Component_#" << i << "\n";
			outputFile << "	{\n";
			outputFile << "		Chemical_Name = " << thisComponent.ComponentMolecules[i].chemicalName << "\n";
			outputFile << "		IUPAC_Name = " << thisComponent.ComponentMolecules[i].IUPACname << "\n";
			outputFile << "		Atomic_components = " << thisComponent.ComponentMolecules[i].atomicComponents.size() << "\n";
			outputFile << "		Component_atoms\n";
			outputFile << "		{\n";
			for (u_int j = 0; j < thisComponent.ComponentMolecules[i].atomicComponents.size(); j++) {
				outputFile << "			Atomic_Component\n";
				outputFile << "			{\n";
				outputFile << "				" << "Symbol = " << thisComponent.ComponentMolecules[i].atomicComponents[j].symbol << "\n";
				outputFile << "				" << "Proton_num = " << thisComponent.ComponentMolecules[i].atomicComponents[j].protonNumber << "\n";
				outputFile << "				" << "Neutron_num = " << thisComponent.ComponentMolecules[i].atomicComponents[j].neutronNumber << "\n";
				outputFile << "				" << "Electron_num = " << thisComponent.ComponentMolecules[i].atomicComponents[j].electronNumber << "\n";
				outputFile << "				" << "Number_of_atoms = " << thisComponent.ComponentMolecules[i].atomicComponents[j].number << "\n";
				outputFile << "			}\n";
			}
			outputFile << "		}\n";
			outputFile << "	}\n";
		}
		outputFile << "}\n";
	}
	else {
		MessageBox(NULL, "Unable to open file to save to this location or name!", "Could not save", MB_ICONERROR);
		OutputDebugString("Error: Could not open file to save resource component in!\n");
		outputFile.close();
		return 0;
	}
	outputFile.close();
	return 1;
}

ResourceComponent GetResourceComponentData() {
	ResourceComponent thisComponent;
	for (u_int i = 0; i < ChemicalStructureComponentCompound.size(); i++) {
		ChemicalComponent NewComponent;
		NewComponent.atomicComponents = ChemicalStructureComponentCompound[i].atomList;
		thisComponent.ComponentMolecules.push_back(NewComponent);
	}
	//begin getting all our entered data out of the text fields
	char data[32];
	GetWindowText(ResourceComponentNameBox, data, 32);
	thisComponent.componentName = data;

	if (CurrentResourceComponentUniqueID == 0) {
		CurrentResourceComponentUniqueID = thisComponent.createUniqueID();
	}
	thisComponent.uniqueID = CurrentResourceComponentUniqueID;

	GetWindowText(ResourceComponentDescBox, data, 32);
	thisComponent.componentDesc = data;

	GetWindowText(ResourceComponentSolidDensityBox, data, 32);
	thisComponent.solidDensity = (float)atof(data);
	GetWindowText(SolidDensityUnitsBox, data, 32);
	thisComponent.solidDensityUnits = data;

	GetWindowText(ResourceComponentLiquidDensityBox, data, 32);
	thisComponent.liquidDensity = (float)atof(data);
	GetWindowText(LiquidDensityUnitsBox, data, 32);
	thisComponent.liquidDensityUnits = data;

	GetWindowText(ResourceComponentMeltingPointBox, data, 32);
	thisComponent.meltingPoint = (float)atof(data);
	GetWindowText(MeltingPointUnitsBox, data, 32);
	thisComponent.meltingPointUnits = data;

	GetWindowText(ResourceComponentBoilingPointBox, data, 32);
	thisComponent.boilingPoint = (float)atof(data);
	GetWindowText(BoilingPointUnitsBox, data, 32);
	thisComponent.boilingPointUnits = data;

	GetWindowText(ResourceComponentPercentAbundanceBox, data, 32);
	thisComponent.percentAbundance = (float)atof(data);
	GetWindowText(PercentAbundanceUnitsBox, data, 32);
	thisComponent.percentAbundanceUnits = data;

	GetWindowText(ResourceComponentMassStoredBox, data, 32);
	thisComponent.massStored = (float)atof(data);
	GetWindowText(MassStoredUnitsBox, data, 32);
	thisComponent.massStoredUnits = data;

	GetWindowText(ResourceComponentVolStoredBox, data, 32);
	thisComponent.volumeStored = (float)atof(data);
	GetWindowText(VolStoredUnitsBox, data, 32);
	thisComponent.volumeStoredUnits = data;

	GetWindowText(ResourceComponentTempBox, data, 32);
	thisComponent.temperature = (float)atof(data);
	GetWindowText(TemperatureUnitsBox, data, 32);
	thisComponent.temperatureUnits = data;

	GetWindowText(ResourceComponentHeatCapacityBox, data, 32);
	thisComponent.heatCapacity = (float)atof(data);
	GetWindowText(HeatCapacityUnitsBox, data, 32);
	thisComponent.heatCapacityUnits = data;

	thisComponent.state = SendMessage(CurrentStateCombobox, CB_GETCURSEL, 0, 0);
	thisComponent.isDissolved = (SendMessage(isDissolvedCheckbox, BM_GETCHECK, 0, 0) == BST_CHECKED);
	thisComponent.isMixable = (SendMessage(isMiscibleCheckbox, BM_GETCHECK, 0, 0) == BST_CHECKED);
	thisComponent.isRadioactive = (SendMessage(isRadioactiveCheckbox, BM_GETCHECK, 0, 0) == BST_CHECKED);
	
	return thisComponent;
}