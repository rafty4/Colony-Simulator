
/*********************************************************************************
*
*	Main window process for the Structural Chemistry window!
*
**********************************************************************************/

#include "stdafx.h"

LRESULT CALLBACK ChemicalFormulaCreationWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	HDC hdc;
	PAINTSTRUCT ps;
	HGDIOBJ hfDefault = GetStockObject(DEFAULT_GUI_FONT);
	switch (message) {
	case WM_CREATE:
	{
		//Main control buttons
		HWND FinishEditButton = CreateWindowEx(NULL, "BUTTON", "Finish", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 55, 230, 100, 25, hWnd, (HMENU)CSW_FINISH_EDIT, GetModuleHandle(NULL), NULL);
		HWND ApplyEditButton = CreateWindowEx(NULL, "BUTTON", "Apply", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 165, 230, 100, 25, hWnd, (HMENU)CSW_APPLY_EDIT, GetModuleHandle(NULL), NULL);
		HWND CancelEditButton = CreateWindowEx(NULL, "BUTTON", "Cancel", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 275, 230, 100, 25, hWnd, (HMENU)CSW_CANCEL_EDIT, GetModuleHandle(NULL), NULL);
		SendMessage(FinishEditButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(ApplyEditButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(CancelEditButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

		//New chemical compound text box
		NewCompoundEditBox = CreateWindowEx(0, "EDIT", "", WS_BORDER | WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_AUTOVSCROLL | ES_MULTILINE | ES_LEFT | ES_WANTRETURN, 107, 200, 148, 20, hWnd, NULL, NULL, NULL);
		SendMessage(NewCompoundEditBox, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		EnableWindow(NewCompoundEditBox, FALSE); //and disable the edit box!
		//New Chemical compound add new elements button
		HWND EditNewCompoundButton = CreateWindowEx(NULL, "BUTTON", "Edit", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 260, 200, 55, 20, hWnd, (HMENU)CSW_EDIT_NEW_COMPONENT, GetModuleHandle(NULL), NULL);
		HWND AddNewCompoundButton = CreateWindowEx(NULL, "BUTTON", "Add", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 320, 200, 55, 20, hWnd, (HMENU)CSW_ADD_NEW_COMPONENT, GetModuleHandle(NULL), NULL);
		SendMessage(EditNewCompoundButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(AddNewCompoundButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
	}
	break;
	case WM_COMMAND:
	{
		switch (LOWORD(wParam)) {
		case CSW_START_EDIT:
		{
			ShowWindow(hWnd, SW_SHOW);
		}
		break;
		case CSW_UPDATE_STRUCTURE_EDITBOX:
		{
			std::string chemicalComponentString = "";
			ChemicalFormulaComponentCharge = PeriodicTableChemicalComponentCharge;
			ChemistryCreationComponentList = PeriodicTableChemicalComponentList; //Copy the lists before they get nuked by the other window!
			if (ChemicalFormulaComponentCharge != 0) {
				chemicalComponentString = "["; //put somebrackets around it to denote an ion
			}
			for (u_int i = 0; i < PeriodicTableChemicalComponentList.size(); i++) {
				chemicalComponentString += PeriodicTableChemicalComponentList[i].symbol;
				if (PeriodicTableChemicalComponentList[i].number > 1) {
					chemicalComponentString += std::to_string(int(PeriodicTableChemicalComponentList[i].number));
				}
			}
			if (ChemicalFormulaComponentCharge != 0) {
				chemicalComponentString += "]";  // close the bracket
				if (abs(ChemicalFormulaComponentCharge) > 1) {
					chemicalComponentString += std::to_string(abs(ChemicalFormulaComponentCharge));
				}
				if (ChemicalFormulaComponentCharge > 0) { //and then add a sign
					chemicalComponentString += "+";
				}
				else {
					chemicalComponentString += "-";
				}
			}
			SendMessage(NewCompoundEditBox, WM_SETTEXT, 0, (LPARAM)chemicalComponentString.c_str());
		}
		break;
		//Buttons!
		case CSW_EDIT_NEW_COMPONENT:
		{
			//Copy the list across to the other window. We did hit 'Edit' after all!
			PeriodicTableChemicalComponentCharge = ChemicalFormulaComponentCharge;
			PeriodicTableChemicalComponentList = ChemistryCreationComponentList;
			SendMessage(PeriodicTableWindowHandle, WM_COMMAND, PTW_SHOW, 0);
		}
		break;
		case CSW_ADD_NEW_COMPONENT:
		{
			if (ChemistryCreationComponentList.size() > 0) {
				char formula[64];
				GetWindowText(NewCompoundEditBox, formula, 64 - 1);
				MolecularComponent newComponent = MolecularComponent(formula, ChemistryCreationComponentList, ChemicalFormulaComponentCharge);
				ChemicalStructureComponentCompound.push_back(newComponent);
				InvalidateRect(ChemicalFormulaCreationWindowHandle, NULL, FALSE); //update the window to show the component
			}
		}
		break;
		case CSW_FINISH_EDIT:
		{
			ChemicalStructureRender = GetDC(ChemicalStructureWindowHandle); //update the render!
			InvalidateRect(ResourceComponentCreationWindowHandle, NULL, TRUE);
			ShowWindow(hWnd, SW_HIDE);
		}
		break;
		case CSW_APPLY_EDIT:
		{
			ChemicalStructureRender = GetDC(ChemicalStructureWindowHandle); //update the render!
			InvalidateRect(ResourceComponentCreationWindowHandle, NULL, TRUE);
		}
		break;
		case CSW_CANCEL_EDIT:
		{
			ShowWindow(hWnd, SW_HIDE);
		}
		break;
		}
	}
	break;
	case WM_PAINT:
	{
		hdc = BeginPaint(hWnd, &ps);
		HFONT hFont;
		HBRUSH hBrush;
		SetBkColor(hdc, RGB(255, 255, 255));
		RECT clientRect;
		HRGN bgRgn;
		GetClientRect(hWnd, &clientRect);
		win_width = clientRect.right - clientRect.left;
		win_height = clientRect.bottom - clientRect.top;
		bgRgn = CreateRectRgnIndirect(&clientRect);
		hBrush = CreateSolidBrush(RGB(255, 255, 255)); //colour it white
		FillRgn(hdc, bgRgn, hBrush); //draw to buffer
		DeleteObject(hBrush);

		hFont = CreateFont(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		RECT textRect = { 10, 202, 60, 210 };
		DrawText(hdc, "New Component:", 14, &textRect, DT_LEFT | DT_NOCLIP);
		DeleteObject(hFont);

		EndPaint(hWnd, &ps);
	}
	break;
	case WM_CLOSE:
	{
		ShowWindow(hWnd, SW_HIDE);
		return 1;
	}
	break;
	case WM_DESTROY:
	{
		PostQuitMessage(0);
		return 1;
	}
	break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

/*********************************************************************************
*
*	Embedded Child window process for the structural chemistry window
*
**********************************************************************************/

LRESULT CALLBACK ChemicalStructureWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	HDC hdc;
	PAINTSTRUCT ps;
	HGDIOBJ hfDefault = GetStockObject(DEFAULT_GUI_FONT);
	POINT mousePos;
	GetCursorPos(&mousePos);
	ScreenToClient(hWnd, &mousePos);
	int thisMouseX = (int)mousePos.x;
	int thisMouseY = (int)mousePos.y;
	switch (message) {
	case WM_CREATE:
	{
	}
	break;
	case WM_COMMAND:
	{
		switch (LOWORD(wParam)) {
		case RCM_EDIT_CHEMICAL_COMPONENT:
		{
			if (selectedChemicalStructureComponent >= 0 && selectedChemicalStructureComponent < ChemicalStructureComponentCompound.size()) {
				//Copy the list across to the other window. We did hit 'Edit' after all!
				PeriodicTableChemicalComponentCharge = ChemicalStructureComponentCompound[selectedChemicalStructureComponent].netCharge;
				PeriodicTableChemicalComponentList = ChemicalStructureComponentCompound[selectedChemicalStructureComponent].atomList;
				SendMessage(PeriodicTableWindowHandle, WM_COMMAND, PTW_SHOW, 0); //and show the periodic table window!
			}
			else {
				OutputDebugString("Error: Chemical component selected for RCM Editing did not have a valid index!\n");
			}
			selectedChemicalStructureComponent = -1;
		}
		break;
		case RCM_DUP_CHEMICAL_COMPONENT:
		{
			if (selectedChemicalStructureComponent >= 0 && selectedChemicalStructureComponent < ChemicalStructureComponentCompound.size()) {
				MolecularComponent newComponent = ChemicalStructureComponentCompound[selectedChemicalStructureComponent];
				newComponent.xpos = 20;
				newComponent.ypos = 20;
				ChemicalStructureComponentCompound.push_back(newComponent);
			}
			else {
				OutputDebugString("Error: Chemical component selected for RCM duplication did not have a valid index!\n");
			}
			selectedChemicalStructureComponent = -1;
		}
		break;
		case RCM_DELETE_CHEMICAL_COMPONENT:
		{
			if (selectedChemicalStructureComponent >= 0 && selectedChemicalStructureComponent < ChemicalStructureComponentCompound.size()) {
				ChemicalStructureComponentCompound.erase(ChemicalStructureComponentCompound.begin() + selectedChemicalStructureComponent);
			}
			else {
				OutputDebugString("Error: Chemical component selected for RCM deletion did not have a valid index!\n");
			}
			selectedChemicalStructureComponent = -1;
		}
		break;
		case RCM_TOGGLE_COMPONENT_BORDER:
		{
			if (selectedChemicalStructureComponent >= 0 && selectedChemicalStructureComponent < ChemicalStructureComponentCompound.size()) {
				ChemicalStructureComponentCompound[selectedChemicalStructureComponent].drawBoundingRect = !ChemicalStructureComponentCompound[selectedChemicalStructureComponent].drawBoundingRect; //invert it!
			}
			else {
				OutputDebugString("Error: Chemical component selected for RCM border toggle did not have a valid index!\n");
			}
			selectedChemicalStructureComponent = -1;
		}
		break;
		}
	}
	break;
	case WM_LBUTTONDOWN:
	{
		chemicalStructureWindowMousePressed = true;
		//select the first component the mouse is over
		for (int i = ChemicalStructureComponentCompound.size() - 1; i >= 0; i--) { //we want to go backwards so we select the component at the top of the draw order
			if (ChemicalStructureComponentCompound[i].isMouseOverComponent(thisMouseX, thisMouseY)) {
				ChemicalStructureComponentCompound[i].isMovable = true;
				break;
			}
		}
	}
	break;
	case WM_LBUTTONUP:
	{
		chemicalStructureWindowMousePressed = false;
		//make sure all the components are deselected
		for (u_int i = 0; i < ChemicalStructureComponentCompound.size(); i++) {
			ChemicalStructureComponentCompound[i].isMovable = false;
		}
	}
	break;
	case WM_RBUTTONUP:
	{
		HMENU hMenu = CreatePopupMenu();
		HMENU hSubMenu = CreatePopupMenu();
		selectedChemicalStructureComponent = -1;
		for (int i = ChemicalStructureComponentCompound.size() - 1; i >= 0; i--) { //Get the top of the draw order!
			if (!ChemicalStructureComponentCompound[i].isMovable) {
				if (ChemicalStructureComponentCompound[i].isMouseOverComponent(thisMouseX, thisMouseY)) {
					InsertMenu(hMenu, 0, MF_BYPOSITION | MF_STRING, RCM_EDIT_CHEMICAL_COMPONENT, "Edit");
					InsertMenu(hMenu, 1, MF_BYPOSITION | MF_STRING, RCM_DUP_CHEMICAL_COMPONENT, "Duplicate");
					InsertMenu(hMenu, 2, MF_BYPOSITION | MF_STRING, RCM_DELETE_CHEMICAL_COMPONENT, "Delete");
					InsertMenu(hMenu, 3, MF_BYPOSITION | MF_STRING, RCM_TOGGLE_COMPONENT_BORDER, "Toggle Border");
					selectedChemicalStructureComponent = i;
					break;
				}
			}
		}
		GetCursorPos(&mousePos);
		TrackPopupMenu(hMenu, TPM_TOPALIGN | TPM_LEFTALIGN, (int)mousePos.x, (int)mousePos.y, 0, hWnd, NULL);
		DeleteMenu(hMenu, NULL, NULL);
		DeleteMenu(hSubMenu, NULL, NULL);
	}
	break;
	case WM_PAINT:
	{
		RECT rect;
		HDC hdcMem;
		HBITMAP hbmMem;
		HANDLE hOld;
		HBRUSH hBrush;
		GetWindowRect(hWnd, &rect);
		win_width = rect.right - rect.left;
		win_height = rect.bottom - rect.top;

		hdc = BeginPaint(hWnd, &ps);

		// Create an off-screen DC for double-buffering
		hdcMem = CreateCompatibleDC(hdc);
		hbmMem = CreateCompatibleBitmap(hdc, win_width, win_height);

		hOld = SelectObject(hdcMem, hbmMem);

		/*************************************************************************************
		*
		*	Drawing code called here!
		*
		**************************************************************************************/

		// Fill the client area with a brush
		HRGN bgRgn;
		GetClientRect(hWnd, &rect);
		win_width = rect.right - rect.left;
		win_height = rect.bottom - rect.top;
		bgRgn = CreateRectRgnIndirect(&rect);
		hBrush = CreateSolidBrush(RGB(255, 255, 255)); //colour it white
		FillRgn(hdcMem, bgRgn, hBrush); //draw to buffer
		DeleteObject(hBrush);
		SetBkMode(hdcMem, TRANSPARENT);  //Make sure text has a transparent background

		for (u_int i = 0; i < ChemicalStructureComponentCompound.size(); i++) {
			if (chemicalStructureWindowMousePressed) {
				if (ChemicalStructureComponentCompound[i].isMovable && ChemicalStructureComponentCompound[i].isMouseOverComponent(thisMouseX, thisMouseY)) {
					ChemicalStructureComponentCompound[i].xpos = thisMouseX - 10;
					ChemicalStructureComponentCompound[i].ypos = thisMouseY - 10;
				}
			}
			ChemicalStructureComponentCompound[i].draw(hdcMem);
		}

		//Swap buffers
		BitBlt(hdc, 0, 0, win_width, win_height, hdcMem, 0, 0, SRCCOPY);

		//Free-up the off-screen buffer
		SelectObject(hdcMem, hOld);
		DeleteObject(hbmMem);
		DeleteDC(hdcMem);

		SelectObject(hdc, NULL);

		EndPaint(hWnd, &ps);
		InvalidateRect(hWnd, NULL, FALSE); //make sure the screen is continually updated!
	}
	break;
	case WM_DESTROY:
	{
		PostQuitMessage(0);
		return 1;
	}
	break;
	}
	InvalidateRect(hWnd, NULL, FALSE);
	return DefWindowProc(hWnd, message, wParam, lParam);
}

/*********************************************************************************
*
*	Main window process for the Periodic table window
*
**********************************************************************************/
LRESULT CALLBACK PeriodicTableWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	HDC hdc;
	PAINTSTRUCT ps;
	HGDIOBJ hfDefault = GetStockObject(DEFAULT_GUI_FONT);
	POINT PeriodicTableWindowCursorPos;
	GetCursorPos(&PeriodicTableWindowCursorPos);
	ScreenToClient(hWnd, &PeriodicTableWindowCursorPos);
	int periodicTableMouseX = (int)PeriodicTableWindowCursorPos.x;
	int periodicTableMouseY = (int)PeriodicTableWindowCursorPos.y;
	switch (message) {
	case WM_CREATE:
	{
		//add a button for each table element!
		for (u_int i = 0; i < PeriodicTable.size(); i++) {
			HWND newElementButton = CreateWindowEx(NULL, "BUTTON", PeriodicTable[i].symbol.c_str(), WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_FLAT, PeriodicTable[i].periodicTablePos[0] * 30, PeriodicTable[i].periodicTablePos[1] * 30, 30, 30, hWnd, (HMENU)(PTW_ELEMENT_BUTTON + i), GetModuleHandle(NULL), NULL);
			SendMessage(newElementButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		}
		//And now make the controls to control chemical component creation!
		NumberOfAtomsToAddEditBoxHandle = CreateWindowEx(0, "EDIT", "1", WS_BORDER | WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_AUTOVSCROLL | ES_LEFT | ES_NUMBER, 150, 245, 50, 20, hWnd, (HMENU)NULL, NULL, NULL);
		TotalChargeEditBoxHandle = CreateWindowEx(0, "EDIT", "0", WS_BORDER | WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_AUTOVSCROLL | ES_LEFT | ES_NUMBER, 150, 275, 30, 20, hWnd, (HMENU)PTW_TOTAL_CHARGE_EDITBOX, NULL, NULL);
		TogglePosOrNegComponentCharge = CreateWindowEx(NULL, "BUTTON", "Toggle Polarity", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 185, 275, 90, 20, hWnd, (HMENU)PTW_TOGGLE_TOTAL_CHARGE, GetModuleHandle(NULL), NULL);
		HWND FinishComponentButton = CreateWindowEx(NULL, "BUTTON", "Finish", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 10, 340, 100, 25, hWnd, (HMENU)PTW_FINISH_COMPONENT, GetModuleHandle(NULL), NULL);
		HWND ApplyComponentButton = CreateWindowEx(NULL, "BUTTON", "Apply", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 120, 340, 100, 25, hWnd, (HMENU)PTW_APPLY_COMPONENT, GetModuleHandle(NULL), NULL);
		HWND CancelEditButton = CreateWindowEx(NULL, "BUTTON", "Cancel", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 230, 340, 100, 25, hWnd, (HMENU)PTW_CANCEL_COMPONENT, GetModuleHandle(NULL), NULL);
		SendMessage(NumberOfAtomsToAddEditBoxHandle, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(TotalChargeEditBoxHandle, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(TogglePosOrNegComponentCharge, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(FinishComponentButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(ApplyComponentButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));
		SendMessage(CancelEditButton, WM_SETFONT, (WPARAM)hfDefault, MAKELPARAM(FALSE, 0));

	}
	case WM_COMMAND:
	{
		//If one of those element buttons has been pressed (by a supremely inelegant solution...)
		if ((LOWORD(wParam) >= PTW_ELEMENT_BUTTON) && LOWORD(wParam) < PTW_ELEMENT_BUTTON + 150) {
			PeriodicTableChemicalComponentList.push_back(PeriodicTable[LOWORD(wParam) - 1100]); //stick it onto the end of the list!
			char data[32];
			GetWindowText(NumberOfAtomsToAddEditBoxHandle, data, 32);
			int numberOfAtoms = atoi(data);
			if (numberOfAtoms < 1) {
				numberOfAtoms = 1;
				SendMessage(NumberOfAtomsToAddEditBoxHandle, WM_SETTEXT, 0, LPARAM("1"));
			}
			PeriodicTableChemicalComponentList[PeriodicTableChemicalComponentList.size() - 1].number = atoi(data);
			InvalidateRect(hWnd, NULL, TRUE);
		}
		switch (LOWORD(wParam)) {
		case PTW_SHOW:
		{
			//Reset the relevant fields
			SetWindowText(TotalChargeEditBoxHandle, std::to_string(abs(PeriodicTableChemicalComponentCharge)).c_str());
			SetWindowText(NumberOfAtomsToAddEditBoxHandle, "1");
			SendMessage(TogglePosOrNegComponentCharge, BM_SETCHECK, 0, PeriodicTableChemicalComponentCharge > 0);
			ShowWindow(hWnd, SW_SHOW);
		}
		break;
		case PTW_TOGGLE_TOTAL_CHARGE: //if the user hs toggled charge polarity
		case PTW_TOTAL_CHARGE_EDITBOX: //or if they have done something to the edit box
		{
			char data[4];
			SendMessage(TotalChargeEditBoxHandle, WM_GETTEXT, 2, reinterpret_cast<LPARAM>(data));
			if (SendMessage(TogglePosOrNegComponentCharge, BM_GETCHECK, 0, 0) == TRUE) {
				PeriodicTableChemicalComponentCharge = atoi(data);
			}
			else {
				PeriodicTableChemicalComponentCharge = -atoi(data);
			}
			InvalidateRect(hWnd, NULL, FALSE);
		}
		break;
		case PTW_FINISH_COMPONENT:
		{
			ShowWindow(hWnd, SW_HIDE); //Hide (instead of closing) the window!
			SendMessage(ChemicalFormulaCreationWindowHandle, WM_COMMAND, CSW_UPDATE_STRUCTURE_EDITBOX, 0); //Tell the other window to update their editbox!
			PeriodicTableChemicalComponentList.clear(); //Nuke the component list!
		}
		break;
		case PTW_APPLY_COMPONENT:
		{
			SendMessage(ChemicalFormulaCreationWindowHandle, WM_COMMAND, CSW_UPDATE_STRUCTURE_EDITBOX, 0); //Tell the other window to update!
		}
		break;
		case PTW_CANCEL_COMPONENT:
		{
			ShowWindow(hWnd, SW_HIDE); //Hide (instead of closing) the window!
			PeriodicTableChemicalComponentList.clear(); //Nuke the component list!
		}
		break;
		}
	}
	break;
	case WM_LBUTTONUP:
	{
		//check to see if the mouse was over any of the element boxes...
		int totalChemicalComponentLength = 0;
		for (u_int i = 0; i < PeriodicTableChemicalComponentList.size(); i++) {
			if (periodicTableMouseX > PeriodicTableChemicalComponentList[i].BoundingRect.left && periodicTableMouseX < PeriodicTableChemicalComponentList[i].BoundingRect.right) {
				if (periodicTableMouseY > PeriodicTableChemicalComponentList[i].BoundingRect.top - 5 && periodicTableMouseY < PeriodicTableChemicalComponentList[i].BoundingRect.bottom + 5) {
					//Now we know we clicked inside a box, we can get down to cases
					if (periodicTableMouseY < PeriodicTableChemicalComponentList[i].BoundingRect.top + 8 && periodicTableMouseX > PeriodicTableChemicalComponentList[i].BoundingRect.right - 8) { //We clicked on the 'x'!
						PeriodicTableChemicalComponentList.erase(PeriodicTableChemicalComponentList.begin() + i);
						InvalidateRect(hWnd, NULL, FALSE);
						break; //We've got what we came out for, time to leave!
					}
				}
			}
		}
	}
	break;
	case WM_PAINT:
	{
		hdc = BeginPaint(hWnd, &ps);
		SetBkMode(hdc, TRANSPARENT); //make sure the text doesn't show a white background!
		HFONT hFont;
		HBRUSH hBrush;
		SetBkColor(hdc, RGB(255, 255, 255));
		RECT clientRect;
		HRGN bgRgn;
		GetClientRect(hWnd, &clientRect);
		win_width = clientRect.right - clientRect.left;
		win_height = clientRect.bottom - clientRect.top;
		bgRgn = CreateRectRgnIndirect(&clientRect);
		hBrush = CreateSolidBrush(RGB(255, 255, 255)); //colour it white
		FillRgn(hdc, bgRgn, hBrush); //draw to buffer
		DeleteObject(hBrush);

		//Draw the labels for the chemical formuale stuff
		RECT textRect;
		hFont = CreateFont(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		SelectObject(hdc, hFont);
		textRect = { 10, 248, 0,0 };
		DrawText(hdc, "Number of atoms to add:", 23, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 10, 278, 0,0 };
		DrawText(hdc, "Total Charge:", 13, &textRect, DT_LEFT | DT_NOCLIP);
		textRect = { 10, 313, 0,0 };
		DrawText(hdc, "Component Formula:", 18, &textRect, DT_LEFT | DT_NOCLIP);
		DeleteObject(hFont);

		//Set ourselves up to draw chemical formula boxes
		hBrush = CreateSolidBrush(RGB(200, 200, 200));
		SelectObject(hdc, hBrush);
		hFont = CreateFont(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		HFONT subscriptFont = CreateFont(10, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		HFONT exitButtonFont = CreateFont(9, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, NULL);
		int totalChemicalComponentLength = 0;
		for (u_int i = 0; i < PeriodicTableChemicalComponentList.size(); i++) {
			SIZE stringSize;
			SIZE subscriptSize;
			SelectObject(hdc, hFont);
			GetTextExtentPoint32(hdc, PeriodicTableChemicalComponentList[i].symbol.c_str(), PeriodicTableChemicalComponentList[i].symbol.size(), &stringSize);
			textRect = { 153 + totalChemicalComponentLength, 310, 0, 0 };
			if (PeriodicTableChemicalComponentList[i].number > 1) {
				GetTextExtentPoint32(hdc, std::to_string(int(PeriodicTableChemicalComponentList[i].number)).c_str(), std::to_string(int(PeriodicTableChemicalComponentList[i].number)).size(), &subscriptSize);
				subscriptSize.cx += 3; //Add a small amount of padding to the rectangle
			}
			else {
				subscriptSize.cx = 0; //don't extend the bounding rectange at all
				subscriptSize.cy = 0;
			}
			Rectangle(hdc, 150 + totalChemicalComponentLength, 300, 150 + totalChemicalComponentLength + stringSize.cx + subscriptSize.cx + 6, 335); //background rectangle
			PeriodicTableChemicalComponentList[i].BoundingRect = { 150 + totalChemicalComponentLength, 300, 150 + totalChemicalComponentLength + stringSize.cx + subscriptSize.cx + 6, 335};
			DrawText(hdc, PeriodicTableChemicalComponentList[i].symbol.c_str(), PeriodicTableChemicalComponentList[i].symbol.size(), &textRect, DT_LEFT | DT_NOCLIP);
			//if we have more than one atom, we write the subscript number!
			if (PeriodicTableChemicalComponentList[i].number > 1) {
				textRect = { 153 + stringSize.cx + 3 + totalChemicalComponentLength, 310 + 8, 0, 0 };
				SelectObject(hdc, hFont);
				DrawText(hdc, std::to_string(int(PeriodicTableChemicalComponentList[i].number)).c_str(), std::to_string(int(PeriodicTableChemicalComponentList[i].number)).size(), &textRect, DT_LEFT | DT_NOCLIP);
				totalChemicalComponentLength += subscriptSize.cx;
			}
			totalChemicalComponentLength += stringSize.cx + 10; //record the amount of extra space we wook up, and add some padding!
																//and finally, draw a custom "remove" button (i.e. an 'x').
			textRect = { 153 + totalChemicalComponentLength - 13, 299, 0, 0 };
			SelectObject(hdc, exitButtonFont);
			DrawText(hdc, "x", 1, &textRect, DT_LEFT | DT_NOCLIP);
		}
		SelectObject(hdc, hFont);
		textRect = { 153 + totalChemicalComponentLength - 5, 300, 0,0 };
		std::string componentCharge = std::to_string(abs(PeriodicTableChemicalComponentCharge));
		if (PeriodicTableChemicalComponentCharge > 0) {
			if (PeriodicTableChemicalComponentCharge > 1) { //keep to that chemist's habit of not putting in a number a for single charge!
				componentCharge += "+";
			}
			else {
				componentCharge = "+";
			}
			DrawText(hdc, componentCharge.c_str(), componentCharge.size(), &textRect, DT_LEFT | DT_NOCLIP);
		}
		else if (PeriodicTableChemicalComponentCharge < 0) {
			if (PeriodicTableChemicalComponentCharge < -1) {
				componentCharge += "-";
			}
			else {
				componentCharge = "-";
			}
			DrawText(hdc, componentCharge.c_str(), componentCharge.size(), &textRect, DT_LEFT | DT_NOCLIP);
		}
		//Plug our memory leaks...
		DeleteObject(hBrush);
		DeleteObject(hFont);
		DeleteObject(subscriptFont);
		DeleteObject(exitButtonFont);

		EndPaint(hWnd, &ps);
	}
	break;
	case WM_CLOSE:
	{
		ShowWindow(hWnd, SW_HIDE);
		return 1;
	}
	break;
	case WM_DESTROY:
	{
		PostQuitMessage(0);
		return 1;
	}
	break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}
